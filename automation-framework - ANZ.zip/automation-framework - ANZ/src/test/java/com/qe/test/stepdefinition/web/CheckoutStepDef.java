package com.qe.test.stepdefinition.web;

import com.qe.framework.common.CommonActionHelper;
import com.qe.framework.common.GetPOWebElements;
import com.qe.framework.common.Utils;
import com.qe.framework.customexception.ExceptionAndErrors;
import cucumber.api.DataTable;
import cucumber.api.java.en.Then;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.joda.time.DateTime;
import org.openqa.selenium.WebElement;

import java.util.List;

import static org.junit.Assert.assertTrue;

public class CheckoutStepDef extends CommonActionHelper {

    private static final Logger logger = LoggerFactory.getLogger(CommonStepDef.class);
    String pageName = "CheckoutPo";

    @Then("^\"(.*?)\" selects (delivery|collection) slot in checkout page$")
    public void selectSlotInCheckout(String userType, String checkoutType, DataTable locatorType) throws InterruptedException {
        elements = locatorType.raw();
        String currentElement = elements.get(1).get(0);
        String slotDate = elements.get(1).get(1);
        String time = elements.get(1).get(2);
        String preference = elements.get(1).get(3);
        WebElement targetElement = null;
        String property = null;
        Boolean selectionFlag = false;
        Boolean checkIndex = false;
        int flag = 0;
        String attributeValue = null;
        try {
            if (slotDate.equalsIgnoreCase("today") ||
                    slotDate.equalsIgnoreCase("tomorrow") ||
                    slotDate.contains("date_")) {
                if (slotDate.equalsIgnoreCase("today")) {
                    property = "date_current";
                } else if (slotDate.equalsIgnoreCase("tomorrow")) {
                    property = "date_+1dt";
                } else if (slotDate.contains("date_")) {
                    property = slotDate;
                }
                DateTime dateTime = Utils.getDesiredDateTime(property);
                slotDate = Utils.getDateAsString(dateTime);
                String[] splitDate = slotDate.split(" ");
                slotDate = splitDate[2] + " " + splitDate[1];
                slotDate = slotDate.toLowerCase();
            } else {
                slotDate = slotDate.substring(0, 6).toLowerCase();
            }
            List<WebElement> allSlots = GetPOWebElements.getBDDElements(pageName, currentElement);
            for (WebElement element : allSlots) {
                attributeValue = element.getAttribute("aria-label").toLowerCase();
                if (attributeValue.contains(slotDate) && attributeValue.contains(time)) {
                    if (!attributeValue.contains("sold out")) {
                        targetElement = element;
                        selectionFlag = true;
                    }
                    break;
                }
            }
            if (selectionFlag == false) {
                for (WebElement element : allSlots) {
                    attributeValue = element.getAttribute("aria-label").toLowerCase();
                    if (preference.equalsIgnoreCase("before")) {
                        if (attributeValue.contains(slotDate) && attributeValue.contains(time)) {
                            break;
                        } else if (!attributeValue.contains("sold out")) {
                            targetElement = element;
                            selectionFlag = true;
                            break;
                        }
                    } else if (preference.equalsIgnoreCase("after")) {
                        if (!checkIndex && attributeValue.contains(slotDate) && attributeValue.contains(time)) {
                            checkIndex = true;
                        } else if (checkIndex && !attributeValue.contains("sold out")) {
                            targetElement = element;
                            selectionFlag = true;
                            break;
                        }
                    }
                }
            }
            if (!selectionFlag) {
                ExceptionAndErrors.getFailedstep("No slot found");
            } else {
                scrollPageToWebElement(targetElement);
                assertTrue(click(targetElement));
            }
        } catch (Exception e) {
            logger.error(ExceptionAndErrors.getFailedstep(e));
        }
    }

}
