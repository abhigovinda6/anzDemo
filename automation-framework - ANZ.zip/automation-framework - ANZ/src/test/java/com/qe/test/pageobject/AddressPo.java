package com.qe.test.pageobject;


import com.qe.framework.common.GetPOWebElements;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.qe.framework.common.CommonActionHelper;

public class AddressPo extends CommonActionHelper {

    public void deleteAllAddresses(final String pageName) throws InterruptedException {
        WebElement deleteIcon = null;
        WebElement confirmDelete = null;
        deleteIcon = GetPOWebElements.getBDDElement(pageName, "icon_DeleteAddress");

        click(deleteIcon);
        confirmDelete = GetPOWebElements.getBDDElement(pageName, "btn_Confirm");
        click(confirmDelete);
    }


}