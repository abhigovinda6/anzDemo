package com.qe.test.stepdefinition.api;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jayway.jsonpath.JsonPath;
import com.qe.framework.api.helpers.APIHelper;
import com.qe.framework.common.*;
import com.qe.framework.customexception.ExceptionAndErrors;
import com.qe.framework.web.helpers.WebDriverHelper;
import com.qe.test.stepdefinition.Hooks;
import cucumber.api.DataTable;
import cucumber.api.Scenario;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.http.Cookie;
import io.restassured.http.Cookies;
import io.restassured.http.Header;
import io.restassured.http.Headers;
import io.restassured.specification.RequestSpecification;
import org.apache.commons.lang3.StringUtils;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import static com.qe.framework.common.Constants.targetEnvName;
import static com.qe.framework.common.JsonValidation.getNodeSize;
import static com.qe.framework.common.PropertiesHelper.contextMap;
import static org.junit.Assert.assertEquals;

public class APIHandlingStepDef extends APIHelper {
    private static final Logger logger = LoggerFactory.getLogger(APIHandlingStepDef.class);
    String apiBaseUrl = null;
    CommonActionHelper objCommon = CommonActionHelper.getInstance();
    JSONHelper jsonHelper = new JSONHelper();
    CommonActionHelper ab;
    List<Header> headerlist;
    String restURI = null;
    String globalPayLoads = null;
    String filterPattern = "//";
    String endPointV = "Endpoint ->";
    String endPointValue;
    String actualList = "Actual List :";
    String expectedList = "Expected List :";
    String noRecordDelete = "No Record to Delete";
    RequestSpecification request;

    private static int randomNumber = 0;
    private ArrayList<String> actualAttributesList = new ArrayList<>();

    @Given("^\"(.*?)\" sets the following headers attributes for the endpoint \"(.*?)\"$")
    public void setAttriubtesForEndpoint(String userType, String endPointName, DataTable attributesTable) {
        String strHeader;
        Header hdr;
        String token;
        headerlist = new ArrayList<>();
        List<List<String>> item;
        try {
            item = attributesTable.raw();
            for (int j = 1; j < item.size(); j++) {
                if (item.get(j).get(0).contains("Authorization")) {
                    if (Objects.nonNull(contextMap.get(item.get(j).get(1)))) {
                        token = contextMap.get(item.get(j).get(1));
                    } else if (Objects.nonNull(contextMap.get("access_token"))) {
                        token = contextMap.get("access_token");
                    } else {
                        token = initiateAuthCallToToken(item.get(j).get(1));
                        contextMap.put(item.get(j).get(1), token);
                    }
                    strHeader = "Bearer " + token;
                } else {
                    if (item.get(j).get(1).contains("$")) {
                        strHeader = Utils.prepareDataString(item.get(j).get(1));
                        if (strHeader == null || strHeader.endsWith(item.get(j).get(1))) {
                            strHeader = item.get(j).get(1).replace("$", " ").trim();
                            strHeader = Utils.prepareDataString("/APIConfig/" + strHeader);
                        }
                    } else {
                        strHeader = item.get(j).get(1);
                    }
                }

                hdr = new Header(item.get(j).get(0), strHeader);
                headerlist.add(hdr);
            }
            reqHeaders = new Headers(headerlist);
            logger.info("Headers : " + headerlist);
        } catch (Exception e) {
            ExceptionAndErrors.getAPIFailedstep(e.getMessage() + " Headers not set for endpoint.");
        }
    }

    @Given("^\"(.*?)\" updates the following headers attributes for the endpoint \"(.*?)\"$")
    public void updatesHeaderAttributes(String endPoint, String appType, DataTable attributesTable) {
        String strHeader = null;
        Header hdr = null;
        String action = null;
        List<List<String>> item;
        try {
            item = attributesTable.raw();
            for (int j = 1; j < item.size(); j++) {
                if (item.get(j).get(1).contains("$")) {
                    strHeader = item.get(j).get(1).replace("$", " ").trim();
                    strHeader = loadProps.getTestDataProperty(strHeader);
                } else {
                    strHeader = item.get(j).get(1);
                }
                hdr = new Header(item.get(j).get(0), strHeader);
                action = item.get(j).get(2);
                switch (action.toLowerCase()) {
                    case "update":
                        for (Header oldhdr : headerlist) {
                            if (oldhdr.getName().equals(hdr.getName())) {
                                headerlist.remove(oldhdr);
                                headerlist.add(hdr);
                                break;
                            }
                        }
                        break;
                    case "delete":
                        for (Header oldhdr : headerlist) {
                            if (oldhdr.getName().equals(hdr.getName())) {
                                headerlist.remove(oldhdr);
                                break;
                            }
                        }
                        break;
                    case "add":
                        headerlist.add(hdr);
                        break;
                    default:
                        ExceptionAndErrors.getAPIFailedstep("Incorrect action for header update");
                }
            }
            reqHeaders = new Headers(headerlist);
            logger.info("Updated Headers : " + headerlist);
        } catch (Exception e) {
            ExceptionAndErrors.getAPIFailedstep(e.getMessage() + " Headers update failed.");
        }
    }

    @Given("^\"(.*?)\" updates the following body attributes for the endpoint \"(.*?)\"$")
    public void updatesBodyAttributes(String userType, String endPointValue, DataTable attributesTable) throws ParseException {
        String body = getBodyPayload();
        List<List<String>> item;
        String key;
        Object value;
        String action;
        try {
            item = attributesTable.raw();
            for (int j = 1; j < item.size(); j++) {
                key = item.get(j).get(0);
                value = Utils.prepareDataString(item.get(j).get(1));
                action = item.get(j).get(2);

                try {
                    String dataType = item.get(j).get(3);
                    if (dataType.equalsIgnoreCase("integer")) {
                        value = Integer.parseInt(value.toString());
                    } else if (dataType.equalsIgnoreCase("float")) {
                        value = Float.valueOf(value.toString());
                    } else if (dataType.equalsIgnoreCase("boolean")) {
                        value = Boolean.valueOf(value.toString());
                    }
                } catch (Exception e) {
                }

                switch (action.toLowerCase()) {
                    case "update":
                        body = jsonHelper.updateJSONValue(body, key, value);
                        break;
                    case "delete":
                        body = jsonHelper.deleteJSONValue(body, key);
                        break;
                    default:
                        ExceptionAndErrors.getAPIFailedstep("Incorrect action for payload update");
                }
            }
            setBodyPayload(body);
            logger.info("Updated Payload : " + Utils.removeNewLine(getBodyPayload()));
        } catch (Exception e) {
            ExceptionAndErrors.getAPIFailedstep(e.getMessage() + " Payload update failed.");
        }
    }

    @When("^\"(.*?)\" makes a \"(.*?)\" call for \"(.*?)\" using endpoint \"(.*?)\" on url \"(.*?)\"$")
    public void makesCallWithPayLoad(String userType, String callType, String callName, String endPoint, String appType) {
        String jasonBody = null;
        if (getBodyPayload() != null) {
            jasonBody = getBodyPayload();
        }

        setApiUri(appType, endPoint, null);
        request = buildAPICall(jasonBody);
        triggerAPICall(restURI, callType, request);
        setApiResponse(APIHelper.getResponse().asString());
        setBodyPayload(null);
        if (!endPoint.equals("allLocationsEndpoint") || !endPoint.equals("allProductsEndpoint")) {
            logger.info("Response : \n" + getApiResponse());
        }
    }


    @When("^\"(.*?)\" makes a \"(.*?)\" call for \"(.*?)\" using endpoint \"(.*?)\" with below attributes on url \"(.*?)\"$")
    public void makesCallWithPayLoadWithAttributes(String userType, String callType, String callName, String endPoint, String appType, DataTable attributesTable) {
        String jasonBody = null;
        List<List<String>> attributes = attributesTable.raw();
        if (getBodyPayload() != null) {
            jasonBody = getBodyPayload();
        }
        setApiUri(appType, endPoint, attributes);
        request = buildAPICall(jasonBody);
        triggerAPICall(restURI, callType, request);
        setApiResponse(APIHelper.getResponse().asString());
        setBodyPayload(null);
        logger.info("Response : \n" + getApiResponse());
    }

    @When("^\"(.*?)\" prepares an API call for \"(.*?)\" using endpoint \"(.*?)\" with below attributes on url \"(.*?)\"$")
    public void preparesCallWithPayLoadWithAttributes(String userType, String callName, String endPoint, String appType, DataTable attributesTable) {
        String jasonBody = null;
        List<List<String>> attributes = attributesTable.raw();
        if (getBodyPayload() != null) {
            jasonBody = getBodyPayload();
        }
        setApiUri(appType, endPoint, attributes);
        request = buildAPICall(jasonBody);
    }

    @When("^\"(.*?)\" prepares an API call for \"(.*?)\" using endpoint \"(.*?)\" on url \"(.*?)\"$")
    public void preparesCallWithPayLoad(String userType, String callName, String endPoint, String appType) {
        String jasonBody = null;
        if (getBodyPayload() != null) {
            jasonBody = getBodyPayload();
        }
        setApiUri(appType, endPoint, null);
        request = buildAPICall(jasonBody);
        //logger.debug("Request build successfully : " + request.toString());
    }

    @When("^\"(.*?)\" polls( \\d+ times)? \"(.*?)\" call for statusCode \"(.*?)\" with the below attributes$")
    public void makesPollWithPayLoadWithAttributes(String userType, String pollCount, String callType, int statusCode, DataTable attributesTable) throws InterruptedException {
        List<List<String>> attributes = attributesTable.raw();
        int count;
        if (pollCount != null) {
            count = Integer.parseInt(pollCount.replace(" ", "").replace("times", ""));
        } else {
            count = Integer.parseInt(PropertiesHelper.getConfigPropProperty("pollingCount"));
        }
        int interval = Integer.parseInt(PropertiesHelper.getConfigPropProperty("pollingInterval"));
        do {
            triggerAPICall(restURI, callType, request);
            setApiResponse(getResponse().asString());
            logger.info("polling count {}", count);
            if (statusCode == getStatusCode() && comparesAttributesFromTheResponse(attributes)) {
                break;
            }

            Thread.sleep(interval * 1000L);
            count--;
        } while (count > 0);
        if (count == 0) {
            ExceptionAndErrors.getAPIFailedstep("Polling attempts exceeded and the API did not return the status and attributes as expected.");
        }
        setBodyPayload(null);
        logger.info("Response : " + getResponse());
    }

    @When("^\"(.*?)\" polls( \\d+ times)? \"(.*?)\" call for \"(.*?)\" statusCode$")
    public void makesPollWithPayLoad(String userType, String pollCount, String callType, int statusCode) throws InterruptedException {
        int count;
        if (pollCount != null) {
            count = Integer.parseInt(pollCount.replace(" ", "").replace("times", ""));
        } else {
            count = Integer.parseInt(PropertiesHelper.getConfigPropProperty("pollingCount"));
        }
        int interval = Integer.parseInt(PropertiesHelper.getConfigPropProperty("pollingInterval"));
        do {
            triggerAPICall(restURI, callType, request);
            setApiResponse(getApiResponse());
            logger.info("polling count {}", count);
            if (statusCode == getStatusCode()) {
                break;
            }
            Thread.sleep(interval * 1000L);
            count--;
        } while (count > 0);
        if (count == 0) {
            ExceptionAndErrors.getAPIFailedstep("Polling attempts exceeded and the API did not return the status and attributes as expected.");
        }
        setBodyPayload(null);
        logger.info("Response : " + getApiResponse());
    }


    @Given("^\"(.*?)\" sets body with given payLoad \"(.*?)\" for API call$")
    public void setApiBody(String userType, String payload) {
        String apiBody = null;
        String contentType = "/json";
        String RequestFilePath = payload;
        FileHelper fileHelper = new FileHelper();
        try {
            if (headerlist != null) {
                for (Header hd : headerlist) {
                    if (hd.getName().equals("Content-Type")) {
                        contentType = hd.getValue();
                    }
                }
            }
            if (RequestFilePath.startsWith("$")) {
                apiBody = loadProps.getTestDataProperty(RequestFilePath.replace("$", " ").trim());
            } else if (contentType != null) {
                String fileExt = contentType.split("/")[1];
                apiBody = fileHelper.readFileAsString(Constants.JSONREQUESTFOLDERPATH + RequestFilePath + "." + fileExt);
            }
        } catch (Exception e) {
            ExceptionAndErrors.getAPIFailedstep(e.getMessage() + " Payload Creation Failed.");
        }
        setBodyPayload(apiBody);
        logger.info("Payload Created : \n" + Utils.removeNewLine(getBodyPayload()));
    }

    @Given("^\"(.*?)\" sets cookies with following attributes for the endpoint \"(.*?)\"$")
    public void setCookiesForEndpoint(String userType, String endPointName, DataTable attributesTable) {
        String strCookie;
        Cookie cookie;
        List<Cookie> cookieList = new ArrayList<>();
        List<List<String>> item;
        try {
            item = attributesTable.raw();
            for (int j = 1; j < item.size(); j++) {
                if (item.get(j).get(1).contains("$")) {
                    strCookie = item.get(j).get(1).replace("$", " ").trim();
                    strCookie = loadProps.getTestDataProperty(strCookie);
                } else {
                    strCookie = item.get(j).get(1);
                }
                cookie = new Cookie.Builder(item.get(j).get(0), strCookie).build();
                cookieList.add(cookie);
            }
            reqCookies = new Cookies(cookieList);
            logger.info("Cookies : " + cookieList);
        } catch (Exception e) {
            ExceptionAndErrors.getAPIFailedstep(e.getMessage() + " Cookies addition failed.");
        }
    }

    @Then("^Verify status code as$")
    public void verifyReceivesStatusCode(DataTable attributesTable) {
        try {
            int statusCodeExpected;
            int currentStatusCode = getResponse().getStatusCode();
            List<List<String>> attributes = attributesTable.raw();

            statusCodeExpected = Integer.parseInt(attributes.get(1).get(0));
            if (currentStatusCode != statusCodeExpected) {
                ExceptionAndErrors.getAPIFailedstep("Status code not matching. Expected->" + statusCodeExpected + " != " + currentStatusCode);
            }
            ExceptionAndErrors.getAPIPassedstep("Actual Status Code is matching with expected- " + statusCodeExpected + "--" + currentStatusCode);

        } catch (Exception e) {
            ExceptionAndErrors.getAPIFailedstep(e.getMessage());
        }
    }


    @Then("^\"(.*?)\" verifies \"(.*?)\" from the above response$")
    public void verifiesKeyValuesFromResponse(String userType, String infoMsg, DataTable attributesTable) {
        String key;
        String expectedAttribute1;
        String expectedAttribute;
        ArrayList<String> actualValueList = new ArrayList<>();
        ArrayList<String> expectedValueList = new ArrayList<>();
        try {
            String strResponse = getApiResponse();
            List<List<String>> attributes = attributesTable.raw();
            for (int i = 1; i < attributes.size(); i++) {
                key = attributes.get(i).get(0);
                key = Utils.prepareDataString(key);
                if (attributes.get(i).get(1).contains("$")) {
                    expectedAttribute1 = attributes.get(i).get(1).replace("$", "").trim();
                    expectedAttribute = loadProps.getEndpointArgsProperty(expectedAttribute1);
                    if (expectedAttribute == null) {
                        expectedAttribute = contextMap.get(expectedAttribute1);
                    }
                    expectedValueList.add(expectedAttribute);
                } else {
                    expectedValueList.add(attributes.get(i).get(1).trim());
                }
                actualValueList.add(JsonPath.read(strResponse, key).toString());
            }
            assertEquals(actualValueList, expectedValueList);
            logger.info(actualList + actualValueList + "\n" + expectedList + expectedValueList);
        } catch (Exception e) {
            ExceptionAndErrors.getAPIFailedstep(e.toString());
        }
    }

    @And("^validate that the attributes below are (matching|not matching) in \"(.*?)\" response$")
    public void validateTheAttributeBelowMatchingResponse(String isMatching, String endPointName, DataTable attributesTable) {
        ArrayList<String> aryLst = new ArrayList<>();
        String key;
        String value = null;
        String strResponse = getApiResponse();
        List<List<String>> attributes = attributesTable.raw();
        int i = 0;
        try {
            for (List<String> myItem : attributes) {
                if (i != 0) {
                    key = myItem.get(0).trim();
                    try {
                        value = JsonPath.read(strResponse, key).toString();
                        if (isMatching.equalsIgnoreCase("matching") && (!value.isEmpty())) {
                            logger.info(key + " is present ");
                        } else if (isMatching.equalsIgnoreCase("not matching")) {
                            logger.info(key + " is not present ");
                            ExceptionAndErrors.getAPIFailedstep(key + " is present- requested not matching");
                        }
                    } catch (Exception e) {
                        if (isMatching.equalsIgnoreCase("matching"))
                            ExceptionAndErrors.getFailedstep(key + " not found and matching");
                        else {
                            logger.info(key + " is not present ");
                            ExceptionAndErrors.getPassedstep(key + " is present- requested not matching");
                        }
                    }
                    aryLst.add(value);
                }
                i++;
            }
            logger.info("All attributes verified from response : " + aryLst);
        } catch (Exception e) {
            ExceptionAndErrors.getAPIFailedstep(e.getMessage());
        }
    }

    @And("^\"(.*?)\" verifes following attributes values are (null|not null) from \"(.*?)\" response$")
    public void validateNotNull(String userType, String nullValue, String msg, DataTable attributesTable) {
        try {
            String strResponse = getApiResponse();
            List<List<String>> attributes = attributesTable.raw();
            ArrayList<String> aryLst = new ArrayList<>();
            String key, value;
            int i = 0;
            boolean flag = true;
            for (List<String> myItem : attributes) {
                if (i != 0) {
                    key = myItem.get(0).trim();
                    value = JsonPath.read(strResponse, key).toString();
                    aryLst.add(value);
                    if (nullValue.equalsIgnoreCase("not null") && (value == null || value.isEmpty())) {
                        flag = false;
                    } else if (nullValue.equalsIgnoreCase("null") && (value != null)) {
                        flag = false;
                    }
                }
                i++;
            }
            if (flag) {
                logger.info("Verified attributes from response for " + nullValue + "  values : " + aryLst);
            } else {
                ExceptionAndErrors.getAPIFailedstep("Not all attributes " + nullValue + " : " + aryLst);
            }
        } catch (Exception e) {
            ExceptionAndErrors.getAPIFailedstep(e.getMessage());
        }
    }

    @Then("^\"(.*?)\" get \"(.*?)\" and save as \"(.*?)\" of \"(.*?)\"$")
    public void getsNewlyAddedRecordIdList(String userType, String childNode, String key, String strCase) {
        try {
            childNode = Utils.prepareDataString(childNode);
            String value = JsonValidation.getValueFromJSon(getResponse().asString(), childNode);
            Hooks.scenario.write(key + ":" + value);
            contextMap.put(key, value);
            logger.info("Fetched attribute from response : [" + key + " : " + value + "]");
        } catch (Exception e) {
            ExceptionAndErrors.getAPIFailedstep(e.getMessage());
        }
    }

    @Then("^\"(.*?)\" verifies if \"(.*?)\" exists from the previous \"(.*?)\" and calls \"(.*?)\" endpoint on url \"(.*?)\"$")
    public void verifies_if_exists_from_the_previous_and_calls_endpoint_on_url(String userType, String BasketID, String strCase, String endPoint, String appType, DataTable attributesTable) {
        {
            String jasonBody = null;
            List<List<String>> oldValue = attributesTable.raw();
            List<List<String>> attributes = new ArrayList<>(oldValue);

            try {
                String response = getResponse().asString();
                if (getResponse().asString().contains("basketId")) {
                    String existingBasketID = JsonValidation.getValueFromJSon(getResponse().asString(), "$.baskets[0].basketId");
                    logger.info("Existing basketID : \n" + existingBasketID);
                    List<String> attribute = new ArrayList<String>();
                    attribute.add(attributes.get(1).get(0));
                    attribute.add(existingBasketID);
                    attribute.add("");
                    attributes.set(1, attribute);
                    setApiUri(appType, endPoint, attributes);
                    request = buildAPICall(jasonBody);
                    triggerAPICall(restURI, "DELETE", request);
                    setApiResponse(APIHelper.getResponse().asString());
                    setBodyPayload(null);
                    logger.info("Response : \n" + getApiResponse());
                } else {
                    logger.info("Create a new basket");
                }
            } catch (Exception e) {
                ExceptionAndErrors.getAPIFailedstep(e.getMessage());
            }
        }
    }

    private void saveResponseAttributes(String userType, DataTable attributesTable) {
        try {
            String strResponse = getApiResponse();
            List<List<String>> attributes = attributesTable.raw();
            actualAttributesList.clear();
            int i = 0;
            String key;
            for (List<String> myItem : attributes) {
                key = myItem.get(0).trim();
                if (i != 0) {
                    actualAttributesList.add(JsonPath.read(strResponse, key).toString());
                }
                i++;
            }
            logger.info("Attributes from response : " + actualAttributesList);
        } catch (Exception e) {
            ExceptionAndErrors.getAPIFailedstep(e.getMessage());
        }
    }

    String endPointFilteredValue(String s1, int num, List<List<String>> attributes) {
        String s2;
        String changedValue;
        String requestOperation;
        String getKey;
        String updateValue;
//        String newChanged = null;
        try {
            for (num = 1; num < attributes.size(); num++) {
                updateValue = attributes.get(num).get(0);
                changedValue = attributes.get(num).get(1);
                requestOperation = attributes.get(num).get(2);
                if (changedValue.equalsIgnoreCase("newrecord")) {
                    changedValue = newRecord;
                } else if (changedValue.contains("$")) {
                    changedValue = changedValue.replace("$", " ").trim();
                    getKey = changedValue;
                    changedValue = loadProps.getTestDataProperty((changedValue).trim());
                    if (changedValue == null) {
                        changedValue = contextMap.get(getKey);
                    }
                } else {
                    changedValue = attributes.get(num).get(1);
                }
                if (requestOperation.toLowerCase().contains("encode")) {
                    changedValue = URLEncoder.encode(changedValue, StandardCharsets.UTF_8.toString());
                }
                s2 = "{" + updateValue + "}";

                s1 = s1.replace(s2, changedValue);
            }
//            logger.debug("Filtered Endpoint : " + s1);
        } catch (Exception e) {
            ExceptionAndErrors.getAPIFailedstep(e.getMessage());
        }
        return s1;
    }

    @Then("^\"(.*?)\" verifies the following node size in \"(.*?)\" response$")
    public void verifiesTheSizeWithExpectedSize(String userType, String msg, DataTable attributesTable) throws IOException {
        int objSize;
        ObjectMapper objectMapper = new ObjectMapper();
        String strResponse = getApiResponse();
        JsonNode root = objectMapper.readTree(strResponse);
        try {
            List<List<String>> attributes = attributesTable.raw();
            String node;
            int i = 0, expectedSize;
            for (List<String> myItem : attributes) {
                if (i != 0) {
                    node = myItem.get(0).trim();
                    expectedSize = Integer.parseInt(myItem.get(1).trim());
                    objSize = getNodeSize(root, node);
                    if (expectedSize == objSize) {
                        ExceptionAndErrors.getAPIPassedstep(node + " node size matches expected size : " + objSize + " = " + expectedSize);
                    } else {
                        ExceptionAndErrors.getAPIPassedstep(node + " node size does not match expected size : " + objSize + " != " + expectedSize);
                    }
                }
                i++;
            }
        } catch (Exception e) {
            ExceptionAndErrors.getAPIFailedstep(e.getMessage());
        }
    }

    @Given("^\"(.*?)\" sets body with following payLoads$")
    public void setBodyForEndpoint(String userType, DataTable attributesTable) {

        try {
            List<List<String>> item = attributesTable.raw();
            StringBuilder jsonBody = new StringBuilder(item.get(1).get(1));

            if (jsonBody.toString().startsWith("$")) {
                jsonBody = new StringBuilder(WebDriverHelper.webPropHelper.getTestDataProperty(jsonBody.toString()));
                setBodyPayload(jsonBody.toString());

            } else {

                jsonBody = new StringBuilder("{");
                headerlist = new ArrayList<>();
                String key;
                String value;
                String rKey = "key";
                String rValue = "value";
                String dataType;
                String temp = null;


                for (int i = 1; i < item.size(); i++) {
                    key = item.get(i).get(0);
                    value = item.get(i).get(1);
                    jsonBody.append("\"key\":");
                    jsonBody = new StringBuilder(jsonBody.toString().replace(rKey, key));
                    if (value.contains("newRecord")) {
                        value = newRecord;
                    }

                    if (value.contains("$")) {
                        value = loadProps.getApiBodyValuesProperty(value);
                    }
                    dataType = item.get(i).get(2);
                    if (!dataType.contains("int") && !dataType.contains("bool")) {
                        temp = "\"value\"";
                        temp = temp.replace(rValue, value);
                        value = temp;
                    }
                    jsonBody.append(value).append(",");
                }

                jsonBody = new StringBuilder(StringUtils.chop(jsonBody.toString()));

                globalPayLoads = jsonBody + "}";

                setBodyPayload(globalPayLoads);
                logger.info("Payload Created : \n" + Utils.removeNewLine(getBodyPayload()));
            }
        } catch (Exception e) {
            ExceptionAndErrors.getAPIFailedstep(e.getMessage() + " Payload Creation Failed");
        }
    }

    @Then("^\"(.*?)\" verifies that the result \"(.*?)\" is empty$")
    public void verifiesEmptyResponse(String userType, String data) {


        JSONParser parser = new JSONParser();
        String strResponse = response.asString();

        try {
            JSONObject obj = (JSONObject) parser.parse(strResponse);
            JSONObject dataObj = (JSONObject) obj.get(data);
            if (!dataObj.isEmpty()) {
                logger.error(ExceptionAndErrors.getAPIFailedstep(data + " is not empty"));
            }
            logger.info(data + " is empty");
        } catch (ParseException e) {
            ExceptionAndErrors.getAPIFailedstep(e.getMessage());
        }
    }

    public void setApiUri(String appType, String endPoint, List<List<String>> attributes) {
        try {
            apiBaseUrl = PropertiesHelper.getConfigPropProperty(appType + "." + targetEnvName);
            endPointValue = loadProps.getEndpointProProperty(endPoint);
            String endPointFilterValued = endPointValue;
            if (attributes != null) {
                endPointFilterValued = endPointFilteredValue(endPointValue, 1, attributes);
            }
            endPointFilterValued = endPointFilterValued.replace(filterPattern, "/");
            restURI = apiBaseUrl + endPointFilterValued;
//            logger.debug("Endpoint : " + restURI);
        } catch (Exception e) {
            logger.error(e.getMessage());
        }
    }

    public boolean comparesAttributesFromTheResponse(List<List<String>> item) {
        try {
            actualAttributesList.clear();
            ObjectMapper objectMapper = new ObjectMapper();
            String attribute;
            ArrayList<String> expectedAttributesList = new ArrayList<>();
            String strResponse = response.asString();
            JsonNode root = objectMapper.readTree(strResponse);
            String key;
            for (int j = 1; j < item.size(); j++) {
                key = item.get(j).get(0).trim();
                if (key.contains("$")) {
                    actualAttributesList.add(JsonPath.read(strResponse, key).toString());
                } else {
                    String value = Utils.prepareDataString(item.get(j).get(1).trim());
                    actualAttributesList = (ArrayList<String>) JsonValidation.attributeMatchingRecursive(root, item.get(j).get(0).trim(), value, actualAttributesList);
                }

                attribute = Utils.prepareDataString(item.get(j).get(1));
                expectedAttributesList.add(attribute);
            }

            boolean result = true;
            for (int i = 1; i < item.size(); i++) {
                String conditionType = item.get(i).get(2);
                if (conditionType.equals("contains")) {
                    if (!actualAttributesList.get(i - 1).contains(expectedAttributesList.get(i - 1))) {
                        result = false;
                    }
                } else if (conditionType.equals("equals") || conditionType.equals("")) {
                    if (!actualAttributesList.get(i - 1).equals(expectedAttributesList.get(i - 1))) {
                        result = false;
                    }
                }
            }
            return result;
        } catch (Exception e) {
            logger.error(e.getMessage());
        }
        //        logger.debug("Attributes list comparison unsuccessful");
        return false;
    }

    @Then("^\"(.*?)\" gets required json path from the above response$")
    public void getDynamicJsonObject(String userType, DataTable attributesTable) {
        List<List<String>> item;
        boolean indexFound;
        try {
            String strResponse = getApiResponse();
            item = attributesTable.raw();
            for (int j = 1; j < item.size(); j++) {
                indexFound = false;
                String path = item.get(j).get(0);
                String key = item.get(j).get(1);
                String value = Utils.prepareDataString(item.get(j).get(2));
                String validationType = item.get(j).get(3);
                String instance = item.get(j).get(4);
                String secondaryPath = item.get(j).get(5);
                String saveAs = item.get(j).get(6);
                String pathToBePresent = item.get(j).get(7);
                JSONParser jsonParser = new JSONParser();
                JSONArray jsonArray = (JSONArray) jsonParser.parse(JsonPath.read(strResponse, path).toString());
                int i = 0;
                int instanceCount = 1;
                for (Object object : jsonArray) {
                    JSONObject jsonObject = (JSONObject) object;
                    String res = jsonObject.toString();
                    String valueFound = JsonPath.read(res, key).toString();
                    if (valueFound.equalsIgnoreCase(value) && validationType.equalsIgnoreCase("equalsIgnoreCase")) {
                        if (instanceCount == Integer.parseInt(instance)) {
                            contextMap.getContext().put(saveAs, path + "[" + i + "]" + secondaryPath);
                            indexFound = true;
                            break;
                        }
                        instanceCount++;
                    } else if (valueFound.contains(value) && validationType.equalsIgnoreCase("contains")) {
                        if (instanceCount == Integer.parseInt(instance)) {
                            contextMap.getContext().put(saveAs, path + "[" + i + "]" + secondaryPath);
                            indexFound = true;
                            break;
                        }
                        instanceCount++;
                    } else if (valueFound.equals(value) && validationType.equalsIgnoreCase("equals")) {
                        if (instanceCount == Integer.parseInt(instance)) {
                            contextMap.getContext().put(saveAs, path + "[" + i + "]" + secondaryPath);
                            indexFound = true;
                            break;
                        }
                        instanceCount++;
                    }
                    i++;
                }
                assertEquals("JSON path to be found Expected : " + Boolean.valueOf(pathToBePresent) + " But Actual : " + indexFound, Boolean.valueOf(pathToBePresent), indexFound);
            }
        } catch (Exception e) {
            ExceptionAndErrors.getAPIFailedstep(e.getMessage() + " JSONObject not Found");
        }
    }

    @Given("^\"([^\"]*)\" authenticate and get access code \"([^\"]*)\"$")
    public void authenticateAndGetAccessCode(String userType, String endPointName, DataTable attributesTable) {
        List<List<String>> item;
        try {
            item = attributesTable.raw();
            for (int j = 1; j < item.size(); j++) {
                if (item.get(j).get(0).contains("Authorization")) {
                    getCodeToken(item.get(j).get(1));
                }
            }
        } catch (Exception e) {
            ExceptionAndErrors.getAPIFailedstep(e.getMessage() + "Exception in authentication endpoint");
        }
    }


    @And("^\"([^\"]*)\" fetch key value from response headers token$")
    public void fetchKeyValueFromResponseHeadersToken(String userType, DataTable attributesTable) throws Throwable {
        List<List<String>> item = attributesTable.raw();
        for (int j = 1; j < item.size(); j++) {
            String response = item.get(j).get(0);
            String key = item.get(j).get(1);
            String subKey = item.get(j).get(2);
            getKeyValueFromResponse(response, key, subKey);

        }
    }

    @Then("^\"([^\"]*)\"authenticate and get access token$")
    public void authenticateAndGetAccessToken(String arg0, DataTable attributesTable) throws Throwable {
        List<List<String>> item;
        try {
            item = attributesTable.raw();
            for (int j = 1; j < item.size(); j++) {
                if (item.get(j).get(0).contains("Authorization")) {
                    getAccessToken(item.get(j).get(1), item.get(j).get(2), item.get(j).get(3));
                }
            }
        } catch (Exception e) {
            ExceptionAndErrors.getAPIFailedstep(e.getMessage() + "Exception in authentication endpoint");
        }
    }

    @Then("^\"(.*?)\" gets value of a random node from the above response using condition below$")
    public void getValuesFromJsonObject(String userType, DataTable attributesTable) {
        List<List<String>> item;
        try {
            String fetchedValue = "";
            String strResponse = getApiResponse();
            item = attributesTable.raw();
            JSONParser jsonParser = new JSONParser();
            JSONArray jsonArray = new JSONArray();
            for (int j = 1; j < item.size(); j++) {
                String path = item.get(j).get(0);
                String secondaryPath = item.get(j).get(1);
                String key = item.get(j).get(2);
                String value = Utils.prepareDataString(item.get(j).get(3));
                String contains = item.get(j).get(4);
                String notContains = item.get(j).get(5);
                String charLength = item.get(j).get(6);
                String saveAs = item.get(j).get(7);
                String randomIndexType = item.get(j).get(8);
                if (jsonArray.size() == 0) {
                    jsonArray = (JSONArray) jsonParser.parse(JsonPath.read(strResponse, path).toString());
                }
                for (int i = 0; i < jsonArray.size(); i++) {
                    int index = 0;
                    boolean validationStatus = true;
                    if (!randomIndexType.equalsIgnoreCase("same")) {
                        index = Integer.parseInt(Utils.getRandomNumber(String.valueOf(jsonArray.size() - 1).length()));
                        randomNumber = index;
                    } else {
                        index = randomNumber;
                    }
                    if (index < jsonArray.size()) {
                        String conditionValueFetched = JsonPath.read(jsonArray.get(index).toString(), key).toString();
                        if (conditionValueFetched.equalsIgnoreCase(value)) {
                            net.minidev.json.JSONArray array = JsonPath.read(jsonArray.get(index).toString(), secondaryPath);
                            fetchedValue = array.get(0).toString();
                            if (!contains.equalsIgnoreCase("")) {
                                if (!fetchedValue.contains(contains)) {
                                    validationStatus = false;
                                }
                            }
                            if (!notContains.equalsIgnoreCase("")) {
                                if (fetchedValue.contains(notContains)) {
                                    validationStatus = false;
                                }
                            }
                            if (!charLength.equalsIgnoreCase("")) {
                                if (!String.valueOf(fetchedValue.length()).equals(charLength)) {
                                    validationStatus = false;
                                }
                            }
                            if (validationStatus) {
                                contextMap.put(saveAs, fetchedValue);
                                break;
                            } else {
                                i++;
                            }
                        }
                    }
                }
                assertEquals("Required Value was not found", true, !fetchedValue.equals(""));
            }
        } catch (Exception e) {
            ExceptionAndErrors.getAPIFailedstep(e.getMessage() + " JSONObject not Found");
        }
    }
}