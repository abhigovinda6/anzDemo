package com.qe.test.stepdefinition.accessibility;

import com.qe.framework.accessibility.AccessibilityHelper;
import com.qe.framework.common.FileHelper;
import com.qe.framework.common.PropertiesHelper;
import com.qe.framework.common.Utils;
import com.qe.test.stepdefinition.web.CommonStepDef;
import cucumber.api.java.en.Given;
import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

import static com.qe.framework.common.Constants.AXEFOLDERPATH;
import static com.qe.framework.common.Constants.AXETEMPLATEPATH;


public class AccessibilityStepDef extends AccessibilityHelper {
    private static final Logger logger = LoggerFactory.getLogger(CommonStepDef.class);

    private String getCurrentImpactBoxColor(String currImpactLevel) {
        switch (currImpactLevel) {
            case "moderate":
                currImpactLevel = "<li class=\"result warning\">";
                break;
            case "minor":
                currImpactLevel = "<li class=\"result notice\">";
                break;
            default:
                currImpactLevel = "<li class=\"result error\">";
                break;
        }

        return currImpactLevel;
    }

    private StringBuilder getNodesTargetText(JSONArray nodes, String issueHeader) {
        StringBuilder allNodesText = new StringBuilder();
        JSONObject currObject;
        JSONArray currArray;
        for (int iNode = 0; iNode < nodes.length(); iNode++) {
            currObject = nodes.getJSONObject(iNode);
            currArray = currObject.getJSONArray("target");
            allNodesText
                    .append(issueHeader)
                    .append("<pre>").append(currArray.get(0).toString()).append("</pre></li>");
        }
        return allNodesText;
    }

    // ----------------------- AXE Validator ---------------------------------------------
    @Given("^Admin User performs Accessibility validation in \"(.*?)\"$")
    public void performAXEValidation(String pageName) throws IOException {
        JSONObject currObject;
        JSONArray currArray;
        JSONArray currTags;
        List<String> tagList = null;
        List<String> impactLevelList = null;
        File newHtmlFile;
        FileHelper fileHelper = new FileHelper();

        String defaultTags;
        String defaultImpactLevel;
        defaultTags = PropertiesHelper.getConfigPropProperty("accessibilityCategories");

        tagList = Utils.convertCommaSeparatedStringToList(defaultTags);
        defaultTags = Utils.wrapEachValueWithDelimeter(tagList, "\'", ", ");

        defaultImpactLevel = PropertiesHelper.getConfigPropProperty("accessibilityImpactLevels");
        if (defaultImpactLevel.equalsIgnoreCase("all")) {
            defaultImpactLevel = "critical, serious, moderate, minor";
        }
        impactLevelList = Utils.convertCommaSeparatedStringToList(defaultImpactLevel);

        // Run the AXE Processor to determine list of Violations based on criteria - Category and Impact-Level
        JSONArray violations = axeProcessor(pageName, defaultTags, tagList, impactLevelList);

        // Reading the remaining Violations
        if (violations.length() > 0) {
            JSONArray nodes;
            pageName = pageName.trim();
            pageName = pageName.replaceAll("\\s+", " ");
            pageName = pageName.replace(" ", "_");

            File htmlMainTemplateFile = new File(AXETEMPLATEPATH + "AXE_Main_Template.html");
            String htmlMainString = fileHelper.readFileAsString(htmlMainTemplateFile.toString());
            htmlMainString = htmlMainString.replace("$pageName", pageName);

            int criticalCount = 0;
            int seriousCount = 0;
            int moderateCount = 0;
            int minorCount = 0;

            StringBuilder criticalNodes = new StringBuilder();
            StringBuilder seriousNodes = new StringBuilder();
            StringBuilder moderateNodes = new StringBuilder();
            StringBuilder minorNodes = new StringBuilder();

            String currImpactLevel = null;

            // Gather the Statistics
            for (int iErr = 0; iErr < violations.length(); iErr++) {
                StringBuilder criticalHelpText = new StringBuilder();
                StringBuilder seriousHelpText = new StringBuilder();
                StringBuilder moderateHelpText = new StringBuilder();
                StringBuilder minorHelpText = new StringBuilder();

                currObject = violations.getJSONObject(iErr);
                nodes = currObject.getJSONArray("nodes");

                currImpactLevel = currObject.get("impact").toString();
                String currImpactLevelTxt;

                List<String> curObjTags = Utils.jsonarraytostringlist(currObject.getJSONArray("tags"));
                String matchingTags = Utils.getAllItemsMatchingInTwoLists(tagList, curObjTags);

                switch (currImpactLevel) {
                    case "critical":
                        currImpactLevelTxt = getCurrentImpactBoxColor(currImpactLevel);
                        criticalHelpText.append(currImpactLevelTxt)
                                .append("<h2>Description: ").append(currObject.get("help").toString()).append("<br>")
                                .append("Category: ").append(matchingTags).append("<br>")
                                .append("Impact Level: ").append(currImpactLevel).append("<br>")
                                .append("</h2></br>");
                        criticalCount = criticalCount + nodes.length();
                        criticalNodes = criticalNodes.append(getNodesTargetText(nodes, criticalHelpText.toString()));
                        break;
                    case "serious":
                        currImpactLevelTxt = getCurrentImpactBoxColor(currImpactLevel);
                        seriousHelpText.append(currImpactLevelTxt)
                                .append("<h2>Description: ").append(currObject.get("help").toString()).append("<br>")
                                .append("Category: ").append(matchingTags).append("<br>")
                                .append("Impact Level: ").append(currImpactLevel).append("<br>")
                                .append("</h2></br>");
                        seriousCount = seriousCount + nodes.length();
                        seriousNodes = seriousNodes.append(getNodesTargetText(nodes, seriousHelpText.toString()));
                        break;
                    case "moderate":
                        currImpactLevelTxt = getCurrentImpactBoxColor(currImpactLevel);
                        moderateHelpText.append(currImpactLevelTxt)
                                .append("<h2>Description: ").append(currObject.get("help").toString()).append("<br>")
                                .append("Category: ").append(matchingTags).append("<br>")
                                .append("Impact Level: ").append(currImpactLevel).append("<br>")
                                .append("</h2></br>");
                        moderateCount = moderateCount + nodes.length();
                        moderateNodes = moderateNodes.append(getNodesTargetText(nodes, moderateHelpText.toString()));
                        break;
                    case "minor":
                        currImpactLevelTxt = getCurrentImpactBoxColor(currImpactLevel);
                        minorHelpText.append(currImpactLevelTxt)
                                .append("<h2>Description: ").append(currObject.get("help").toString()).append("<br>")
                                .append("Category: ").append(matchingTags).append("<br>")
                                .append("Impact Level: ").append(currImpactLevel).append("<br>")
                                .append("</h2></br>");
                        minorCount = minorCount + nodes.length();
                        minorNodes = minorNodes.append(getNodesTargetText(nodes, minorHelpText.toString()));
                        break;
                }
            }

            // Prepare the Summary Report
            htmlMainString = htmlMainString.replace("$totalErrorsText", "<span class=\"count notice\"><B>TOTAL VIOLATIONS : " + (criticalCount + seriousCount + moderateCount + minorCount) + "<B></span><br>");
            if (criticalCount > 0) {
                htmlMainString = htmlMainString.replace("$criticalCount", "<a href=AccessibilityReport_Critical_" + pageName + ".html>" + "<span class=\"count error\">" + String.valueOf(criticalCount) + " Critical</span></a>");
                htmlMainString = htmlMainString.replace("$criticalHelpText", criticalNodes.toString());
            } else {
                htmlMainString = htmlMainString.replace("$criticalCount", " ");
                htmlMainString = htmlMainString.replace("$criticalHelpText", " ");
            }
            if (seriousCount > 0) {
                htmlMainString = htmlMainString.replace("$seriousCount", "<a href=AccessibilityReport_Serious_" + pageName + ".html>" + "<span class=\"count error\">" + String.valueOf(seriousCount) + " Serious</span></a>");
                htmlMainString = htmlMainString.replace("$seriousHelpText", seriousNodes.toString());
            } else {
                htmlMainString = htmlMainString.replace("$seriousCount", " ");
                htmlMainString = htmlMainString.replace("$seriousHelpText", " ");
            }
            if (moderateCount > 0) {
                htmlMainString = htmlMainString.replace("$moderateCount", "<a href=AccessibilityReport_Moderate_" + pageName + ".html>" + "<span class=\"count warning\">" + String.valueOf(moderateCount) + " Moderate</span></a>");
                htmlMainString = htmlMainString.replace("$moderateHelpText", moderateNodes.toString());
            } else {
                htmlMainString = htmlMainString.replace("$moderateCount", " ");
                htmlMainString = htmlMainString.replace("$moderateHelpText", " ");
            }
            if (minorCount > 0) {
                htmlMainString = htmlMainString.replace("$minorCount", "<a href=AccessibilityReport_Minor_" + pageName + ".html>" + "<span class=\"count notice\">" + String.valueOf(minorCount) + " Minor</span></a>");
                htmlMainString = htmlMainString.replace("$minorHelpText", minorNodes.toString());
            } else {
                htmlMainString = htmlMainString.replace("$minorCount", " ");
                htmlMainString = htmlMainString.replace("$minorHelpText", " ");
            }

            //Print the Main File
            newHtmlFile = new File(AXEFOLDERPATH + "AccessibilityReport_" + pageName + ".html");
            byte[] arr = htmlMainString.getBytes();
            try {
                Files.write(Paths.get(String.valueOf(newHtmlFile)), arr);
            } catch (IOException ex) {
                logger.info("Accessibiility: Error in output to {}", newHtmlFile);
            }
        }
    }
}