package com.qe.test.stepdefinition.feedFile;

import com.qe.framework.common.CSVHelper;
import com.qe.framework.common.FileHelper;
import com.qe.framework.common.HTML;
import com.qe.framework.common.XMLHelper;
import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.qe.framework.common.Constants.*;
import static com.qe.framework.enums.VerificationType.*;
import static org.junit.Assert.fail;

public class FeedFileStepDef extends FileHelper {

    private static final Logger logger = LoggerFactory.getLogger(FileHelper.class);
    FileHelper fileHelper = new FileHelper();
    XMLHelper xmlHelper = new XMLHelper();
    CSVHelper csv_helper = new CSVHelper();

    @Then("^from \"(.+)\" verify (ALL|XML|CSV) files for file name extension rules \"(.+)\"$")
    public void verifyFilesConfirmingTheRules(String fromFolder, String fileFormat, String rules) throws IOException {
        try {
            appendTextInGlobalSummary(HTML.TABLE + HTML.TR + HTML.TH + "File extension verification for folder: " + fromFolder + HTML.TH_CLOSE + HTML.TR_CLOSE);
            rules = rules + ".json";
            List<File> files = new ArrayList<File>();
            boolean flag;
            fromFolder = FEEDFILEINPUTFOLDERPATH + fromFolder;
            if (fileFormat.equalsIgnoreCase("ALL")) {
                files = fileHelper.readFiles(fromFolder);
                flag = fileHelper.verifyFileRules(files, rules);
            } else {
                files = fileHelper.readFiles(fromFolder, fileFormat);
                flag = fileHelper.verifyFileRules(files, rules, fileFormat.toLowerCase());
            }
            if (flag) {
                logger.info("Files validation under directory::" + fromFolder + " successful for rules::" + rules);
            } else {
                logger.info("Files validation under directory::" + fromFolder + " unsuccessful for rules::" + rules);
            }
        } catch (Exception ex) {
            fail(ex.getMessage());
        }
    }

    @Then("^from \"(.+)\" verify (ALL|XML|CSV) batch files for file name extension rules \"(.+)\"$")
    public void verifyBatchFilesConfirmingTheRules(String fromFolder, String fileFormat, String rules) throws IOException {
        try {
            appendTextInGlobalSummary(HTML.TABLE + HTML.TR + HTML.TH
                    + "Verifying the file extension with rule: " + rules + " for folder: " + fromFolder
                    + HTML.TH_CLOSE + HTML.TR_CLOSE);
            rules = rules + ".json";
            List<File> files = new ArrayList<File>();
            boolean flag;
            fromFolder = FEEDFILEINPUTFOLDERPATH + fromFolder;
            if (fileFormat.equalsIgnoreCase("ALL")) {
                files = fileHelper.readFiles(fromFolder);
                flag = fileHelper.verifyFileRules(files, rules);
            } else {
                files = fileHelper.readFiles(fromFolder, fileFormat);
                flag = fileHelper.verifyFileRules(files, rules, fileFormat.toLowerCase());
            }
            if (flag) {
                logger.info("Batch Files validation under directory::" + fromFolder + " successful for rules::" + rules);
            } else {
                logger.info("Batch Files validation under directory::" + fromFolder + " unsuccessful for rules::" + rules);
            }
        } catch (Exception ex) {
            fail(ex.getMessage());
        }
    }

    @Then("^from (valid files) verify (ALL|CSV|XML) files structure confirming the rules \"(.+)\"$")
    public void routestructureConfirmValidFile(String validFiles, String fileFormat, String rules) {
        appendTextInGlobalSummary(HTML.LI + "Verifying the file structure of valid files against rule: " + rules + HTML.LI_CLOSE);
        verifyFileContentConfirmingRules(validFiles, null, fileFormat, rules);

    }

    @Then("^from \"(.+)\" verify (ALL|CSV|XML) files structure confirming the rules \"(.+)\"$")
    public void routestructureConfirmFolder(String fromFolder, String fileFormat, String rules) {
        verifyFileContentConfirmingRules(null, fromFolder, fileFormat, rules);
    }

    private void verifyFileContentConfirmingRules(String validFiles, String fromFolder, String fileFormat, String rules) {
        try {
            rules = rules + ".json";
            List<File> files = new ArrayList<File>();
            boolean flag = false;
            if (validFiles != null) {
                HashMap<File, String> fileStatus = (HashMap<File, String>) FileHelper.fileMap.get(FILE_NAME_EXT);
                for (Map.Entry fileStat : fileStatus.entrySet()) {
                    if (fileStat.getValue().toString().equalsIgnoreCase("pass")) {
                        files.add((File) fileStat.getKey());
                    }
                }
            } else {
                fromFolder = FEEDFILEINPUTFOLDERPATH + fromFolder;
                files = fileHelper.readFiles(fromFolder, fileFormat);
            }
            if (fileFormat.equalsIgnoreCase("xml") || fileFormat.equalsIgnoreCase("all")) {
                flag = xmlHelper.checkAllXMLFiles(files, rules, FILE_STRUCTURE);
            }
            if (fileFormat.equalsIgnoreCase("csv") || fileFormat.equalsIgnoreCase("all")) {
                flag = csv_helper.checkAllCSVFiles(files, rules, FILE_STRUCTURE);
            }
            if (flag) {
                logger.info("Files validation successful for rules::" + rules);
            } else {
                logger.info("Files validation unsuccessful for rules::" + rules);
            }
        } catch (Exception ex) {
            fail(ex.getMessage());
        }
    }

    @Then("^Create rule structure \"(.+)\" for (XML|CSV) file \"(.+)\"$")
    public void createRuleStructure(String fileName, String extension, String xmlFile) {
        try {
            File file = new File(FEEDFILEINPUTFOLDERPATH + xmlFile + "." + extension.toLowerCase());
            File ruleStructure = new File(RULESFILEPATH + "/Template/ruleStructure.json");
            xmlHelper.createDefaultRule(ruleStructure, file, fileName, extension);
        } catch (Exception ex) {
            fail(ex.getMessage());
        }
    }

    @Then("^from (valid files) verify (ALL|CSV|XML) files data quality confirming the rules \"(.+)\"$")
    public void verifyDataAccuracyConfirmingRulesValidFile(String validFiles, String fileFormat, String rules) {
        verifyDataAccuracyConfirmingRules(validFiles, null, fileFormat, rules);
    }

    @Then("^from \"(.+)\" verify (ALL|CSV|XML) files data quality confirming the rules \"(.+)\"$")
    public void verifyDataAccuracyConfirmingRulesFolder(String fromFolder, String fileFormat, String rules) {
        verifyDataAccuracyConfirmingRules(null, fromFolder, fileFormat, rules);
    }

    public void verifyDataAccuracyConfirmingRules(String validFiles, String fromFolder, String fileFormat, String rules) {
        try {
            rules = rules + ".json";
            List<File> files = new ArrayList<File>();
            boolean flag = false;
            if (validFiles != null) {
                HashMap<File, String> fileStatus = (HashMap<File, String>) FileHelper.fileMap.get(FILE_STRUCTURE);
                for (Map.Entry fileStat : fileStatus.entrySet()) {
                    if (fileStat.getValue().toString().equalsIgnoreCase("pass")) {
                        files.add((File) fileStat.getKey());
                    }
                }
            } else {
                fromFolder = FEEDFILEINPUTFOLDERPATH + fromFolder;
                files = fileHelper.readFiles(fromFolder, fileFormat);
            }
            if (fileFormat.equalsIgnoreCase("xml") || fileFormat.equalsIgnoreCase("all")) {
                flag = xmlHelper.checkAllXMLFiles(files, rules, DATA_QUALITY);
            }
            if (fileFormat.equalsIgnoreCase("csv") || fileFormat.equalsIgnoreCase("all")) {
                flag = csv_helper.checkAllCSVFiles(files, rules, DATA_QUALITY);
            }
            if (flag) {
                logger.info("Data Quality Check successful for rules::" + rules);
            } else {
                logger.info("Data Quality Check unsuccessful for rules::" + rules);
            }
        } catch (Exception ex) {
            fail(ex.getMessage());
        }
    }

    @Then("^compare the following data files$")
    public void compareFiles(DataTable dataTable) {
        appendTextInGlobalSummary(HTML.TABLE + HTML.TR + HTML.TD + "File 1" + HTML.TD_CLOSE + HTML.TD + "File 2" + HTML.TD_CLOSE + HTML.TD + "Status" + HTML.TD_CLOSE + HTML.TD + "Report Link" + HTML.TD_CLOSE + HTML.TR_CLOSE);
        List<List<String>> dtable = dataTable.raw();
        addInContextMap("isTableReq", "true");
        CSVHelper csv_helper = new CSVHelper();
        String directory = FEEDFILEINPUTFOLDERPATH;
        for (int i = 1; i < dtable.size(); i++) {
            File contentFile1 = new File(directory + "/" + dtable.get(i).get(0));
            File contentFile2 = new File(directory + "/" + dtable.get(i).get(1));
            csv_helper.compareCSVs(contentFile1, contentFile2);
        }
        appendTextInGlobalSummary(HTML.TABLE_CLOSE);

    }

    @Given("^\"([^\"]*)\" can parse the below XML files and generate CSV output$")
    public void readsTheXmlFileAndWriteInCsvFile(String uerType, DataTable dataTable) throws Throwable {
        List<List<String>> dtable = dataTable.raw();
        File file;
        for (int i = 1; i < dtable.size(); i++) {
            file = new File(USERDIR + "src/test/resources/TestData/FeedFiles/inputs/Demo/ODS/" + dtable.get(i).get(0) + ".xml");
            xmlHelper.xmlToCsv(file);
        }
    }
}
