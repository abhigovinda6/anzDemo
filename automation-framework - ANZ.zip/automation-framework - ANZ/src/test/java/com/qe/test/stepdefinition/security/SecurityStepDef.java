package com.qe.test.stepdefinition.security;

import com.qe.framework.common.CommonActionHelper;
import com.qe.framework.common.Constants;
import com.qe.framework.common.PropertiesHelper;
import com.qe.framework.common.Utils;
import com.qe.framework.customexception.ExceptionAndErrors;
import com.qe.framework.security.helpers.ZapCore;
import com.qe.framework.security.helpers.ZapIntegration;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.zaproxy.clientapi.core.ApiResponse;
import org.zaproxy.clientapi.core.ApiResponseElement;
import org.zaproxy.clientapi.core.ClientApi;
import org.zaproxy.clientapi.core.ClientApiException;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;
import java.util.UUID;
import java.util.regex.Pattern;

import static com.qe.framework.common.Constants.targetEnvName;

public class SecurityStepDef extends CommonActionHelper {

    private static final Logger logger = LoggerFactory.getLogger(SecurityStepDef.class);
    private static String CONTEXTUUID;
    public String TARGET;
    ZapIntegration zapApi;
    ZapCore zap;
    ApiResponse resp;

    public void load() throws ClientApiException {
        TARGET = remdriver.getCurrentUrl();
        zapApi = new ZapIntegration(TARGET);
        zap = new ZapCore(zapApi);

    }


    private String getTargetURL(String appKeyName) {
        String weburl = Utils.prepareDataString(appKeyName + "." + targetEnvName);
        String regex = "^(?:http(s)?:\\/\\/)?\\{username}:\\{password}@[\\w.-]+(?:\\.[\\w\\.-]+)+[\\w\\-\\._~:\\/?#\\[\\]@!\\$&'\\(\\)\\*\\+,;=.]+$";
        if (Pattern.matches(regex, weburl)) {
            String username = null;
            String password = null;
            username = Utils.prepareDataString("/WEBConfig/BasicAuth." + appKeyName + ".userName." + targetEnvName);
            password = Utils.prepareDataString("/WEBConfig/BasicAuth." + appKeyName + ".password." + targetEnvName);
            weburl = weburl.replace("{username}", username).replace("{password}", password);
        }
        return weburl;
    }

    @When("^\"(.*?)\" performs Security Spider Scan on \"(.*?)\"$")
    public ClientApi performsSecuritySpiderScanOn(String userName, String pageName) {
        CONTEXTUUID = UUID.randomUUID().toString();
        String HOSTNAME = PropertiesHelper.getConfigPropProperty("ZAP_HOSTNAME");
        String TARGET = getTargetURL(pageName);
        String zapAddress = PropertiesHelper.getConfigPropProperty("ZAP_ADDRESS");
        int zapPort = Integer.parseInt(PropertiesHelper.getConfigPropProperty("ZAP_PORT"));
        String zapApiKey = Utils.prepareDataString("/Security/ZAP_API_KEY");
        ClientApi api = new ClientApi(zapAddress, zapPort, zapApiKey);
        try {
            // Define a new Session with a new name, using the UUI for this purpose
            api.core.newSession(CONTEXTUUID, "true");
            //Define a new context to make sure we are starting fresh
            api.context.newContext(CONTEXTUUID);
            //Only include the targeted hostname
            api.context.includeInContext(CONTEXTUUID, ".*" + HOSTNAME + ".*");
            api.context.setContextInScope(CONTEXTUUID, "true");
        } catch (Exception e) {
            System.out.println("FATAL: Context could not be set: " + e.toString());
        }
        try {
//            load();
            logger.info("scan on ====>>>   " + TARGET);

            resp = api.spider.scan(TARGET, null, "true", CONTEXTUUID, "true");
            String scanid;
            int progress;

            // The scan now returns a scan id to support concurrent scanning
            scanid = ((ApiResponseElement) resp).getValue();

            // Poll the status until it completes
            do {
                Thread.sleep(1000);
                progress =
                        Integer.parseInt(
                                ((ApiResponseElement) api.spider.status(scanid)).getValue());
                System.out.println("Spider progress : " + progress + "%");
            } while (progress < 100);
            System.out.println("Spider complete");
//            zap.doSpidering();
            generateHtmlReport(api, "SPIDER_SCAN.html");
        } catch (Exception e) {
            logger.error(ExceptionAndErrors.getFailedstep(e.getMessage()));

        }
        return api;
    }

    @When("^\"(.*?)\" performs Security Passive Scan on \"(.*?)\"$")
    public void performsSecurityPassiveScanOn(String userName, String pageName) throws InterruptedException, ClientApiException, IOException {
        ClientApi api;
        int progress;

        api = performsSecuritySpiderScanOn("Admin", pageName);
        do {
            Thread.sleep(1000);
            progress =
                    Integer.parseInt(
                            ((ApiResponseElement) api.pscan.recordsToScan()).getValue());
            System.out.println("Passive Scan progress : " + progress + " records left");
        } while (progress >= 1);
        System.out.println("Passive Scan complete");
        generateHtmlReport(api, "PASSIVE_SCAN.html");
    }

    @When("^\"(.*?)\" performs Security Active Scan on \"(.*?)\"$")
    public void performsSecurityActiveScanOn(String userName, String pageName) throws ClientApiException, InterruptedException, IOException {

        ClientApi api;
        String scanid;
        int progress;

        api = performsSecuritySpiderScanOn("Admin", pageName);
        String TARGET = getTargetURL(pageName);
        api.ascan.removeAllScans();
        resp = api.ascan.scan(TARGET, "True", "False", null, null, null);

        // The scan now returns a scan id to support concurrent scanning
        scanid = ((ApiResponseElement) resp).getValue();

        // Poll the status until it completes
        do {
            Thread.sleep(5000);
            progress =
                    Integer.parseInt(
                            ((ApiResponseElement) api.ascan.status(scanid)).getValue());
            System.out.println("Active Scan progress : " + progress + "%");
        } while (progress < 100);
        System.out.println("Active Scan complete");
        generateHtmlReport(api, "ACTIVE_SCAN.html");
    }


    @Then("^\"([^\"]*)\" is authenticated with login details & scan is performed$")
    public void isAuthenticatedWithLoginDetailsScanIsPerformed(String arg0) throws Throwable {
        try {
            load();
            zapApi.authenticateUser();
        } catch (ClientApiException | UnsupportedEncodingException e) {
            logger.error(e.getMessage());
        }
    }

    @Then("^\"([^\"]*)\" generates the ZAP report as \"(.*?)\"$")
    public void generatesTheReport(String arg0, String reportName) throws Throwable {
        Utils.createFolder(Constants.USERDIR + "target/Zap/");
        zapApi.generateHtmlReport(Constants.USERDIR + "target/Zap/" + reportName + ".html");
    }

    private void generateHtmlReport(ClientApi api, String filePath) throws IOException {
        String report;

        Utils.createFolder(Constants.USERDIR + "target/Zap/");
        filePath = Constants.USERDIR + "target/Zap/" + filePath;
        try (FileWriter fWriter = new FileWriter(filePath); BufferedWriter writer = new BufferedWriter(fWriter)) {
            report = new String(api.core.htmlreport(), StandardCharsets.UTF_8);
            writer.write(report);
        } catch (ClientApiException | IOException e) {
            logger.error(ExceptionAndErrors.getFailedstep(e));
        }
    }
}
