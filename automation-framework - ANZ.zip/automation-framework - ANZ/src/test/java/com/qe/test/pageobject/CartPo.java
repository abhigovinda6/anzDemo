package com.qe.test.pageobject;


import com.qe.framework.common.CommonActionHelper;
import com.qe.framework.common.GetPOWebElements;
import com.qe.framework.common.Utils;
import org.junit.Assert;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class CartPo extends CommonActionHelper {

    @FindBy(xpath = "//span[contains(@aria-label,'Your total is now')]")
    public WebElement text_totalPayable;

    @FindBy(xpath = "//span[@class='order-total__value']")
    public WebElement text_totalPayableMob;

    @FindBy(xpath = "//li[contains(@class,'savings')]//li")
    public WebElement text_multiBuySavings;

    @FindBy(xpath = "//aside[@class='multi-savings__aside']")
    public WebElement text_multiBuySavingsMob;

    @FindBy(xpath = "//*[@aria-label='open trolley summary']")
    public WebElement btn_trolleySummary;

    @FindBy(xpath = "//button[@data-auto-id='btnCheckout']")
    public WebElement btn_checkout;

    public String getPriceofProduct(String productName) throws InterruptedException {
        String xpath = "//a[contains(text(),\"" + productName + "\")]/ancestor::div[contains(@class,'price')]//strong";
        return getText(getfindElementByXPath(xpath));
    }

    public CartPo updateQuantity(String productName, String quantity) throws InterruptedException {
        String xpath = "//a[contains(text(),\"" + productName.trim() + "\")]/ancestor::div[contains(@class,'details')]//input";
        setInputTextWithOptions(getfindElementByXPath(xpath), quantity + Keys.RETURN, true);
        return this;
    }


}