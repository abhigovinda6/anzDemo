package com.qe.test.stepdefinition.web;

import com.qe.framework.common.CommonActionHelper;
import com.qe.framework.common.Utils;
import com.qe.framework.customexception.ExceptionAndErrors;
import com.qe.test.pageobject.CartPo;
import cucumber.api.DataTable;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import static com.qe.framework.common.PropertiesHelper.contextMap;

public class CartStepDef extends CommonActionHelper {
    private static final Logger logger = LoggerFactory.getLogger(CartStepDef.class);
    CartPo cartPo = new CartPo();

    @Then("^\"(.*?)\" (Stores|verifies) the price of following products$")
    public void verifyProductPrice(String userType, String action, DataTable locatorType) {
        try {
            elements = locatorType.raw();
            for (int i = 1; i < elements.size(); i++) {
                String productName = Utils.prepareDataString(elements.get(i).get(0));
                String expectedOrsaveAs = Utils.prepareDataString(elements.get(i).get(1));
                String price = cartPo.getPriceofProduct(productName);
                if (action.equals("verifies"))
                    Utils.numericalComparisonByOperator("equal-to", Float.parseFloat(price.replace("£", "")),
                            Float.parseFloat(expectedOrsaveAs.replace("£", "").replace("now\n", "")));
                else
                    contextMap.getContext().put(expectedOrsaveAs, price);
            }
        } catch (Exception e) {
            logger.error(ExceptionAndErrors.getFailedstep(e, webElement));
        }
    }

    @When("^\"(.*?)\" updates the quantity of following products$")
    public void updateQuantity(String userType, DataTable locatorType) {
        try {
            elements = locatorType.raw();
            for (int i = 1; i < elements.size(); i++) {
                String productName = Utils.prepareDataString(elements.get(i).get(0));
                String quantity = Utils.prepareDataString(elements.get(i).get(1));
                cartPo.updateQuantity(productName, quantity);
            }
        } catch (Exception e) {
            logger.error(ExceptionAndErrors.getFailedstep(e, webElement));
        }
    }


}
