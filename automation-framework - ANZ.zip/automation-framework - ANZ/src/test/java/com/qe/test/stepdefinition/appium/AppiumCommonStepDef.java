package com.qe.test.stepdefinition.appium;

import com.perfecto.utilities.applications.ApplicationUtilities;
import com.perfecto.utilities.browser.BrowserUtilities;
import com.perfecto.utilities.others.OtherUtilities;
import com.perfecto.utilities.uiObjects.UIObjectsUtilities;
import com.qe.framework.appium.helpers.utils.AppiumCommonMethods;
import com.qe.framework.common.Constants;
import com.qe.framework.enums.GestureDirection;
import com.qe.framework.enums.SetswipeDirection;
import com.qe.framework.enums.SwipeDirection;
import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

import static com.qe.framework.common.Constants.remdriver;
import static com.qe.framework.customexception.ExceptionAndErrors.getFailedstep;

public class AppiumCommonStepDef extends AppiumCommonMethods {

    private static final Logger logger = LoggerFactory.getLogger(AppiumCommonStepDef.class);
    public List<List<String>> elements = null;
    String invalidKeyaction = "FAILED Invalid Key Action->";
    String doesNotExpected = "does not contain expected";

    // ----------------------- NAVIGATION ---------------------------------------------

    @Given("^\"(.*?)\" launches the \"(.*?)\" in the mobile (app|browser)$")
    public void userLaunchesTheBrowserNndNavigatesMainPage(String userType, String appConfigKey, String browserOrApp) throws Exception {
        createAndroidiOSSession(browserOrApp, appConfigKey);
        logger.info("Mobile " + appConfigKey + " launched.");
    }

    //WIP
//    @When("^\"(.*?)\" long presses on element \"(.*?)\" in the mobile app$")
//    public void longPress(String userTyp, String elementName, DataTable locatorTypes) {
//        By locator;
//        String objPageNameCT;
//
//        String currentElement;
//        try {
//            List<List<String>> elements = locatorTypes.raw();
//            for (int i = 1; i < elements.size(); i++) {
//                currentElement = elements.get(i).get(0);
//                objPageNameCT = elements.get(i).get(1);
//
//                locator = GetPOWebElements.getBDDByElement(objPageNameCT, currentElement);
//                WebElement element = driver.findElement(locator);
//
//                TouchAction touch = new TouchAction((MobileDriver) driver);
//                LongPressOptions longPressOptions = new LongPressOptions();
//                longPressOptions.withElement(ElementOption.element(element));
//                touch.longPress(longPressOptions).release().perform();
//                logger.info("Long press successful on element: " + element);
//            }
//        } catch (NoSuchElementException e) {
//            logger.error("Mobile - longPress - did not work on the Element" + currentElement);
//            throw e;
//        }
//    }
//
    @When("^\"(.*?)\" swipes (LEFT|RIGHT|UP|DOWN) in the mobile$")
    public void swipe(String userTyp, String direction) throws InterruptedException {
        swipeScreen(SwipeDirection.valueOf(direction));
        logger.info("Mobile - SWIPE " + direction);
    }

    @Then("^\"(.*?)\" hides the keyboard$")
    public void hideKeyBoard(String user) {
        hideKeyBoard();
        logger.info("Closing mobile keyboard");
    }

    @Then("^\"(.*?)\" zooms (IN|OUT) mobile device$")
    public void gesturePerf(String user, String zoomdir) throws InterruptedException {
        remdriver = Constants.remdriver;
        gestureInto(GestureDirection.valueOf(zoomdir));
        logger.info("GESTURE- DIRECTION " + zoomdir);
        Thread.sleep(2000);

    }

    @Then("^\"(.*?)\" swipe (LEFT|RIGHT|UP|DOWN) direction in the mobile browser page$")

    public void getSwipe(String user, String direction) throws InterruptedException {
        remdriver = Constants.remdriver;
        swipeMobile(SetswipeDirection.valueOf(direction));
        logger.info("Mobile - SWIPE " + direction);
        Thread.sleep(2000);
    }

    @Then("^\"(.*?)\" move to home screen of the device$")
    public void movetoHome(String user) throws InterruptedException {
        try {

            OtherUtilities.home((RemoteWebDriver) remdriver);

        } catch (Exception e) {
            logger.error("User is not navigated to Home:\n" + e.getMessage());
        }

    }

    @Then("^\"(.*?)\" clicks on the \"(.*?)\" button$")

    public void clickTextbutton(String userType, String elementType, DataTable locatorType) throws InterruptedException {
        //String basePageName = "";
        //String pageName = "";
        try {
            elements = locatorType.raw();
            String btnName = elements.get(1).get(0);
            UIObjectsUtilities.textButtonClick((RemoteWebDriver) remdriver, btnName, 80, "contain");
        } catch (Exception e) {
            logger.error(getFailedstep(e));
        }

        Thread.sleep(2000);

    }

    @Then("^\"(.*?)\" navigates to external website \"(.*?)\"$")

    public void navigateToother(String user, String elementType, DataTable locatorType) throws InterruptedException {
        try {
            elements = locatorType.raw();
            String siteName = elements.get(1).get(0);
            BrowserUtilities.browserGoto((RemoteWebDriver) remdriver, siteName, "os");
            Thread.sleep(5000);
        } catch (Exception e) {
            logger.error("Browser naviagtion is not successsful:\n" + e.getMessage());
        }
    }

    @Then("^\"(.*?)\" opens the application in mobile device \"(.*?)\"$")

    public void openApp(String userType, String elementType, DataTable locatorType) throws InterruptedException {
        //String basePageName = "";
        //String pageName = "";
        try {
            elements = locatorType.raw();
            String appName = elements.get(1).get(0);
            ApplicationUtilities.startApplicationByName((RemoteWebDriver) remdriver, appName);
        } catch (Exception e) {
            logger.error(getFailedstep(e));
        }
    }

}