package com.qe.test.stepdefinition.web;

import com.qe.framework.common.CommonActionHelper;
import com.qe.framework.common.GetPOWebElements;
import com.qe.framework.customexception.ExceptionAndErrors;
import com.qe.test.pageobject.AddressPo;
import cucumber.api.DataTable;
import cucumber.api.java.en.Then;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.openqa.selenium.WebElement;

import java.util.List;

public class AddressStepDef extends CommonActionHelper {
    private static final Logger logger = LoggerFactory.getLogger(AddressStepDef.class);
    String pageName = "AddressPo";
    AddressPo addressPo = new AddressPo();

    String attributeValue = null;
    String indexValue = null;
    String elementText = null;
    List<WebElement> deleteElementls;

    @Then("^\"(.*?)\" removes and verifies \"(.*?)\" not showing in Address page$")
    public void removesAndVerifiesNotShowingInAddressPage(String userType, String elementType, DataTable locatorType) {

        try {
            elements = locatorType.raw();
            for (int i = 1; i < elements.size(); i++) {
                currentElement = elements.get(i).get(0);
                elementText = elements.get(i).get(1);
                List<WebElement> textPresent = GetPOWebElements.getBDDElements(pageName, elementText);
                if (textPresent.size() > 0) {
                    deleteElementls = GetPOWebElements.getBDDElements(pageName, currentElement);
                    for (int j = 0; j < deleteElementls.size(); j++) {
                        addressPo.deleteAllAddresses(pageName);
                    }
                }
            }
        } catch (Exception e) {
            logger.error(ExceptionAndErrors.getFailedstep(e, webElement));
        }
    }
}
