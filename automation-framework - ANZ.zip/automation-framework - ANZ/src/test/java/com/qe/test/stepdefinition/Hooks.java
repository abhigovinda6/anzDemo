package com.qe.test.stepdefinition;

import com.qe.framework.api.helpers.APIHelper;
import com.qe.framework.common.*;
import com.qe.framework.customexception.ExceptionAndErrors;
import com.qe.framework.web.helpers.BrowserProxyHelper;
import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Objects;

import static com.qe.framework.common.Constants.*;
import static com.qe.framework.common.PropertiesHelper.contextMap;

public class Hooks extends CommonActionHelper {
    private static final Logger logger = LoggerFactory.getLogger(Hooks.class);
    public static Scenario scenario;
    private String screenshortName;

    public Scenario getScenario() {
        return scenario;
    }

    public void setScenario(Scenario scenario) {
        Hooks.scenario = scenario;
    }

    public void startBrowserProxy() {

        Constants.enableBrowserProxy = System.getProperty("EnableBrowserProxy");
        if ("yes".equalsIgnoreCase(Constants.enableBrowserProxy)) {
            logger.info("&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&& Starting Browser MobProxy");
            BrowserProxyHelper.getInstance().initiateBrowserMobProxy();
            Constants.isBrowserProxyEnabled = true;
        }
    }

    @Before
    public void beforeSteps(Scenario scenario) throws Exception {
        Hooks.scenario = scenario;

//        encodedFeatureName = getEncodedFeatureOrScenarioName(0, scenario);
        encodedScenarioName = getEncodedFeatureOrScenarioName(1, scenario);
        if (Utils.isDriverType("remote") || Utils.isDriverType("remloc")) {
            if (Utils.isWebTest(null)) {
                scenarioCloudDevice = CloudConfig.getLocalRemoteReleasedWebOSBrowser();
            } else if (Utils.isMobileTest(null)) {
                scenarioCloudDevice = CloudConfig.getRemoteReleasedMobile();
            }
        } else if (Utils.isDriverType("local")) {
            if (Utils.isWebTest(null)) {
                scenarioCloudDevice = CloudConfig.getLocalRemoteReleasedWebOSBrowser();
            } else if (Utils.isMobileTest(null)) {
                scenarioCloudDevice = CloudConfig.getLocalReleasedMobileDevice();
            }
        }
        APIHelper.reqHeaders = null;
        Constants.screenShortTagNames = "";
        logger.info("BEFORE Test called");
        logger.debug("Execution Start Scenario Name: " + scenario.getName());
        screenshortName = appType + "->" + getTagName("JIRA_");
        logger.info("ScreenshotName Name::" + screenshortName);
        screenshortName = screenshortName.replaceAll("[^A-Za-z\\d-_]", "");
        Constants.screenShortTagNames = screenshortName;

        if (appType.contains("web") || appType.contains("responsive"))
            startBrowserProxy();
        contextMap.put(GLOBAL_SUMMARY, HTML.HTML_START);
    }

    @After
    public void afterSteps(Scenario scenario) {
        try {
            if (Objects.nonNull(contextMap.get("access_token"))) {
                contextMap.remove("access_token");
            }
            if (!Objects.equals(contextMap.get(GLOBAL_SUMMARY), HTML.HTML_START)) {
                CSVHelper csv_helper = new CSVHelper();
                FileHelper fileHelper = new FileHelper();
                String tagName = getTagName("@fd_").replace("@fd_", "");
                String fileName = "GlobalSummary_" + tagName + ".html";
                String fileNameGlobalReport = "FileSummary_" + tagName + ".html";
                fileHelper.writeFileSummary(fileNameGlobalReport);
                logger.info("creating Feed file global summary report for scenario: " + scenario.getName());
                if (contextMap.get("fileMap") != null) {
                    appendTextInGlobalSummary(HTML.LI + "Link to File Summary Data :: <a href=" + fileNameGlobalReport + " target=\"_blank\">" + fileNameGlobalReport + "</a>" + HTML.LI_CLOSE);
                    contextMap.remove("fileMap");
                }
                appendTextInGlobalSummary(HTML.HTML_CLOSE);
                csv_helper.fileWriter(fileName, HTML.UL + "<h3>Scenario: " + scenario.getName() + "</h3>" + HTML.HR +
                        contextMap.get(GLOBAL_SUMMARY));
                logger.info("Created Feedfile Global summary file named: " + fileName + " in directory: " + Constants.FEEDFILEREPORTS);
            }

//            ::FUTURE::
//            encodedScenarioName = getEncodedFeatureOrScenarioName(1, scenario);
//            if (Utils.isDriverType("remote") && Utils.isWebTest()) {
//                CloudConfig.releaseOccupiedWebOSBrowser(encodedScenarioName);
//            }
//            logger.info("Exited Combination: " + scenario.getName() + "----" + scenarioCloudDevice + " ---- JSON --> " + CloudConfig.contextMap.get("DEVICE_PROPERTIES"));

            logger.debug("Execution End Scenario Name: " + scenario.getName() + "  :: Status:" + scenario.getStatus());
            if ((driverType.equalsIgnoreCase("remote") || driverType.equalsIgnoreCase("remloc")) && Utils.isWebTest(null)) {
                try {
                    if (reportiumClient.getReportUrl() == null) {
                        logger.info("----- SCENARIO END: " + scenario.getId() + " was executed on DevOps Agent as fall-back strategy");
                    } else {
                        logger.info("----- SCENARIO END: " + scenario.getId() + " ==> Perfecto URL: " + reportiumClient.getReportUrl());
                    }
                } catch (Exception e) {
                    logger.info("Unfortunately, the Perfecto URL could not be retrieved due to Exception {}", e.getMessage());
                }
            }

//            ::FUTURE::
//            updateTestCaseStatus();
//            updatedTracebilityMatrix();

            if (Utils.isWebTest(null) || Utils.isMobileTest(null)) {
                remdriver = Constants.remdriver;
                if (remdriver != null) {
                    addScreenshot(scenario);
                }
                try {
                    logger.debug("Closing Webdriver or sessions.........");
                    quitDriver();
                } catch (Exception e) {
                    logger.debug("Webdriver or sessions Closed.........");
                }
            }
            logger.debug("Scenario Execution End.");
            logger.info("AFTER Test called");

            stopProxyServer();
        } catch (Exception e) {
            logger.error(ExceptionAndErrors.getFailedstep(e));
        }
    }

    private String getEncodedFeatureOrScenarioName(int featOrScn, Scenario scenario) {
        String[] tab = scenario.getId().split(";");
        String encodedName = tab[featOrScn].replaceAll("[^a-zA-Z\\d]", " ");
        encodedName = Utils.compressString(encodedName);
        return encodedName;
    }

    public void stopProxyServer() {
        logger.debug("EndBrowserProxy is Commented");
        logger.debug("--------------------  inside process ----------------------");
        if ("yes".equalsIgnoreCase(Constants.enableBrowserProxy)) {
            BrowserProxyHelper.getInstance().generateHarFile("BrowserProxy_" + screenshortName + new SimpleDateFormat("dd-MM-yyyy_HH-mm-ss").format(new Date()) + ".har");
        }
    }

    private String getTagName(String name) {
        String tName = "";
        for (String tag : scenario.getSourceTagNames()) {
            if (tag != null && tag.contains(name)) {
                tName = tag;
                break;
            }
        }
        return tName;
    }


    private String getTestType() {
        String appType = "";
        for (String tag : scenario.getSourceTagNames()) {
            if (tag != null) {
                tag = tag.toLowerCase();
                if (tag.contains("api") || tag.contains("web") || tag.contains("mobile") || tag.contains("ob")) {
                    appType = tag.replaceAll("[^A-Za-z\\d-_]", "");
                    break;
                }
            }
        }
        return appType;
    }


    public void addScreenshot(Scenario scenario) {
        boolean flag = false;
        logger.info(scenario.getStatus() + " :Scenario isFailed::" + scenario.isFailed());
        logger.info("Test Type::" + appType);
        if ((appType.contains("web") || appType.contains("ob"))) {
            logger.info("Test Type - screenshot saved -:" + appType);

            flag = embedScreenshot(scenario);
        }
    }

//   ::FUTURE::
//    public void updateTestCaseStatus() {
//        try {
//            if (loadProps.getJiraAtmProperty("isAtmUpdate").equals("yes")) {
//                logger.info("Jira Atm update is ON");
//                String status = scenario.getStatus().substring(0, 1).toUpperCase() + scenario.getStatus().substring(1, 4);
//                String[] test = {""};
//                scenario.getSourceTagNames().stream().filter(s -> s.startsWith("@ATMID")).forEach(tc -> test[0] = tc.substring(7));
//
//                AtmJiraUpdate.updateTestCaseStatus(status, test[0]);
//            }
//        } catch (AtmJiraException e) {
//            logger.error(getFailedstep(e));
//        }
//    }


//    ::FUTURE::
//    public void updatedTracebilityMatrix() {
//        try {
//            if (loadProps.getJiraAtmProperty("isAtmUpdate").equals("yes")) {
//                logger.info("TracebilityMatrix is ON");
//                String[] tagName = new String[3];
//                List<String> tags = (ArrayList<String>) scenario.getSourceTagNames();
//                AtomicInteger i = new AtomicInteger();
//                tags.sort(new Comparator<String>() {
//                    @Override
//                    public int compare(String o1, String o2) {
//                        return o2.compareTo(o1);
//                    }
//                });
//
//                tags.stream().filter(s -> s.startsWith("@ATMID") || s.startsWith("@ST") || s.startsWith("@SCT"))
//                        .forEachOrdered(tag -> {
//                            int ind = tag.indexOf("_");
//                            ind = ind == (-1) ? tag.indexOf("-") : ind;
//                            tagName[i.getAndIncrement()] = tag.substring(ind + 1);
//                        });
//                File file = new File("");
//                try (BufferedWriter out = new BufferedWriter(
//                        new FileWriter(file.getAbsoluteFile() + "//src//test//resources//tracebility//TC_Count.txt", true))) {
//                    out.newLine();
//                    out.write("Sprint-1" + "," + tagName[1] + "," + "APP-" + tagName[0] + "," + tagName[2] + "," + scenario.getStatus().toUpperCase() + ",Automated");
//                    out.close();
//                }
//                logger.debug("execution End Scenario Name: " + scenario.getName() + "  :: Status:" + scenario.getStatus());
//                embedScreenshot(scenario);
//                logger.debug("Closing Webdriver or sessions.........");
//                WebDriverHelper.quitDriver();
//                logger.debug("Scenarion Execution End.");
//            }
//        } catch (IOException e) {
//            logger.error(getFailedstep(e));
//        } catch (Exception e) {
//            logger.error(getFailedstep(e));
//        }
//    }


}