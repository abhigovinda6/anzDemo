package com.qe.test.pageobject;

import com.qe.framework.common.CommonActionHelper;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class CorporatePagePo extends CommonActionHelper {


    @FindBy(xpath = "//input[@id='application_type_single']//parent::label")
    public WebElement btn_appTypeSingle;

    @FindBy(xpath = "//input[@id='application_type_single']")
    public WebElement btn_TypeSingle;

    @FindBy(xpath = "//select[contains(@title,'Number of dependants')]")
    public WebElement lst_noDependents;

    @FindBy(xpath = "//input[@id='borrow_type_home']//parent::label")
    public WebElement btn_appBorrowTypeHome;

    @FindBy(xpath = "(//input[@value='0'])[1]")
    public WebElement inp_annualIncome;

    @FindBy(xpath = "(//input[@value='0'])[2]")
    public WebElement inp_otherIncome;

    @FindBy(xpath = "//input[@id='expenses']")
    public WebElement inp_livingExpense;

    @FindBy(xpath = "//input[@id='homeloans']")
    public WebElement inp_homeLoan;

    @FindBy(xpath = "//input[@id='otherloans']")
    public WebElement inp_otherLoan;

    @FindBy(xpath = "(//input[@value='0'])[8]")
    public WebElement inp_otherMonthlyCommitments;

    @FindBy(xpath = "//input[@id='credit']")
    public WebElement inp_totalCreditCardLimits;

    @FindBy(xpath = "(//button[@class='start-over'])[1]")
    public WebElement btn_startOver;

    @FindBy(xpath = "//button[@id='btnBorrowCalculater']")
    public WebElement btn_borrowCalculator;

    @FindBy(xpath = "//span[@id='borrowResultTextAmount']")
    public WebElement txt_borrowAmount;

    @FindBy(xpath = "//div[@class='borrow__error__text']")
    public WebElement txt_errorMessage;
}
