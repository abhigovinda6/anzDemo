package com.qe.test.stepdefinition.web;

import com.qe.framework.common.*;
import com.qe.framework.enums.ElementStatus;
import com.qe.framework.enums.IFrame;
import com.qe.framework.enums.SelectBy;
import com.qe.framework.web.helpers.QEBrokenURLsLinks;
import com.qe.test.pageobject.GenericPo;
import com.qe.test.stepdefinition.Hooks;
import cucumber.api.DataTable;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.apache.commons.lang3.StringUtils;
import org.joda.time.LocalDate;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.junit.Assert;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.*;
import org.openqa.selenium.html5.LocalStorage;
import org.openqa.selenium.html5.WebStorage;
import org.openqa.selenium.remote.RemoteExecuteMethod;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.remote.html5.RemoteWebStorage;
import org.openqa.selenium.support.Color;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.SimpleDateFormat;
import java.util.*;

import static com.qe.framework.common.Constants.targetEnvName;
import static com.qe.framework.common.PropertiesHelper.contextMap;
import static com.qe.framework.common.PropertiesHelper.getConfigPropProperty;
import static com.qe.framework.common.Utils.convertListToDouble;
import static com.qe.framework.customexception.ExceptionAndErrors.getFailedstep;
import static org.junit.Assert.*;

public class CommonStepDef extends CommonActionHelper {

    private static final Logger logger = LoggerFactory.getLogger(CommonStepDef.class);
    private static WebDriver remdriver;
    GenericPo genericPo = GenericPo.getInstance();
    String objuAction;
    String expectedV;
    String autoGeneraterdUniqueValue;
    String currentURL;
    String keyAction;
    String expectedValueObj;
    String doesNotExpected = "does not contain expected";
    String doesExpected = "does contain expected";

    // ----------------------- NAVIGATION ---------------------------------------------
    @Given("^\"(.*?)\" launches the (ZAP )?browser and navigates to \"(.*?)\" Home page$")
    public void launchBrowserWithMainPage(String userType, String forZap, String url) throws Exception {
        String currnetURL;
        boolean isZap = false;
        String currentNew = null;
        if (forZap != null) {
            isZap = true;
        }

        initializeDriver(isZap);
        remdriver = Constants.remdriver;
        openBaseURL(url, isZap);
        waitForPageLoad(remdriver);

        currnetURL = getCurrentPageURL();
        char last = currnetURL.charAt(currnetURL.length() - 1);
        if (last == '/') {
            currentNew = currnetURL.substring(0, currnetURL.length() - 1);
        }
        String homeURL = currentNew;
        logger.info("{} successfully launched the current home URL {}", userType, homeURL);
    }

//    ::FUTURE::
//    @Then("^\"(.*?)\" navigates to login page$")
//    public void navigatesToLoginPage(String arg1) {
//        driver = Constants.driver;
//        String homeURL = Utils.prepareDataString(targetEnvName.toUpperCase() + weburl);
//        driver.get(homeURL + webPropHelper.getConfigPropProperty("web.login"));
//        driver.manage().timeouts().pageLoadTimeout(100, TimeUnit.SECONDS);
//        logger.info("Successfully navigated to the Login page " + webPropHelper.getConfigPropProperty("app.login"));
//    }

    @And("^\"(.*?)\" navigates (directly|relative) to the URL \"(.*?)\"$")
    public void navigateToPage(String userType, String navigatemethod, String elementType, DataTable locatorType) {
        remdriver = Constants.remdriver;
        logger.info("Navigating to the URL {}", currentElement);
        try {
            elements = locatorType.raw();
            for (int i = 1; i < elements.size(); i++) {
                currentElement = elements.get(i).get(0);
                if (navigatemethod.equals("relative")) {
                    currentElement = getCurrentPageURL() + currentElement;
                }
                remdriver.navigate().to(currentElement);
                logger.info("Successfully navigated to the URL {}", currentElement);
            }
        } catch (Exception e) {
            logger.error("Failed to navigate to the Url: {}", currentURL);
            captureScreenShot(Constants.FAIL);
            getFailedstep(e);
        }
    }

    @And("^\"(.*?)\" switch back to \"(.*?)\" page in parent window$")
    public void switchBackToPageInParentWindow(String userType, String elementType) {
        try {
            Assert.assertTrue(switchBackToParentWindow());
            captureScreenShot(Constants.PASS);
            logger.info("Switched back to Parent window");
        } catch (Exception e) {
            logger.error("Failed to Switched back to Parent window");
            captureScreenShot(Constants.FAIL);
            logger.error(getFailedstep(e));
        }

    }

    @And("^\"(.*?)\" switch back to \"(.*?)\" page in default window$")
    public void switchBackToPageInDefaultWindow(String userType, String elementType) {
        try {
            Assert.assertTrue(switchBackToDefaultWindow());
            captureScreenShot(Constants.PASS);
            logger.info("Switched back to Default window");
        } catch (Exception e) {
            logger.error("Failed to Switched back to Default window");
            captureScreenShot(Constants.FAIL);
            logger.error(getFailedstep(e));
        }
    }


    @And("^User navigates the (previous|next) page$")
    public void userNavigateTheCurrentPage(String navigateDirection) {
        try {
            String logmsg = "";
            remdriver = Constants.remdriver;
            if (navigateDirection.equalsIgnoreCase("previous")) {
                remdriver.navigate().back();
                logmsg = "Navigated to the Previous page";
            } else if (navigateDirection.equalsIgnoreCase("next")) {
                remdriver.navigate().forward();
                logmsg = "Navigated to the Next page";
            }
            captureScreenShot(Constants.PASS);
            logger.info(logmsg);
        } catch (Exception e) {
            logger.error("Failed in navigating back to Previous Page");
            captureScreenShot(Constants.FAIL);
            logger.error(getFailedstep(e));
        }
    }

    @Then("^\"(.*?)\" closes the application$")
    public void userClosesTheApplication(String userType) {
        try {
            logger.debug("User closes the application & Browser.............");
            close();
            quitDriver();
            logger.info("Successfully closed the application");
        } catch (Exception e) {
            logger.error("Failed in closing the application");
            logger.error(getFailedstep(e));
        }
    }

    @Then("^\"(.*?)\" saves the current url of \"(.*?)\"$")
    public void setsCurrentUrlIn(String userT, String pageCT) {
        this.currentURL = getCurrentPageURL();
        try {
            contextMap.getContext().put("$CurrentURL", currentURL);
            captureScreenShot(Constants.PASS);
            logger.info("Saved the value of current URL {} into variable $CurrentURL", currentURL);
        } catch (Exception e) {
            logger.error("Failed to store the current url");
            captureScreenShot(Constants.FAIL);
            logger.error(getFailedstep(e, webElement));
        }

    }

    @Then("^\"(.*?)\" verifies (current|previously saved) url (contains|does not contain) \"(.*?)\" in \"(.*?)\"$")
    public void verifiesCurrentUntainsIn(String userT, String whichURL, String doesNotContain, String elementVal, String pageName) {
        try {
            String savedURL = contextMap.get("$CurrentURL");
            currentURL = getCurrentPageURL();
            if (whichURL.equalsIgnoreCase("previously saved)")) {
                if (doesNotContain.equalsIgnoreCase("contains")) {
                    assertTrue(savedURL.contains(elementVal));
                    logger.info("On this Page {} Found {} within {}", pageName, elementVal, savedURL);
                } else if (doesNotContain.equalsIgnoreCase("does not contain")) {
                    assertFalse(savedURL.contains(elementVal));
                }
            } else if (whichURL.equalsIgnoreCase("current")) {
                if (doesNotContain.equalsIgnoreCase("contains")) {
                    assertTrue(currentURL.contains(elementVal));
                    logger.info("On this Page {} Found {} within {}", pageName, elementVal, currentURL);
                } else if (doesNotContain.equalsIgnoreCase("does not contain")) {
                    assertFalse(currentURL.contains(elementVal));
                }
            }
            captureScreenShot(Constants.PASS);
            logger.info("User successfully verified that {} url {} {}", whichURL, doesNotContain, elementVal);
        } catch (Exception e) {
            logger.info("User failed to verify that {} url {} {}", whichURL, doesNotContain, elementVal);
            captureScreenShot(Constants.FAIL);
            logger.error(getFailedstep(e));
        }
    }

    @Then("^\"(.*?)\" (add|delete|update) the following cookies$")
    public void updateCookieValueFromResponse(String user, String type, DataTable cookieTable) {
        String cookieName = null;
        String cookieValue = null;
        String cookieOperator = null;
        try {
            elements = cookieTable.raw();
            for (int i = 1; i < elements.size(); i++) {
                cookieName = elements.get(i).get(0);
                cookieValue = elements.get(i).get(1);
                cookieOperator = elements.get(i).get(2);

                if (cookieOperator.equalsIgnoreCase("add")) {
                    addCookies(cookieName, cookieValue);
                } else if (cookieOperator.equalsIgnoreCase("delete")) {
                    deleteCookies(cookieName);
                } else
                    upadateCookies(cookieName, cookieValue);
                logger.info("Successfully Performed" + cookieOperator + "operation on" + cookieName);
            }
            captureScreenShot(Constants.PASS);
        } catch (Exception e) {
            logger.error("Failed to perform" + cookieOperator + "operation on" + cookieName);
            captureScreenShot(Constants.FAIL);
            logger.error(getFailedstep(e));
        }
    }

    public void addCookies(String key, String value) {
        try {
            remdriver = Constants.remdriver;
            value = webPropHelper.getTestDataProperty(value);
            Cookie ck = new Cookie(key, value);
            remdriver.manage().addCookie(ck);
            logger.info("Cookies added successfully");
            captureScreenShot(Constants.PASS);
        } catch (Exception e) {
            captureScreenShot(Constants.FAIL);
            logger.error("Failed to add cookies");
            getFailedstep(e);
        }
    }

    public void deleteCookies(String key) {
        try {
            remdriver = Constants.remdriver;
            Cookie ck = remdriver.manage().getCookieNamed(key);
            remdriver.manage().deleteCookie(ck);
            logger.info("Cookies deleted successfully");
            captureScreenShot(Constants.PASS);
        } catch (Exception e) {
            captureScreenShot(Constants.FAIL);
            logger.error("Failed to delete cookies");
            getFailedstep(e);
        }
    }

    public void upadateCookies(String key, String value) {
        try {
            Cookie cookie = remdriver.manage().getCookieNamed(key);
            remdriver.manage().deleteCookie(cookie);
            logger.info("Cookies deleted successfully");
            remdriver.manage().addCookie(
                    new Cookie.Builder(cookie.getName(), value)
                            .domain(cookie.getDomain())
                            .expiresOn(cookie.getExpiry())
                            .path(cookie.getPath())
                            .build()
            );
            captureScreenShot(Constants.PASS);
        } catch (Exception e) {
            captureScreenShot(Constants.FAIL);
            logger.error("Failed to update cookies");
            getFailedstep(e);
        }
    }

    @Then("^\"(.*?)\" switch to (main|second) tab$")
    public void switchToTabName(String userT, String tabName) {
        try {
            switchToTab(tabName);
            logger.info("Successfully switched to {} tab", tabName);
            captureScreenShot(Constants.PASS);
        } catch (Exception e) {
            captureScreenShot(Constants.FAIL);
            logger.info("Failed to switch to {} tab", tabName);
            getFailedstep(e);
        }
    }

    @Then("^\"(.*?)\" close the (main|second) tab$")
    public void closeTabName(String userT, String tabName) {
        try {
            closeTabBrowser();
            logger.info("Successfully closed to the tab");
            captureScreenShot(Constants.PASS);
        } catch (Exception e) {
            captureScreenShot(Constants.FAIL);
            logger.error("Failed to close the tab");
            getFailedstep(e);
        }
    }

    // ----------------------- VERIFY ---------------------------------------------

    @Then("^compares two (numbers|strings) with below attributes$")
    public void compareFloat(String stringOrNumber, DataTable locatorType) {
        String value1Str = "";
        String value2Str = "";
        String operator = "";
        try {
            elements = locatorType.raw();
            for (int i = 1; i < elements.size(); i++) {
                value1Str = Utils.prepareDataString(elements.get(i).get(0));
                value2Str = Utils.prepareDataString(elements.get(i).get(2));
                operator = elements.get(i).get(1);
                if (stringOrNumber.equals("strings")) Utils.stringComparisonByOperator(operator, value1Str, value2Str);
                else
                    Utils.numericalComparisonByOperator(operator, Float.parseFloat(value1Str), Float.parseFloat(value2Str));
                logger.info("Successfully verified if " + value1Str + " is " + operator + " " + value2Str);
            }
        } catch (Exception e) {
            logger.info("Failed to verify if " + value1Str + " is " + operator + " " + value2Str);
            logger.error(getFailedstep(e));
        }
    }

    @Then("^\"([^\"]*)\" gets and validates the current url$")
    public void something_gets_and_validates_the_current_url(String strArg1) {
        try {
            String url = getCurrentPageURL();
            Assert.assertTrue(Utils.validateURLRegex(url));
            logger.info("successfully verifies the synatx of current URL");
            captureScreenShot(Constants.PASS);
        } catch (Exception e) {
            captureScreenShot(Constants.FAIL);
            logger.error("Url has syntax error");
            getFailedstep(e);
        }
    }

    @Then("^\"([^\"]*)\" verifes the no of occurence of regex matched$")
    public void verifesNumberOfOccurenceRregexMatches(String strArg1, DataTable locatorType) {
        String basePageName = "";
        String pageName = "";
        try {
            elements = locatorType.raw();
            for (int i = 1; i < elements.size(); i++) {
                currentElement = elements.get(i).get(0);
                int expectedCount = Integer.parseInt(elements.get(i).get(1));
                String regex = elements.get(i).get(2);
                pageName = elements.get(i).get(3);
                if (pageName.isEmpty()) {
                    pageName = basePageName;
                } else {
                    basePageName = pageName;
                }
                webElement = GetPOWebElements.getBDDElement(pageName, currentElement);
                String text = getText(webElement);
                int actualCount = Utils.valueOccurence(text, regex);
                Assert.assertEquals(actualCount, expectedCount);
                logger.info("Succesfully verified that the text: " + text + " has " + expectedCount + "matches of regex: " + regex);
            }
        } catch (Exception e) {
            logger.info("Failed to verify the count of matched regex with expected");
            logger.error(getFailedstep(e));
        }
    }

    @Then("^\"(.*?)\" verifies that \"(.*?)\" text (are|are not) present in \"(.*?)\"$")
    public void verifiesTextPresentInPage(String userType, String element, String presentOrNot, String pageNameCT, DataTable locatorType) {
        String basePageName = "";
        String pageName = "";
        try {
            elements = locatorType.raw();
            for (int i = 1; i < elements.size(); i++) {
                WebElement webElement = null;
                currentElement = elements.get(i).get(0);
                String textToVerify = elements.get(i).get(1);
                pageName = elements.get(i).get(2);
                if (pageName.isEmpty()) {
                    pageName = basePageName;
                } else {
                    basePageName = pageName;
                }
                By locator = GetPOWebElements.getBDDByElement(pageName, currentElement);
                try {
                    fluentwaitForElement(locator, 30, 2);
                    webElement = remdriver.findElement(locator);
                } catch (Exception e) {
                    if (presentOrNot.equalsIgnoreCase("are not")) assertTrue(true);
                    else fail("Element not found");
                }
                if (webElement != null) {
                    String textOfElement = getText(webElement);

                    if (currentElement.contains("$")) {
                        currentElement = webPropHelper.getTestDataProperty(currentElement).trim();
                    }
                    if (presentOrNot.equalsIgnoreCase("are not")) {
                        assertFalse(textOfElement.contains(textToVerify));
                        logger.info("Verified that [ " + textToVerify + " ] text fragment is not present inside [ " + textOfElement + " ]");
                    } else {
                        assertTrue(textOfElement.contains(textToVerify));
                        logger.info("Verified that [ " + textToVerify + " ] fragment  is  present inside [ " + textOfElement + " ]");
                    }
                }
            }
            captureScreenShot(Constants.PASS);
        } catch (Exception e) {
            captureScreenShot(Constants.PASS);
            logger.error(getFailedstep(e));
        }
    }

    @Then("^\"(.*?)\" (scroll and )?verifies \"(.*?)\" element (is|is not) displayed( with value)? in \"(.*?)\"$")
    public void verifiesDisplayedInHomePage(String userType, String scroll, String elementType, String presentOrNot, String value, String pageNameCT, DataTable locatorType) {
        String basePageName = "";
        String pageName = "";
        remdriver = Constants.remdriver;
        elements = locatorType.raw();
        WebElement webElement = null;
        String rtxvValue = null;
        By locator = null;
        for (int i = 1; i < elements.size(); i++) {
            currentElement = elements.get(i).get(0);
            if (value != null && value.equals(" with value")) {
                rtxvValue = elements.get(i).get(1);
                pageName = elements.get(i).get(2);
            } else {
                pageName = elements.get(i).get(1);
            }
            if (pageName.isEmpty()) {
                pageName = basePageName;
            } else {
                basePageName = pageName;
            }
            if (value != null && value.equals(" with value")) {
                String locatorValue = null;
                if (rtxvValue.contains("$")) {
                    rtxvValue = webPropHelper.getTestDataProperty(rtxvValue);
                }
                locatorValue = GetPOWebElements.getBDDElementString(pageName, currentElement);
                locator = runTimeTextXpath(locatorValue, rtxvValue);
            } else {
                locator = GetPOWebElements.getBDDByElement(pageName, currentElement);
            }
            try {
                boolean verifyFluentWait;
                verifyFluentWait = fluentwaitForElement(locator, 30, 2);
                if (!verifyFluentWait) {
                    throw new NoSuchElementException("");
                }
                webElement = remdriver.findElement(locator);
            } catch (Exception e) {
                if (presentOrNot.equalsIgnoreCase("is not")) assertTrue(true);
                else getFailedstep("Element not found");
            }
            if (webElement != null) {
                if (scroll != null) {
                    if (scroll.equals("scroll and ")) scrollPageToWebElement(webElement);
                }
                if (presentOrNot.equalsIgnoreCase("is not")) {
                    assertFalse(checkElement(webElement, ElementStatus.IS_DISPLAYED));
                } else {
                    assertTrue(checkElement(webElement, ElementStatus.IS_DISPLAYED));
                }
            }
        }
    }

    @Then("^\"(.*?)\" (scroll and )?verifies \"(.*?)\" element (is|is not) enabled in \"(.*?)\"$")
    public void verifiesEnabledInHomePage(String userType, String scroll, String elementType, String presentOrNot, String pageNameCT, DataTable locatorType) {
        remdriver = Constants.remdriver;
        String basePageName = "";
        String pageName = "";

        elements = locatorType.raw();
        WebElement webElement = null;
        for (int i = 1; i < elements.size(); i++) {
            currentElement = elements.get(i).get(0);
            pageName = elements.get(i).get(1);
            if (pageName.isEmpty()) {
                pageName = basePageName;
            } else {
                basePageName = pageName;
            }

            By locator = GetPOWebElements.getBDDByElement(pageName, currentElement);
            try {
                webElement = remdriver.findElement(locator);
            } catch (Exception e) {
                if (presentOrNot.equalsIgnoreCase("is not")) assertTrue(true);
                else fail("Element not found");
            }
            if (webElement != null) {
                scrollPageToWebElement(webElement);
            }
            if (presentOrNot.equalsIgnoreCase("is not")) {
                assertFalse(checkElement(webElement, ElementStatus.IS_ENABLED));
            } else {
                assertTrue(checkElement(webElement, ElementStatus.IS_ENABLED));
            }
        }
    }

    @Then("^\"(.*?)\" verifies that \"(.*?)\" element (is|is not) selected in \"(.*?)\"$")
    public void verifiesElementSelectionInPage(String userType, String elementType, String isNotSelected, String pageNameCT, DataTable locatorType) {
        String basPageName = "";
        String pageName = "";

        try {
            elements = locatorType.raw();
            for (int i = 1; i < elements.size(); i++) {
                currentElement = elements.get(i).get(0);
                pageName = elements.get(i).get(1);
                if (pageName.isEmpty()) {
                    pageName = basPageName;
                } else {
                    basPageName = pageName;
                }
                webElement = GetPOWebElements.getBDDElement(pageName, currentElement);
                if (isNotSelected.equalsIgnoreCase("is not")) {
                    assertFalse(checkElement(webElement, ElementStatus.IS_SELECTED));
                } else {
                    assertTrue(checkElement(webElement, ElementStatus.IS_SELECTED));
                }
                captureScreenShot(Constants.PASS);
                logger.info("Successfully verifies that element " + isNotSelected + " selected");
            }
        } catch (Exception e) {
            captureScreenShot(Constants.FAIL);
            logger.error("Successfully verifies that element " + isNotSelected + " selected");
            getFailedstep(e);
        }
    }

    @Then("^\"(.*?)\" verifies the given page title in Pop-up window$")
    public void verifiesPageInNewWindow(String userType, DataTable locatorType) {
        try {
            elements = locatorType.raw();
            for (int i = 1; i < elements.size(); i++) {
                currentElement = elements.get(i).get(0).trim();
                assertTrue(switchToChildWindow(currentElement));
            }
        } catch (Exception e) {
            logger.error(getFailedstep(currentElement));
        }
    }


    @Then("^\"(.*?)\" verifies \"(.*?)\" element text with the expected text in \"(.*?)\"$")
    public void verifiesElementTextWithExpectedText(String userType, String element, String pageNameCT, DataTable locatorType) {
        String basePageName = "";
        String pageName = "";

        try {
            elements = locatorType.raw();
            for (int i = 1; i < elements.size(); i++) {
                currentElement = elements.get(i).get(0);
                elementValue = elements.get(i).get(1);
                pageName = elements.get(i).get(2);
                if (pageName.isEmpty()) {
                    pageName = basePageName;
                } else {
                    basePageName = pageName;
                }
                webElement = GetPOWebElements.getBDDElement(pageName, currentElement);

                elementValue = Utils.prepareDataString(elementValue);
                Assert.assertTrue(verifyElementTextWithActualText(webElement, elementValue));
                logger.info("Successfully verified that element" + currentElement + " has " + elementValue + " text");
            }
            captureScreenShot(Constants.PASS);
        } catch (Exception e) {
            logger.error("Failed to verify that element" + currentElement + " has " + elementValue + " text");
            captureScreenShot(Constants.FAIL);
            logger.error(getFailedstep(e));
        }
    }

    @Then("^\"([^\"]*)\" verifies the count of item in the list \"(.*?)\" in \"([^\"]*)\"$")
    public void verifyCountOfItemInList(String userType, String elementType, String pageNameCT, DataTable locatorType) {
        String basePageName = "";
        String pageName = "";
        float size;

        int expectedCount = 0;
        String operator = null;
        try {
            elements = locatorType.raw();
            for (int i = 1; i < elements.size(); i++) {
                currentElement = elements.get(i).get(0);
                expectedCount = Integer.parseInt(elements.get(i).get(1));
                operator = elements.get(i).get(2);
                pageName = elements.get(i).get(3);
                if (pageName.isEmpty()) {
                    pageName = basePageName;
                } else {
                    basePageName = pageName;
                }
                webElementLS = GetPOWebElements.getBDDElements(pageName, currentElement);
                size = (float) webElementLS.size();

                logger.info("Validating condition: " + size + "  " + operator + "  " + expectedCount);
                Utils.numericalComparisonByOperator(operator, size, expectedCount);
                logger.info("Successfully verifies the size of list with expected");
            }
            captureScreenShot(Constants.PASS);
        } catch (Exception e) {
            logger.error("Failed to verify the size of list with expected");
            captureScreenShot(Constants.FAIL);
            logger.error(getFailedstep(e));
        }
    }

    @Then("^\"([^\"]*)\" store the counts and text of element across the pages on \"(.*?)\"$")
    public void verifyTypeAndsize(String userType, String elementType, DataTable locatorType) {
        String pageName = "";
        int size;
        int pages = 0;
        String whereToSaveCount = "";
        String whereToSaveElements = "";
        List<WebElement> listOfAllElement;
        int total = 0;
        List<String> list = new ArrayList<>();
        try {
            elements = locatorType.raw();
            currentElement = elements.get(1).get(0);
            whereToSaveCount = elements.get(1).get(1);
            whereToSaveElements = elements.get(1).get(2);
            pageName = elements.get(1).get(3);
            String genericPo = "GenericPo";
            WebElement pagination_box = GetPOWebElements.getBDDElement(genericPo, "lnk_pagination");
            if (checkElement(pagination_box, ElementStatus.IS_DISPLAYED)) {
                pages = Integer.parseInt(Utils.findValuewithPatternAtIndex(getText(pagination_box), "(?<=of)\\s*(-?\\d+(?:\\.\\d+)?)", 1).trim());
                webElement = GetPOWebElements.getBDDElement(genericPo, "btn_rightArrowPagination");
            } else {
                pages = 1;
            }
            for (int j = 1; j <= pages; j++) {
                listOfAllElement = GetPOWebElements.getBDDElements(pageName, currentElement);
                size = listOfAllElement.size();
                total += size;
                for (WebElement products : listOfAllElement) {
                    String s = products.getText();
                    list.add(s);
                }
                webElement = GetPOWebElements.getBDDElement(genericPo, "btn_rightArrowPagination");
                if (j != pages) {
                    click(webElement);
                }
            }
            String TotalWebelements = String.valueOf(total);
            String text_Webelements = Arrays.toString(list.toArray()).replace("[", "").replace("]", "");
            contextMap.getContext().put(whereToSaveCount, TotalWebelements);
            contextMap.getContext().put(whereToSaveElements, text_Webelements);
        } catch (Exception e) {
            logger.error(getFailedstep(e));
        }
    }


    @Then("^\"([^\"]*)\" verifies \"([^\"]*)\" css property with below attributes in \"([^\"]*)\"$")
    public void verifiesCSSPropertyFrom(String userType, String elementVerifyType, String pageName, DataTable locatorType) throws Throwable {

        String cssPropertyValue;
        String hexacolor;
        String attributeName;
        String valueToVerify = "";
        String operator = "";
        String logfail="";
        try {
            elements = locatorType.raw();
            for (int i = 1; i < elements.size(); i++) {
                currentElement = elements.get(i).get(0);
                attributeName = elements.get(i).get(1);
                valueToVerify = elements.get(i).get(2);
                operator = elements.get(i).get(3);
                pageName = elements.get(i).get(4);

                webElement = GetPOWebElements.getBDDElement(pageName, currentElement);
                cssPropertyValue = webElement.getCssValue(attributeName);
                if(attributeName.contains("color"))
                {
                    hexacolor = Color.fromString(cssPropertyValue).asHex();
                    logfail="Failed to verify the color of the element with expected";
                    assertEquals(valueToVerify, hexacolor);
                }
                else if(attributeName.contains("text-align")) {
                    logfail = "Failed to verify the Text Alignment of the element with expected";
                    assertEquals(valueToVerify, cssPropertyValue);
                }
               else if(attributeName.contains("font-family")) {
                    logfail = "Failed to verify the Font Family of the element with expected";
                    assertEquals(valueToVerify, cssPropertyValue);
                } else {
                    String avalue = Utils.findValuewithPatternAtIndex(cssPropertyValue, "\\d+", 1);
                    logfail="Failed to verify the color of the element with expected";
                    Utils.numericalComparisonByOperator(operator, Float.parseFloat(avalue), Float.parseFloat(valueToVerify));
                }
            }

        } catch (Exception e) {
            logger.info(logfail);
            captureScreenShot(Constants.FAIL);
            logger.error(getFailedstep(e));
        }
    }

    @Then("^\"(.*?)\" verifies the \"(.*?)\" list \"(.*?)\" with expected text in \"(.*?)\"$")
    public void verifiyListWithExpectedElelemntAtPosition(String userType, String elementType, String textType, String pageNameCT, DataTable locatorType) {
        String pageName = "";

        String textToBeVerified;
        String actualTextToBeVerified;
        String indexValue;
        try {
            elements = locatorType.raw();
            for (int i = 1; i < elements.size(); i++) {
                currentElement = elements.get(i).get(0);
                pageName = elements.get(i).get(3);
                textToBeVerified = elements.get(i).get(1);
                indexValue = elements.get(i).get(2);
                webElementLS = GetPOWebElements.getBDDElements(pageName, currentElement);
                if (webElementLS.size() != 0) {
                    actualTextToBeVerified = getText(webElementLS.get(Integer.parseInt(indexValue) - 1));
                    if (!(actualTextToBeVerified.contains(textToBeVerified))) {
                        logger.error(getFailedstep(actualTextToBeVerified + "  " + doesNotExpected + "  " + textToBeVerified));
                    }
                } else {
                    logger.error(getFailedstep("list is blank-" + currentElement));
                }
            }
        } catch (Exception e) {
            logger.error(getFailedstep("list is blank-" + currentElement));
        }
    }

    @Then("^\"(.*?)\" verifies the element using RegEx \"(.*?)\" that it contains \"(.*?)\" in \"(.*?)\"$")
    public void verifiesElementContains(String userT, String elementV, String expectedV, String pageNameCT, DataTable locatorType) {
        String basePageName = "";
        String pageName = "";
        String containPattern;
        String elementT;
        String expectedT;
        int textPosition;
        remdriver = Constants.remdriver;
        try {
            elements = locatorType.raw();
            for (int i = 1; i < elements.size(); i++) {
                currentElement = elements.get(i).get(0);
                expectedT = elements.get(i).get(1);
                containPattern = elements.get(i).get(2);
                textPosition = Integer.parseInt(elements.get(i).get(3));
                pageName = elements.get(i).get(4);

                expectedT = currentElement = Utils.prepareDataString(expectedT);
                if (pageName.isEmpty()) {
                    pageName = basePageName;
                } else {
                    basePageName = pageName;
                }
                waitForPageLoad(remdriver);
                webElement = GetPOWebElements.getBDDElement(pageName, currentElement);
                scrollPageToWebElement(webElement);
                elementT = webElement.getText();
                assertEquals(Utils.getTextUsingRegex(elementT, containPattern, textPosition), expectedT);

            }
        } catch (Exception e) {
            logger.error(getFailedstep(e, webElement));
        }
    }

    @Then("^\"(.*?)\" verifies \"(.*?)\" on \"(.*?)\"$")
    public void verifiesByTagname(String userType, String elementType, String pageNameCT, DataTable locatorType) {
        String basePageName = "";
        String pageName = "";
        String expectedValue = null;
        String Tagname = null;
        String Titlename = null;

        try {
            elements = locatorType.raw();
            currentElement = elements.get(1).get(0);
            expectedValue = elements.get(1).get(1);
            objuAction = elements.get(1).get(2);
            pageName = elements.get(1).get(3);
            if (pageName.isEmpty()) {
                pageName = basePageName;
            } else {
                basePageName = pageName;
            }
            switch (objuAction) {
                case "Tagname":
                    webElement = GetPOWebElements.getBDDElement(pageName, currentElement);
                    Tagname = webElement.getTagName();
                    Utils.stringComparisonByOperator("case-insensitive-match", Tagname, expectedValue);
                    break;
                case "PageTitle":
                    webElement = GetPOWebElements.getBDDElement(pageName, currentElement);
                    expectedValue = webElement.getText();
                    Titlename = getTitle();
                    assertNotEquals(Titlename, expectedValue, "Titles name are Equal");
                    break;
            }
            captureScreenShot(Constants.PASS);
            logger.info("Successfully verfied " + objuAction + " with expected value");
        } catch (Exception e) {
            captureScreenShot(Constants.FAIL);
            logger.error("Failed to verify " + objuAction + " with expected value");
            logger.error(getFailedstep(e));
        }
    }

    @Then("^\"(.*?)\" verifies \"(.*?)\" element contains \"(.*?)\" text in \"(.*?)\"$")
    public void verifiesContainsTextInElement(String userType, String element, String actionType, String pageNameCT, DataTable locatorType) {
        String basePageName = "";
        String pageName = "";
        try {
            elements = locatorType.raw();
            for (int i = 1; i < elements.size(); i++) {
                currentElement = elements.get(i).get(0);
                expectedV = elements.get(i).get(1);
                pageName = elements.get(i).get(2);
                if (pageName.isEmpty()) {
                    pageName = basePageName;
                } else {
                    basePageName = pageName;
                }
                expectedV = Utils.prepareDataString(expectedV);

                webElement = GetPOWebElements.getBDDElement(pageName, currentElement);
                String textValue = getText(webElement);
                Assert.assertTrue(textValue.contains(expectedV));
                captureScreenShot(Constants.PASS);
                logger.info("successfully verifies that Element: " + currentElement + " contains " + expectedV);
            }
        } catch (Exception e) {
            captureScreenShot(Constants.FAIL);
            logger.info("Failed to verify that Element: " + currentElement + " contains " + expectedV);
            logger.error(getFailedstep(e));
        }
    }

    @Then("^\"(.*?)\" verifies \"(.*?)\" format \"(.*?)\" in \"(.*?)\"$")
    public void verifiesValueFormatIn(String userType, String seperatorVl, String seperatorFl, DataTable locatorType) {
        String expectedF = null;
        String actualF = null;
        String seperatorF;
        String seperatorValue;
        String basePageName = "";
        String pageName = "";
        try {
            elements = locatorType.raw();
            for (int i = 1; i < elements.size(); i++) {
                currentElement = elements.get(i).get(0);
                seperatorF = elements.get(i).get(1);
                seperatorValue = elements.get(i).get(2);
                expectedF = elements.get(i).get(3);
                pageName = elements.get(i).get(4);
                if (pageName.isEmpty()) {
                    pageName = basePageName;
                } else {
                    basePageName = pageName;
                }
                webElement = GetPOWebElements.getBDDElement(pageName, currentElement);
                if (seperatorF.contains("After")) {
                    actualF = StringUtils.substringAfter(getText(webElement), seperatorValue).trim();
                    Utils.verfiyTextUsingRegex(actualF, expectedF);
                } else if (seperatorF.contains("Remove")) {
                    actualF = StringUtils.remove(getText(webElement), seperatorValue);

                    Utils.verfiyTextUsingRegex(actualF, expectedF);
                } else {
                    Utils.verfiyTextUsingRegex(getText(webElement), expectedF);
                }
            }
            captureScreenShot(Constants.PASS);
            logger.info("successfully verifies the format of the text");
        } catch (Exception e) {
            logger.info("Failed to verify the format of the text");
            captureScreenShot(Constants.FAIL);
            logger.error(getFailedstep(currentElement));
        }
    }

    // this function is used for a Result Summary list of Cards
    @Then("^\"(.*?)\" verifies that \"(.*?)\" tiles have following elements in \"(.*?)\"( and verified against given text)?$")
    public void verifiedMultipleElementsOnResultCards(String userType, String listName, String pageNameCT, String andTextVerified, DataTable locatorType) {

        String textToBeVerified;
        String actualTextToBeVerified;
        int cardIndx = 0;
        WebElement localBDDElement;

        String pageName = "";
        try {
            //Read the Summary List of Cards into webElementLS
            List<List<String>> dataTable = locatorType.raw();
            currentElement = dataTable.get(1).get(0);
            String strListIndex = dataTable.get(1).get(1);
            pageName = dataTable.get(1).get(3);
            webElementLS = GetPOWebElements.getBDDElements(pageName, currentElement);

            if (strListIndex.equalsIgnoreCase("all")) {
                for (int i = 2; i < dataTable.size(); i++) {
                    for (cardIndx = 0; cardIndx < webElementLS.size(); cardIndx++) {
                        currentElement = dataTable.get(i).get(0);
                        textToBeVerified = dataTable.get(i).get(2);

                        localBDDElement = webElementLS.get(cardIndx).findElement(GetPOWebElements.getBDDByElement(pageName, currentElement));
                        logger.info("Element identified by " + currentElement + " is present on the Tile#_" + (cardIndx + 1));
                        if (andTextVerified != null) {
                            actualTextToBeVerified = getText(localBDDElement);
                            if (!(actualTextToBeVerified.contains(textToBeVerified))) {
                                logger.error(getFailedstep(actualTextToBeVerified + "  " + doesNotExpected + "  " + textToBeVerified));
                            } else {
                                logger.info(actualTextToBeVerified + " matches the expected text " + textToBeVerified);
                            }
                        }
                    }
                }
            } else {
                cardIndx = Integer.parseInt(strListIndex) - 1;
                for (int i = 2; i < dataTable.size(); i++) {
                    currentElement = dataTable.get(i).get(0);
                    textToBeVerified = dataTable.get(i).get(2);

                    localBDDElement = webElementLS.get(cardIndx).findElement(GetPOWebElements.getBDDByElement(pageName, currentElement));
                    logger.info("Element identified by " + currentElement + " is present");
                    if (andTextVerified != null) {
                        actualTextToBeVerified = getText(localBDDElement);
                        if (!(actualTextToBeVerified.contains(textToBeVerified))) {
                            logger.error(getFailedstep(actualTextToBeVerified + "  " + doesNotExpected + "  " + textToBeVerified));
                        } else {
                            logger.info(actualTextToBeVerified + " matches the expected text " + textToBeVerified);
                        }
                    }
                }
            }
            captureScreenShot(Constants.PASS);
        } catch (Exception e) {
            captureScreenShot(Constants.FAIL);
            logger.error(getFailedstep("list is blank-" + webElementLS));
        }
    }

    /**
     * @param userName
     * @param locatorType |locator|checked status(true/false)| PageName of locator|
     */
    @Then("^\"(.*?)\" verifies the status of checkbox$")
    public void checkStatusOfCheckbox(String userName, DataTable locatorType) {
        boolean expectedStatus = false;
        String basePageName = "";
        String pageName = "";
        try {
            elements = locatorType.raw();
            for (int i = 1; i < elements.size(); i++) {
                currentElement = elements.get(i).get(0);
                expectedStatus = Boolean.parseBoolean(elements.get(i).get(1).replace(" ", ""));
                pageName = elements.get(i).get(2);
                if (pageName.isEmpty()) {
                    pageName = basePageName;
                } else {
                    basePageName = pageName;
                }
                webElement = GetPOWebElements.getBDDElement(pageName, currentElement);
                logger.info("the status of element is : " + webElement.isSelected());
                assertEquals(expectedStatus, webElement.isSelected());
                captureScreenShot(Constants.PASS);
            }
        } catch (Exception e) {
            captureScreenShot(Constants.FAIL);
            logger.error("Failed at checkbox status: the desired status is " + expectedStatus + " but found " + !expectedStatus);
        }
    }

    @Then("^\"(.*?)\" (clicks and )?verifies Product sorting \"(.*?)\" displayed in \"(.*?)\"$")
    public void verifySorting(String userType, String targetElementType, String keyActionVL, String pageNameCT, DataTable locatorType) {
        List<String> actualList = new ArrayList<>();
        List<String> expectedList = new ArrayList<>();
        List<Double> actualListInDouble;
        List<Double> expectedListInDouble;
        WebElement targetElement;
        String attributeValue;
        String value = null;
        String basePageName = "";
        String pageName = "";

        try {
            elements = locatorType.raw();
            for (int i = 1; i < elements.size(); i++) {
                currentElement = elements.get(i).get(0);
                keyAction = elements.get(i).get(1);
                attributeValue = elements.get(i).get(2);
                pageName = elements.get(i).get(3);
                if (pageName.isEmpty()) {
                    pageName = basePageName;
                } else {
                    basePageName = pageName;
                }
                if (targetElementType != null) {
                    targetElement = GetPOWebElements.getBDDElement(pageName, currentElement);
                    click(targetElement);
                }
                webElementLS = GetPOWebElements.getBDDElements(pageName, currentElement);

                switch (keyAction) {
                    case "Price-Low To High":
                    case "Price-High To Low":
                        for (int j = 0; j <= webElementLS.size() - 1; j++) {
                            value = getText(webElementLS.get(j));
                            value = StringUtils.substringAfter(value, "£");
                            value = StringUtils.deleteWhitespace(value).replace(",", "");
                            actualList.add(value);
                            expectedList.add(value);
                        }
                        break;

                    case "Rating-Low To High":
                    case "Rating-High To Low":
                        for (int j = 0; j <= webElementLS.size() - 1; j++) {
                            value = getAttributeElement(webElementLS.get(j), attributeValue);
                            value = StringUtils.substringBefore(value, "Stars").trim();
                            actualList.add(value);
                            expectedList.add(value);
                        }
                        break;
                    case "Name-A To Z":
                    case "Name-Z TO A":
                    case "Sorted Ascending":
                    case "Sorted Descending":
                    case "Relevence":
                        for (int j = 0; j <= webElementLS.size() - 1; j++) {
                            value = getText(webElementLS.get(j));
                            actualList.add(value.toLowerCase());
                            expectedList.add(value.toLowerCase());
                        }
                        break;
                    case "Total Time-Low To High":
                    case "Total Time-High To Low":
                        for (int j = 0; j < webElementLS.size() - 1; j++) {
                            value = getText(webElementLS.get(j));
                            actualList.add(Utils.hourToMinute(value));
                            expectedList.add(Utils.hourToMinute(value));
                        }
                        break;
                    default:
                        captureScreenShot(Constants.FAIL);
                        logger.error(getFailedstep(""));
                }

                switch (keyAction) {
                    case "Price-Low To High":
                    case "Rating-Low To High":
                    case "Total Time-Low To High":
                        actualListInDouble = convertListToDouble(actualList);
                        expectedListInDouble = convertListToDouble(actualList);
                        Collections.sort(expectedListInDouble);
                        assertEquals(actualListInDouble, expectedListInDouble);
                        break;
                    case "Price-High To Low":
                    case "Rating-High To Low":
                    case "Total Time-High To Low":
                        actualListInDouble = convertListToDouble(actualList);
                        expectedListInDouble = convertListToDouble(actualList);
                        expectedListInDouble.sort(Collections.reverseOrder());
                        assertEquals(actualListInDouble, expectedListInDouble);
                        break;
                    case "Name-A To Z":
                        Collections.sort(expectedList);
                        assertEquals(actualList, expectedList);
                        break;
                    case "Name-Z TO A":
                        actualList.sort(Collections.reverseOrder());
                        assertEquals(actualList, expectedList);
                        break;
                    case "Relevence":
                        break;
                    default:
                        captureScreenShot(Constants.FAIL);
                }
            }
            captureScreenShot(Constants.PASS);
            logger.info("Successfully verified that " + keyAction + " sorting is working");
        } catch (AssertionError ae) {
            captureScreenShot(Constants.FAIL);
            logger.error("Failed - Assertion Error - verify that " + keyAction + "did not work as expected");
            logger.error(getFailedstep(currentElement));
        } catch (Exception e) {
            captureScreenShot(Constants.FAIL);
            logger.error("There was an Exception verifying Sorting functionality");
            logger.error(getFailedstep(currentElement));
        }
    }

    // ----------------------- WAITs ---------------------------------------------
    @And("^User refresh the current page$")
    public void userRefreshTheCurrrentPage() {
        try {
            remdriver = Constants.remdriver;
            remdriver.navigate().refresh();
            waitForPageLoad(remdriver);
            logger.info("Refreshed the page");
            captureScreenShot(Constants.PASS);
        } catch (Exception e) {
            logger.info("Failed to refresh the page");
            captureScreenShot(Constants.FAIL);
            getFailedstep(e);
        }
    }

    @And("^user waits for the page to load$")
    public void userWaitforCurrrentPageLoadComplete() throws Exception {
        logger.info("User is waiting for the page to load");
        remdriver = Constants.remdriver;
        waitForPageLoad(remdriver);
    }

    @When("^\"(.*?)\" waits for few seconds in \"(.*?)\"$")
    public void waitsForToBeLoad(String userT, String pageNme, DataTable locatorType) {
        try {
            elements = locatorType.raw();
            currentElement = elements.get(1).get(0);

            if (currentElement.contains("$")) {
                logger.info("User is waiting for " + webPropHelper.getTestDataProperty(currentElement) + "ms");
                Thread.sleep(Integer.parseInt(webPropHelper.getTestDataProperty(currentElement)));
            } else {
                logger.info("User is waiting for " + currentElement + "ms");
                Thread.sleep(Integer.parseInt(currentElement));
            }
        } catch (Exception e) {
            logger.error(getFailedstep(e));
        }
    }

    @When("^\"(.*?)\" waits for the elements to load in \"(.*?)\"$")
    public void waitsForElementToLoad(String userType, String pageName, DataTable locatorType) {
        elements = locatorType.raw();
        for (int i = 1; i < elements.size(); i++) {
            currentElement = elements.get(i).get(0);
            pageName = elements.get(i).get(1).trim();
            By byThisElement = GetPOWebElements.getBDDByElement(pageName, currentElement);
            logger.info("User is waiting for element:" + currentElement + " to be visible");
            waitForElementVisible(byThisElement);
        }
    }

    // ----------------------- FINDING ELEMENT ---------------------------------------------
    @Then("^\"(.*?)\" scroll to (Top|Bottom) of the \"(.*?)\"$")
    public void scrollToTopBottomOfThePage(String userType, String position, String pageNameCT) {
        try {
            Assert.assertTrue(scrollToTopBottomPage(position));
            logger.info("Successfully scrolled to the " + position + " of the Page");
            captureScreenShot(Constants.PASS);
        } catch (Exception e) {
            logger.error("Successfully scrolled to the " + position + " of the Page");
            captureScreenShot(Constants.FAIL);
            logger.error(getFailedstep(e));
        }
    }

    @Then("^\"(.*?)\" scroll to element of the \"(.*?)\"$")
    public void scrollToElementofThePage(String userType, String pageNameCT, DataTable locatorType) {
        String basePageName = "";
        String pageName = "";
        try {
            elements = locatorType.raw();
            currentElement = elements.get(1).get(0);
            pageName = elements.get(1).get(1);
            if (pageName.isEmpty()) {
                pageName = basePageName;
            } else {
                basePageName = pageName;
            }
            webElement = GetPOWebElements.getBDDElement(pageName, currentElement);
            Assert.assertTrue(scrollPageToWebElement(webElement));
            logger.info("Successfully scrolled to the element: " + currentElement);
            captureScreenShot(Constants.PASS);
        } catch (Exception e) {
            logger.error("Failed to scroll to the element: " + currentElement);
            captureScreenShot(Constants.FAIL);
            logger.error(getFailedstep(e));
        }
    }

    // ----------------------- ENTER TEXT ---------------------------------------------
    @Given("^\"(.*?)\" (clears and )?enters \"(.*?)\" in \"(.*?)\"$")
    public void entersTextInPage(String userType, String clearsInputBox, String elementType, String pageNameCT, DataTable locatorType) {
        String basePageName = "";
        String pageName = "";
        try {
            elements = locatorType.raw();
            for (int i = 1; i < elements.size(); i++) {
                currentElement = elements.get(i).get(0);
                elementValue = elements.get(i).get(1);
                pageName = elements.get(i).get(2).trim();
                if (pageName.isEmpty()) {
                    pageName = basePageName;
                } else {
                    basePageName = pageName;
                }
                if (elementType.toLowerCase().contains("credential")) {
                    elementValue = "/WEBConfig/" + elementValue;
                }
                elementValue = Utils.prepareDataString(elementValue);
                webElement = GetPOWebElements.getBDDElement(pageName, currentElement);
                setInputTextWithOptions(webElement, elementValue, clearsInputBox != null);
            }
        } catch (Exception e) {
            logger.error(getFailedstep(e));
        }
    }

    @Then("^\"(.*?)\" enters unique \"(.*?)\" value in \"(.*?)\"$")
    public void entersUniqueValue(String userT, String uniqueV, String pageNameCT, DataTable locatorType) {
        String basePageName = "";
        String pageName = "";
        String objUniqueV = uniqueV;
        try {
            elements = locatorType.raw();
            for (int i = 1; i < elements.size(); i++) {
                currentElement = elements.get(i).get(0);
                objUniqueV = elements.get(i).get(1);
                pageName = elements.get(i).get(2);
                if (pageName.isEmpty()) {
                    pageName = basePageName;
                } else {
                    basePageName = pageName;
                }
                autoGeneraterdUniqueValue = Utils.generateRandomNumericAlphaString(objUniqueV);
                webElement = GetPOWebElements.getBDDElement(pageName, currentElement);
                setInputTextWithOptions(webElement, autoGeneraterdUniqueValue, true);
                logger.info("user enters the text: " + autoGeneraterdUniqueValue);
                captureScreenShot(Constants.PASS);
            }
        } catch (Exception e) {
            logger.error("user failed to enter the text: " + autoGeneraterdUniqueValue);
            captureScreenShot(Constants.FAIL);
            logger.error(getFailedstep(e, webElement));
        }
    }

    @When("^\"([^\"]*)\" enters the value and presses the Enter key in \"([^\"]*)\"$")
    public void sendKeysAndPressEnter(String userName, String page, DataTable dataTable) {
        String basePageName = "";
        String pageName = "";
        try {
            elements = dataTable.raw();
            for (int i = 1; i < elements.size(); i++) {
                currentElement = elements.get(i).get(0);
                elementValue = elements.get(i).get(1);
                pageName = elements.get(i).get(2).trim();
                if (pageName.isEmpty()) {
                    pageName = basePageName;
                }
                webElement = GetPOWebElements.getBDDElement(pageName, currentElement);
                setInputTextWithEnterKey(webElement, elementValue);
                logger.info("user enters the text: " + elementValue + " and presses Enter Btn");
                captureScreenShot(Constants.PASS);
            }
        } catch (Exception e) {
            logger.error("user failed to enter the text: " + elementValue);
            captureScreenShot(Constants.FAIL);
            logger.error(getFailedstep(e, webElement));
        }
    }

    @And("^\"([^\"]*)\" clears the input$")
    public void clearInput(String user, DataTable dataTable) {
        String basepageName = "";
        String pageName = "";
        try {
            elements = dataTable.raw();
            for (int i = 1; i < elements.size(); i++) {
                currentElement = elements.get(i).get(0);
                pageName = elements.get(i).get(1).trim();
                if (pageName.isEmpty()) {
                    pageName = basepageName;
                } else {
                    basepageName = pageName;
                }
                webElement = GetPOWebElements.getBDDElement(pageName, currentElement);
                clearInput(webElement);
                logger.info("user clears the input");
                captureScreenShot(Constants.PASS);
            }
        } catch (Exception e) {
            logger.error("user failed to clear the input");
            captureScreenShot(Constants.FAIL);
            logger.error(getFailedstep(e));
        }
    }

    @When("^\"([^\"]*)\" Select in dropdown by (TEXT|VALUE|INDEX)$")
    public void selectDropDown(String user, String selectBy, DataTable dataTable) {
        String basePageName = "";
        String pageName = "";
        String text = null;
        try {
            elements = dataTable.raw();
            for (int i = 1; i < elements.size(); i++) {
                currentElement = elements.get(i).get(0);
                text = elements.get(i).get(1);
                pageName = elements.get(i).get(2).trim();
                if (pageName.isEmpty()) {
                    pageName = basePageName;
                }
                webElement = GetPOWebElements.getBDDElement(pageName, currentElement);
                selectBy(webElement, text, SelectBy.valueOf(selectBy));
                logger.info("User selects the option: " + text + " in the dropdown");
                captureScreenShot(Constants.PASS);
            }
        } catch (Exception e) {
            logger.error("User failed to selects the option: " + text + " in the dropdown");
            captureScreenShot(Constants.FAIL);
            logger.error(getFailedstep(e, webElement));
        }
    }

    // ----------------------- ORDER HISTORY Specific ---------------------------------------------
    @And("^\"([^\"]*)\" verifies sorting \"([^\"]*)\" displayed in \"([^\"]*)\"$")
    public void verifieSorting(String userType, String element, String pageNameCT, DataTable locatorType) {
        String pageName = "";
        List<String> listB = new ArrayList<String>();
        try {

            elements = locatorType.raw();
            for (int i = 1; i < elements.size(); i++) {
                currentElement = elements.get(i).get(0);
                pageName = elements.get(i).get(1);
                webElementLS = GetPOWebElements.getBDDElements(pageName, currentElement);

                for (int j = 1; j < webElementLS.size(); j++) {
                    int size = webElementLS.size();
                    String date = webElementLS.get(j).getText();

                    listB.add(date);
                }
                for (int k = 0; k < listB.size() - 1; k++) {

                    DateTimeFormatter formatter = DateTimeFormat.forPattern("dd/MM/yyyy");
                    String date1 = listB.get(k);
                    String date2 = listB.get(k + 1);
                    LocalDate localDate1 = formatter.parseLocalDate(date1);
                    LocalDate localDate2 = formatter.parseLocalDate(date2);
                    boolean is1After2 = (localDate1.isAfter(localDate2) || localDate1.isEqual(localDate2));

                    assertTrue(is1After2);
                }
            }
            logger.info("Successfully verifies that the sorting is working");
            captureScreenShot(Constants.PASS);
        } catch (Exception e) {
            logger.error("Failed to verify that the sorting is working");
            captureScreenShot(Constants.FAIL);
            logger.error(getFailedstep(e));
        }
    }

    @Then("^\"([^\"]*)\" verifies date sorting \"([^\"]*)\" displayed in \"([^\"]*)\"$")
    public void verifieDateSorting(String userType, String element, String pageNameCT, DataTable locatorType) {
        String pageName = "";
        List<Object> listB = new ArrayList<Object>();
        try {

            elements = locatorType.raw();
            for (int i = 1; i < elements.size(); i++) {
                currentElement = elements.get(i).get(0);
                pageName = elements.get(i).get(1);
                webElementLS = GetPOWebElements.getBDDElements(pageName, currentElement);
                SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
                for (int j = 1; j < webElementLS.size(); j++) {
                    String date = webElementLS.get(j).getText();
                    Date date1 = sdf.parse(date);
                    listB.add(date1);
                }
                logger.info(String.valueOf(listB));

                for (int k = 0; k < listB.size() - 1; k++) {

                    Date date2 = (Date) (listB.get(k));
                    Date date3 = (Date) (listB.get(k + 1));
                    assertTrue(date2.compareTo(date3) >= 0);
                }
            }
            logger.info("successfully verifies that the date sorting is working as expected");
            captureScreenShot(Constants.PASS);
        } catch (Exception e) {
            logger.error("Failed to verify that date sorting is working");
            captureScreenShot(Constants.FAIL);
            logger.error(getFailedstep(e));
        }
    }

    // ----------------------- EXTRACT TEXT FROM ELEMENT ---------------------------------------------
    @Then("^\"(.*?)\" gets text of \"(.*?)\"( with fast polling)? and saves into given variable$")
    public void getsTextOfElementAndSaves(String userType, String element, String pollingType, DataTable locatorType) {
        String basePageName = "";
        String pageName = "";
        String whereToSave = "";
        String textFragment = "";
        try {
            elements = locatorType.raw();
            for (int i = 1; i < elements.size(); i++) {
                currentElement = elements.get(i).get(0);
                whereToSave = elements.get(i).get(1);
                pageName = elements.get(i).get(2);
                if (pageName.isEmpty()) {
                    pageName = basePageName;
                } else {
                    basePageName = pageName;
                }
                if (pollingType != null) {
                    By locator = GetPOWebElements.getBDDByElement(pageName, currentElement);
                    fluentwaitForElement(locator, 10, 1);
                    webElement = remdriver.findElement(locator);
                } else {
                    try {
                        scrollPageToWebElement(pageName, currentElement);
                    } catch (NoSuchElementException ne) {
                        //ignore
                    }
                    webElement = GetPOWebElements.getBDDElement(pageName, currentElement);
                }
                textFragment = webElement.getText();
                Assert.assertTrue(textFragment.length() > 0);
                contextMap.getContext().put(whereToSave, textFragment);
                logger.info("Successfully fetched the text: " + textFragment + " and stored it in " + whereToSave);
                captureScreenShot(Constants.PASS);
            }
        } catch (Exception e) {
            logger.info("Failed to fetch the text: " + textFragment + " and stored it in " + whereToSave);
            captureScreenShot(Constants.FAIL);
            logger.error(getFailedstep(e));
        }
    }

    // ----------------------- COMPARE TEXT FRAGMENTS ---------------------------------------------
    @Then("^\"(.*?)\" compares and validates the following \"(.*?)\" in \"(.*?)\"$")
    public void compareAndValitesFollowingKeys(String userType, String element, String pageNameCT, DataTable locatorType) {
        String basePageName = "CommonElementPo";
        String pageName = "";
        String valueFromContextLF = null;
        String valueFromContextRF = null;
        String compareWhat = null;
        String compareWith = null;
        String modeOfValidation = null;

        try {
            elements = locatorType.raw();
            for (int i = 1; i < elements.size(); i++) {
                compareWhat = elements.get(i).get(0);
                compareWith = elements.get(i).get(1);
                modeOfValidation = elements.get(i).get(2);
                pageName = basePageName;

                if (compareWhat.contains("$")) {
                    valueFromContextLF = webPropHelper.getTestDataProperty(compareWhat);
                }
                if (valueFromContextLF == null && contextMap.contains(compareWhat)) {
                    valueFromContextLF = contextMap.get(compareWhat);
                }
                if (valueFromContextLF == null) {
                    valueFromContextLF = compareWhat;
                }
                valueFromContextLF = valueFromContextLF.trim();

                if (compareWith.contains("$")) {
                    valueFromContextRF = webPropHelper.getTestDataProperty(compareWith);
                }
                if (valueFromContextRF == null && contextMap.contains(compareWith)) {
                    valueFromContextRF = contextMap.get(compareWith);
                }
                if (valueFromContextRF == null) {
                    valueFromContextRF = compareWith;
                }
                valueFromContextRF = valueFromContextRF.trim();
                Utils.stringComparisonByOperator(modeOfValidation, valueFromContextLF, valueFromContextRF);
                logger.info("Successfully verifies that the text with given text");
                captureScreenShot(Constants.PASS);
            }
        } catch (Exception e) {
            logger.error("Failed to verify the text with given text");
            captureScreenShot(Constants.FAIL);
            logger.error(getFailedstep(e));

        }
    }

    @And("^\"(.*?)\" get expiry date \"(.*?)\"$")
    public void getcookie(String userType, String elementType, DataTable locatorType) {
        Date expected = null;
        Date actual;
        remdriver = Constants.remdriver;
        try {
            elements = locatorType.raw();
            for (int i = 1; i < elements.size(); i++) {
                currentElement = elements.get(i).get(0);
                Cookie cookie1 = remdriver.manage().getCookieNamed(currentElement);
                expected = cookie1.getExpiry();
                logger.info("Cookie expiry expected {}", expected);
                SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
                String formattedExpected = formatter.format(expected);
                Calendar c1 = Calendar.getInstance();
                c1.add(Calendar.DAY_OF_YEAR, 30);
                actual = c1.getTime();
                String formattedActual = formatter.format(actual);

                assertEquals(formattedExpected, formattedActual);
                logger.info("Cookie details {}", cookie1);
                logger.info("Successfully gets the cookies named: " + currentElement);
            }
        } catch (Exception e) {
            logger.error("Failed to get the cookies named: " + currentElement);
            logger.error(getFailedstep(e));
        }
    }

    // ----------------------- CLICK on ELEMENT ---------------------------------------------
    @Then("^\"(.*?)\" hovers and clicks( and tabs-out)? on \"(.*?)\" in \"(.*?)\"$")
    public void hoversAndClicksOn(String userT, String tabOut, String offset, String pageName, DataTable locatorType) {
        int xOffset;
        int yOffset;
        String basePageName = "";
        try {
            elements = locatorType.raw();
            for (int i = 1; i < elements.size(); i++) {
                currentElement = elements.get(i).get(0);
                pageName = elements.get(i).get(3);
                if (pageName.isEmpty()) {
                    pageName = basePageName;
                } else {
                    basePageName = pageName;
                }
                xOffset = Integer.parseInt(elements.get(i).get(1));
                yOffset = Integer.parseInt(elements.get(i).get(2));
                webElement = GetPOWebElements.getBDDElement(pageName, currentElement);
                Assert.assertTrue(moveAndClick(webElement, xOffset, yOffset));
                if (tabOut != null) {
                    webElement.sendKeys(Keys.TAB);
                }
                logger.info("Successfully hovered and clicks on the element: " + currentElement);
                captureScreenShot(Constants.PASS);
            }
        } catch (Exception e) {
            logger.error("Failed to click on the element: " + currentElement);
            captureScreenShot(Constants.FAIL);
            logger.error(getFailedstep(webElement));
        }
    }

    @When("^\"(.*?)\" clicks on \"(.*?)\" having (partial-)?link text in \"(.*?)\"$")
    public void clicksLinkOnPage(String userType, String elementType, String isPartial, String pageNameCT, DataTable locatorType) {
        String basePageName = "";
        String pageName = "";
        remdriver = Constants.remdriver;
        String linkText;
        try {
            elements = locatorType.raw();
            for (int i = 1; i < elements.size(); i++) {
                linkText = elements.get(i).get(0);
                pageName = elements.get(i).get(1);
                if (pageName.isEmpty()) {
                    pageName = basePageName;
                } else {
                    basePageName = pageName;
                }
                if (isPartial.equals("partial-")) {
                    webElement = remdriver.findElement(By.partialLinkText(linkText));
                } else {
                    webElement = remdriver.findElement(By.linkText(linkText));
                }
                Assert.assertTrue(click(webElement));
                logger.info("Successfully clicked on the element: " + currentElement);
                captureScreenShot(Constants.PASS);
            }
        } catch (Exception e) {
            logger.error("Failed to click on the element: " + currentElement);
            captureScreenShot(Constants.FAIL);
            logger.error(getFailedstep(e));
        }
    }

    @When("^\"(.*?)\" clicks on \"(.*?)\" element( with value)?( and tabs-out)? in \"(.*?)\"( and ignore failure)?$")
    public void clicksButtonOnPage(String userType, String elementType, String value, String tabOut, String pageNameCT, String ignoreFailure, DataTable locatorType) {
        String basePageName = "";
        String pageName = "";
        remdriver = Constants.remdriver;
        String rtxvValue = null;
        if (elementType.contains("PWAGHS_Trolley")) {
            remdriver.navigate().to("https://ghs-pwa-development.mobify-storefront.com/trolley");
        } else {
            try {
                elements = locatorType.raw();
                for (int i = 1; i < elements.size(); i++) {
                    currentElement = elements.get(i).get(0);
                    if (value != null && value.equals(" with value")) {
                        rtxvValue = elements.get(i).get(1);
                        pageName = elements.get(i).get(2);
                    } else {
                        pageName = elements.get(i).get(1);
                    }
                    if (pageName.isEmpty()) {
                        pageName = basePageName;
                    } else {
                        basePageName = pageName;
                    }
                    if (value != null && value.equals(" with value")) {
                        String locatorValue = null;
                        By currentLocator;
                        if (rtxvValue.contains("$")) {
                            rtxvValue = webPropHelper.getTestDataProperty(rtxvValue);
                        }
                        locatorValue = GetPOWebElements.getBDDElementString(pageName, currentElement);
                        currentLocator = runTimeTextXpath(locatorValue, rtxvValue);
                        webElement = remdriver.findElement(currentLocator);
                    } else {
                        webElement = GetPOWebElements.getBDDElement(pageName, currentElement);
                    }
                    Assert.assertTrue(click(webElement));
                    if (tabOut != null) {
                        webElement.sendKeys(Keys.TAB);
                    }
                    logger.info("Successfully hovered and clicks on the element: " + currentElement);
                    captureScreenShot(Constants.PASS);
                }
            } catch (AssertionError ae) {
                if (ignoreFailure != null) {
                    logger.warn("Skipping click on : " + currentElement);
                } else {
                    captureScreenShot(Constants.FAIL);
                    logger.error(getFailedstep(ae.getMessage()));
                }
            } catch (Exception e) {
                if (ignoreFailure != null) {
                    logger.warn("Skipping click on : " + currentElement);
                } else {
                    logger.error("Failed to click on the element: " + currentElement);
                    captureScreenShot(Constants.FAIL);
                    logger.error(getFailedstep(currentElement));
                }
            }
        }
    }

    @And("^\"([^\"]*)\" selects the \"([^\"]*)\" in Calendar on \"([^\"]*)\"$")
    public void selectDate(String userType, String elementVerifyType, String pageNameCT, DataTable locatorType) throws InterruptedException {
        String pageName = "";
        String elementvalue;
        String link_before;
        String text_day;
        By currentLocator;
        String text_dayValue;
        remdriver = Constants.remdriver;
        try {
            elements = locatorType.raw();
            for (int i = 1; i < elements.size(); i++) {
                currentElement = elements.get(i).get(0);
                elementvalue = elements.get(i).get(1);
                link_before = elements.get(i).get(2);
                text_day = elements.get(i).get(3);
                text_dayValue = elements.get(i).get(4);
                pageName = elements.get(1).get(5);
                webElement = GetPOWebElements.getBDDElement(pageName, currentElement);

                while (!webElement.getText().equalsIgnoreCase(elementvalue)) {
                    webElement = GetPOWebElements.getBDDElement(pageName, link_before);
                    Assert.assertTrue(click(webElement));
                    webElement = GetPOWebElements.getBDDElement(pageName, currentElement);
                }
                String locatorValue = GetPOWebElements.getBDDElementString(pageName, text_day);
                currentLocator = runTimeTextXpath(locatorValue, text_dayValue);
                webElement = remdriver.findElement(currentLocator);
                Assert.assertTrue(click(webElement));
                logger.info("Successfully selects the given date");
                captureScreenShot(Constants.PASS);
            }
        } catch (Exception e) {
            logger.error("Failed to select the given date");
            captureScreenShot(Constants.FAIL);
            logger.error(getFailedstep(webElement));
        }
    }

    @When("^\"(.*?)\" scrolls to and clicks the element \"(.*?)\"( and tabs-out)? in \"(.*?)\"$")
    public void scrollAndClicksOnButtonInCheckoutPage(String scrollElementType, String targetElementType, String tabOut, String pageNameCT, DataTable locatorType) {
        WebElement scrollElement;
        WebElement targetElement;
        String scrollTo;
        String clickTo;
        String basePageName = "";
        String pageName = "";
        try {
            elements = locatorType.raw();
            for (int i = 1; i < elements.size(); i++) {
                scrollTo = elements.get(i).get(0);
                clickTo = elements.get(i).get(1);
                pageName = elements.get(i).get(2);
                if (pageName.isEmpty()) {
                    pageName = basePageName;
                } else {
                    basePageName = pageName;
                }
                scrollElement = GetPOWebElements.getBDDElement(pageName, scrollTo);
                scrollPageToWebElement(scrollElement);
                targetElement = GetPOWebElements.getBDDElement(pageName, clickTo);
                assertTrue(click(targetElement));
                if (tabOut != null) {
                    targetElement.sendKeys(Keys.TAB);
                }
                logger.info("Successfully clicks on the element: " + currentElement);
                captureScreenShot(Constants.PASS);
            }
        } catch (Exception e) {
            logger.error("Failed to click on the element: " + currentElement);
            captureScreenShot(Constants.FAIL);
            logger.error(getFailedstep(e));
        }

    }

    @Given("^\"(.*?)\" enters \"(.*?)\" click in \"(.*?)\"$")
    public void entersClickIn(String userT, String info, String pageNameCT, DataTable locatorType) {
        WebElement sendInputElement;
        WebElement clickElement;
        String inputValue = "";
        String sendInput = "";
        String clickBtn = "";
        String basePageName = "";
        String pageName = "";
        try {
            elements = locatorType.raw();
            for (int i = 1; i < elements.size(); i++) {
                sendInput = elements.get(i).get(0);
                inputValue = elements.get(i).get(1);
                clickBtn = elements.get(i).get(2);
                pageName = elements.get(i).get(3);
                if (pageName.isEmpty()) {
                    pageName = basePageName;
                } else {
                    basePageName = pageName;
                }
                scrollPageToWebElement(pageName, currentElement);

                if (info.toLowerCase().contains("credential")) {
                    inputValue = "/WEBConfig/" + inputValue;
                }
                inputValue = Utils.prepareDataString(inputValue);

                sendInputElement = GetPOWebElements.getBDDElement(pageName, sendInput);
                setInputTextWithOptions(sendInputElement, inputValue, true);
                clickElement = GetPOWebElements.getBDDElement(pageName, clickBtn);
                Assert.assertTrue(click(clickElement));
                logger.info("Successfully enters the text: " + inputValue + " and clicks on " + clickBtn);
                captureScreenShot(Constants.PASS);
            }
        } catch (Exception e) {
            logger.info("Failed to enter the text: " + inputValue + " and clicks on " + clickBtn);
            captureScreenShot(Constants.FAIL);
            logger.error(getFailedstep(e, webElement));
        }
    }

    @When("^\"(.*?)\" finds the list \"(.*?)\" & clicks on \"(.*?)\" in \"(.*?)\"$")
    public void findsListClicksIn(String userT, String listS, String indexS, String pageNameCT, DataTable locatorType) {
        String objIndexS = indexS;
        String basePageName = "";
        String pageName = "";
        try {
            elements = locatorType.raw();
            for (int i = 1; i < elements.size(); i++) {
                currentElement = elements.get(i).get(0);
                objIndexS = elements.get(i).get(1);
                pageName = elements.get(i).get(2);
                if (pageName.isEmpty()) {
                    pageName = basePageName;
                } else {
                    basePageName = pageName;
                }
                webElementLS = GetPOWebElements.getBDDElements(pageName, currentElement);
                Assert.assertTrue(clickOnButtonList(webElementLS, Integer.parseInt(objIndexS)));
                logger.info("Successfully clicks on the element: " + currentElement + " on index " + indexS);
                captureScreenShot(Constants.PASS);
            }
        } catch (Exception e) {
            logger.error("Failed to click the element: " + currentElement + " on index " + indexS);
            captureScreenShot(Constants.FAIL);
            logger.error(getFailedstep(e));
        }

    }

    @Then("^\"(.*?)\" sends keyboard action \"(.*?)\" in \"(.*?)\"$")
    public void sendsKeyboardActionIn(String userT, String actionT, String pageNameCT, DataTable locatorType) {
        String basePageName = "";
        String pageName = "";
        String objAction = "";
        try {
            elements = locatorType.raw();
            for (int i = 1; i < elements.size(); i++) {
                currentElement = elements.get(i).get(0);
                objAction = elements.get(i).get(1);
                pageName = elements.get(i).get(2);
                if (pageName.isEmpty()) {
                    pageName = basePageName;
                } else {
                    basePageName = pageName;
                }
                webElement = GetPOWebElements.getBDDElement(pageName, currentElement);
                Assert.assertTrue(sendKeyboardAction(webElement, objAction));
                logger.info("Pressed the " + objAction + " key");
                captureScreenShot(Constants.PASS);
            }
        } catch (Exception e) {
            logger.error("Failed to Press the " + objAction + " key");
            captureScreenShot(Constants.FAIL);
            logger.error(getFailedstep(e, webElement));
        }
    }

    // ----------------------- IFRAME  ---------------------------------------------
    @Then("^\"(.*?)\" switch to \"(.*?)\" iframe in \"(.*?)\"$")
    public void switchToIframe(String userType, String info, String pageNameCT, DataTable locatorType) {
        String frameName = null;
        String pageName = "";

        try {
            elements = locatorType.raw();
            for (int i = 1; i < elements.size(); i++) {
                frameName = elements.get(i).get(0);
                pageName = elements.get(i).get(1);
                Assert.assertTrue(switchToIframe(frameName, IFrame.NAME));
                logger.info("switched to iframe by name:" + frameName);
                captureScreenShot(Constants.PASS);
            }
        } catch (Exception e) {
            logger.error("Failed to switch to iframe by name:" + frameName);
            captureScreenShot(Constants.FAIL);
            logger.error(getFailedstep(e));
        }

    }

    @Then("^\"(.*?)\" switch to \"(.*?)\" iframe By id in \"(.*?)\"$")
    public void switchToIframeByID(String userType, String info, String pageNameCT, DataTable locatorType) {
        String pageName = "";
        String frameName = null;
        WebElement iframeElement;
        try {
            elements = locatorType.raw();
            for (int i = 1; i < elements.size(); i++) {
                frameName = elements.get(i).get(0);
                pageName = elements.get(i).get(1);
                iframeElement = GetPOWebElements.getBDDElement(pageName, frameName);
                Assert.assertTrue(switchToIframe(iframeElement, IFrame.ID));
                logger.info("switched to iframe by id:" + frameName);
                captureScreenShot(Constants.PASS);
            }
        } catch (Exception e) {
            logger.error("Failed to switch to iframe by id:" + frameName);
            captureScreenShot(Constants.FAIL);
            logger.error(getFailedstep(e));
        }
    }

    // ----------------------- ATTRIBUTE Validation  ---------------------------------------------
    @Then("^\"(.*?)\" verifies \"(.*?)\" (with|without) given attribute value in \"(.*?)\"$")
    public void verifiesDisplayedAttributeInPage(String userType, String element, String attType, String pageNameCT, DataTable locatorType) {
        String basePageName = "";
        String pageName = "";
        String expectedAltValue = "";
        String attributeText = null;
        String succlogmsg = "";
        String faillogmsg = "";
        try {
            elements = locatorType.raw();
            for (int i = 1; i < elements.size(); i++) {
                currentElement = elements.get(i).get(0);
                elementValue = elements.get(i).get(1).trim();
                if (attType.equals("with")) {
                    expectedAltValue = Utils.prepareDataString(elements.get(i).get(2).trim());
                    pageName = elements.get(i).get(3);
                } else {
                    pageName = elements.get(i).get(2);
                }
                if (pageName.isEmpty()) {
                    pageName = basePageName;
                } else {
                    basePageName = pageName;
                }
                webElement = GetPOWebElements.getBDDElement(pageName, currentElement);
                attributeText = getAttributeElement(webElement, elementValue);
                if (attType.equals("with")) {
                    Assert.assertEquals(attributeText, expectedAltValue);
                    succlogmsg = "Successfully verifies that the attribute:" + elementValue + " has text " + expectedAltValue;
                    faillogmsg = "Failed to verify that the attribute:" + elementValue + " has text " + expectedAltValue;
                } else {
                    Assert.assertNotNull(attributeText);
                    succlogmsg = "Successfully verifies that the attribute:" + elementValue + " is not null";
                    faillogmsg = "Failed to verify that the attribute:" + elementValue + " has not null";
                }
                logger.info(succlogmsg);
                captureScreenShot(Constants.PASS);
            }
        } catch (Exception e) {
            logger.error(faillogmsg);
            captureScreenShot(Constants.FAIL);
            logger.error(getFailedstep(e));
        }
    }


    @Then("^\"(.*?)\" verifies \"(.*?)\" size with expected size on \"(.*?)\"$")
    public void verifyTagSize(String userType, String elementType, String pageNameCT, DataTable locatorType) {
        String basePageName = "";
        String pageName = "";
        String expectedsize;
        String currentElementsize;
        List<WebElement> webElementLS1 = null;
        try {
            elements = locatorType.raw();
            for (int i = 1; i < elements.size(); i++) {
                currentElement = elements.get(i).get(0);
                expectedsize = elements.get(i).get(1);
                pageName = elements.get(i).get(2);
                if (pageName.isEmpty()) {
                    pageName = basePageName;
                } else {
                    basePageName = pageName;
                }
                webElementLS1 = GetPOWebElements.getBDDElements(pageName, currentElement);
                currentElementsize = String.valueOf(webElementLS1.size());

                assertEquals(currentElementsize, expectedsize);
                logger.info("Successfully verifies the list size with expected");
                captureScreenShot(Constants.PASS);
            }
        } catch (Exception e) {
            logger.error("Failed to verify the list size with expected");
            captureScreenShot(Constants.FAIL);
            logger.error(getFailedstep(e));
        }
    }

    @Then("^\"(.*?)\" verifies \"(.*?)\" contains \"(.*?)\" attribute in \"(.*?)\"$")
    public void verifiesContainsAttributeIn(String userType, String attributeV1, String expectedValue, String attribute1, DataTable locatorType) {
        String basePageName = "";
        String pageName = "";
        String attributeV;
        String attribute;

        try {
            elements = locatorType.raw();
            for (int i = 1; i < elements.size(); i++) {
                currentElement = elements.get(i).get(0);
                expectedValueObj = elements.get(i).get(2);
                attribute = elements.get(i).get(1);
                pageName = elements.get(i).get(3);
                if (pageName.isEmpty()) {
                    pageName = basePageName;
                } else {
                    basePageName = pageName;
                }
                webElement = GetPOWebElements.getBDDElement(pageName, currentElement);
                assertTrue(checkElement(webElement, ElementStatus.IS_DISPLAYED));
                attributeV = getAttributeElement(webElement, attribute);
                if (attributeV.contains(expectedValueObj) || expectedValueObj != " null") {
                    logger.info(attributeV + "  " + doesExpected + "  " + expectedValueObj);
                } else {
                    logger.error(getFailedstep(attributeV + "  " + doesNotExpected + "  " + expectedValueObj));
                }
            }
            captureScreenShot(Constants.PASS);
        } catch (Exception e) {
            captureScreenShot(Constants.FAIL);
            logger.error(getFailedstep(e, webElement));
        }
    }

    // ----------------------- MISC  ---------------------------------------------
    @And("^performs the calculation and save into given variable$")
    public void performCalculation(DataTable attributeTable) {
        try {
            List<List<String>> attributes = attributeTable.raw();
            if (attributes.size() > 1) {
                for (int i = 1; i < attributes.size(); i++) {
                    String value1str = Utils.prepareDataString(attributes.get(i).get(0));
                    float value1 = Float.parseFloat(value1str);
                    String operator = attributes.get(i).get(1);
                    String value2str = Utils.prepareDataString(attributes.get(i).get(2));
                    float value2 = Float.parseFloat(value2str);
                    String key = attributes.get(i).get(3);
                    float result = Utils.calculateValue(value1, operator, value2);
                    contextMap.getContext().put(key, Float.toString(result));
                    logger.info("The calculation performed was: " + value1str + " " + operator + " " + value2str);
                    logger.info(result + " is now saved into the variable " + key);
                }
            }
        } catch (Exception e) {
            fail(e.getMessage());
        }
    }

    @When("^\"(.*?)\" verifies all broken link in \"(.*?)\"$")
    public void verifiesAllBrokenLink(String userType, String pageName) {
        try {
            QEBrokenURLsLinks brokenLinks = new QEBrokenURLsLinks();
            assertTrue(brokenLinks.getErrorText(), brokenLinks.getBrokenLinks());
            logger.info("Successfully verifies all the broken links");
            captureScreenShot(Constants.PASS);
        } catch (Exception e) {
            logger.error("Failed to verify all the broken links");
            captureScreenShot(Constants.FAIL);
            getFailedstep(e);
        }
    }

    @When("^\"(.*?)\" verifies all broken image in \"(.*?)\"$")
    public void verifiesAllBrokenImage(String userType, String pageName) {
        try {
            QEBrokenURLsLinks brokenLinks = new QEBrokenURLsLinks();
            assertTrue(brokenLinks.getErrorText(), brokenLinks.getBrokenImageLinks());
            logger.info("Successfully verifies all the broken images");
            captureScreenShot(Constants.PASS);
        } catch (Exception e) {
            logger.error("Failed to verify all the broken images");
            captureScreenShot(Constants.FAIL);
            getFailedstep(e);
        }
    }

    @Then("^\"(.*?)\" gets the list \"(.*?)\" text in \"(.*?)\"$")
// UNIMPLEMENTED
    public void getListTextValue(String userType, String pageNameCT, String elementTextVl, DataTable locatorType) {
        String basePageName = "";
        String pageName = "";
        int finalProductCount = 0;
        String seperatorFormat;
        String seperatorValue;
        String elementText;

        try {
            elements = locatorType.raw();
            for (int i = 1; i < elements.size(); i++) {
                currentElement = elements.get(i).get(0);
                seperatorFormat = elements.get(i).get(1);
                seperatorValue = elements.get(i).get(2);
                pageName = elements.get(i).get(3);
                if (pageName.isEmpty()) {
                    pageName = basePageName;
                } else {
                    basePageName = pageName;
                }
                if (seperatorFormat.equalsIgnoreCase("between")) {
                    webElementLS = GetPOWebElements.getBDDElements(pageName, currentElement);
                    String open = StringUtils.substringBefore(seperatorValue, ",");
                    String close = StringUtils.substringAfter(seperatorValue, ",");
                    for (WebElement element : webElementLS) {
                        elementText = getText(element);
                        elementText = StringUtils.substringBetween(elementText, open, close);
                        int productcount = Integer.parseInt(elementText);
                        finalProductCount = finalProductCount + productcount;
                    }
                }
            }
        } catch (Exception e) {
            logger.error(getFailedstep(currentElement));
        }
    }

    @Then("^\"(.*?)\" sets \"(.*?)\" for \"(.*?)\" element$")
    public void setUniqueValue(String userType, String actionType, String filedType, DataTable locatorType) {
        int expLen;
        long actualLen;
        String prefix;
        String postfix;
        String saveAs;
        String tmpString;
        try {
            elements = locatorType.raw();
            expLen = Integer.parseInt(elements.get(1).get(0).trim());
            prefix = elements.get(1).get(1).trim();
            postfix = elements.get(1).get(2).trim();
            saveAs = elements.get(1).get(3).trim();
            actualLen = Long.parseLong(Utils.getUniqueValue().trim());
            long y;
            String z = "";
            for (int i = 0; i < expLen; i++) {
                y = actualLen % 10;
                z = y + "" + z;
                actualLen = actualLen / 10;
            }
            postfix = Utils.prepareDataString(postfix);
            tmpString = prefix + z + postfix;
            contextMap.getContext().put(saveAs, tmpString);
            Hooks.scenario.write(tmpString);
        } catch (Exception e) {
            logger.error(getFailedstep(e, webElement));
        }
    }

    @When("^\"(.*?)\" scrolls to and hover on \"(.*?)\" element in \"(.*?)\"$")
    public void scrollAndHoverOnLink(String scrollElementType, String targetElementType, String pageNameCT, DataTable locatorType) {
        WebElement scrollElement;
        WebElement targetElement;
        String objscrollElementType;
        String objtargetElementType = "";
        String basePageName = "";
        String pageName = "";
        try {
            elements = locatorType.raw();
            for (int i = 1; i < elements.size(); i++) {
                objscrollElementType = elements.get(i).get(0);
                objtargetElementType = elements.get(i).get(1);
                pageName = elements.get(i).get(2);
                if (pageName.isEmpty()) {
                    pageName = basePageName;
                } else {
                    basePageName = pageName;
                }
                scrollElement = GetPOWebElements.getBDDElement(pageName, objscrollElementType);
                scrollPageToWebElement(scrollElement);
                targetElement = GetPOWebElements.getBDDElement(pageName, objtargetElementType);
                Assert.assertTrue(moveHover(targetElement));
                logger.info("successfully hovered over element: " + objtargetElementType);
                captureScreenShot(Constants.PASS);
            }
        } catch (Exception e) {
            logger.error("successfully hovered over element: " + objtargetElementType);
            captureScreenShot(Constants.FAIL);
            logger.error(getFailedstep(e, webElement));
        }
    }

    @When("^\"(.*?)\" hovers on \"(.*?)\" element in \"(.*?)\"$")
    public void hoverOnLink(String scrollElementType, String targetElementType, String pageNameCT, DataTable locatorType) {
        WebElement scrollElement;
        WebElement targetElement;
        String objtargetElementType = "";
        String basePageName = "";
        String pageName = "";
        try {
            elements = locatorType.raw();
            for (int i = 1; i < elements.size(); i++) {
                objtargetElementType = elements.get(i).get(0);
                pageName = elements.get(i).get(1);
                if (pageName.isEmpty()) {
                    pageName = basePageName;
                } else {
                    basePageName = pageName;
                }
                targetElement = GetPOWebElements.getBDDElement(pageName, objtargetElementType);
                Assert.assertTrue(moveHover(targetElement));
                logger.info("successfully hovered over element: " + objtargetElementType);
                captureScreenShot(Constants.PASS);
            }
        } catch (Exception e) {
            logger.error("successfully hovered over element: " + objtargetElementType);
            captureScreenShot(Constants.FAIL);
            logger.error(getFailedstep(e));
        }
    }

    /**
     * For examples of how to use this step Def check DateTimeAndRegex.feature file
     */
    @And("^\"([^\"]*)\" matches value with (regex|contains) and (saves|verifies) the data$")
    public void matchedValue(String user, String option, String action, DataTable locatorType) {
        try {
            elements = locatorType.raw();
            for (int i = 1; i < elements.size(); i++) {
                String text = elements.get(i).get(0);
                text = Utils.prepareDataString(text);
                String regex = elements.get(i).get(1);
                if (action.equals("saves")) {
                    String index = elements.get(i).get(2);
                    String saveAs = elements.get(i).get(3);
                    if (index.equalsIgnoreCase("ALL"))
                        if (option.equals("contains")) Utils.saveAllRegexValue(text, regex, saveAs);
                        else Utils.storeValuesWithMatchedPattern(text, regex, saveAs);
                    else if (option.equals("contains"))
                        contextMap.getContext().put(saveAs, Utils.findValueRegexAtIndex(text, regex, Integer.parseInt(index)));
                    else
                        contextMap.getContext().put(saveAs, Utils.findValuewithPatternAtIndex(text, regex, Integer.parseInt(index)));
                } else Assert.assertTrue(Utils.verfiyTextUsingRegex(text, regex));
                logger.info("Successfully verifies that text matches with " + option + " and " + action + " the data");
            }
        } catch (Exception e) {
            logger.error(getFailedstep(e));
        }
    }

    /**
     * For examples of how to use this step Def check DateTimeAndRegex.feature file
     */
    @When("^\"([^\"]*)\" creates set of random data with below format$")
    public void saveRandomValue(String userType, DataTable dataTable) {
        elements = dataTable.raw();
        for (int i = 1; i < elements.size(); i++) {
            String saveAs = elements.get(i).get(0);
            String value = elements.get(i).get(1);
            value = Utils.prepareDataString(value);
            logger.info("saveAs: " + saveAs + " value: " + value);
            if (!value.isEmpty()) contextMap.getContext().put(saveAs, value);
        }
    }

    /**
     * For examples of how to use this step Def check DateTimeAndRegex.feature file
     */
    @And("^\"([^\"]*)\" creates the Date Time pattern with below attributes$")
    public void storesTheGivenPropertyOfDateTime(String strArg1, DataTable dataTable) {
        elements = dataTable.raw();
        for (int i = 1; i < elements.size(); i++) {
            String saveAs = elements.get(i).get(0);
            String property = elements.get(i).get(1);
            String result = Utils.generateDateTimeZone(property);
            logger.info("saveAs: " + saveAs + " value: " + result);
            if (!result.isEmpty()) contextMap.getContext().put(saveAs, result);
        }
    }

    /**
     * This step def tries to locate Pagination. Ref web/Organic_PlpSortPagination_Validation.feature
     */
    @Given("^\"(.*?)\" verifies pagination in \"(.*?)\" and saves page count$")
    public void checkForPagination(String userType, String pagName) {
        String pageName = "GenericPo";

        //if showing items section found, print the  products count
        try {
            WebElement showingItems = GetPOWebElements.getBDDElement(pageName, "lnk_showingItems");
            if (checkElement(showingItems, ElementStatus.IS_DISPLAYED)) {
                String productCountInPage = Utils.findValuewithPatternAtIndex(getText(showingItems), "(?<=of)\\s*(-?\\d+(?:\\.\\d+)?)", 1);
                contextMap.getContext().put("$ProductCount", productCountInPage);
                logger.info("Total Number of Products -> " + productCountInPage);
            }
        } catch (AssertionError e) {
            logger.info("You're at Product Page.");
        }
        try {
            WebElement paginationSection = GetPOWebElements.getBDDElement(pageName, "lnk_pagination");
            if (checkElement(paginationSection, ElementStatus.IS_DISPLAYED)) {
                List<WebElement> paginationPages = GetPOWebElements.getBDDElements(pageName, "lst_pagination");
                logger.info("Pagination found [ " + paginationPages.size() + " Pages] at [ " + pagName + " ]");
                click(GetPOWebElements.getBDDElement(pageName, "lst_pagination"));
                genericPo.verifyStatusOfElementsOnPagination(1, false, true);
                int paginationMidPage = paginationPages.size() / 2;
                genericPo.verifyStatusOfElementsOnPagination(paginationMidPage, true, true);
                waitForPageLoad(remdriver);
                genericPo.verifyStatusOfElementsOnPagination(paginationPages.size(), true, false);
            }
            captureScreenShot(Constants.PASS);
        } catch (AssertionError | InterruptedException e) {
            captureScreenShot(Constants.FAIL);
            logger.info("Pagination Not found ! at [ " + pageName + " ]");
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @And("^\"([^\"]*)\" replaces the subString with given text$")
    public void replaceString(String user, DataTable dataTable) {
        String text = "";
        String regex = "";
        try {
            elements = dataTable.raw();
            for (int i = 1; i < elements.size(); i++) {

                text = Utils.prepareDataString(elements.get(i).get(0));
                regex = Utils.prepareDataString(elements.get(i).get(1));
                String replaceWith = Utils.prepareDataString(elements.get(i).get(2));
                String key = elements.get(i).get(3);

                text = text.replaceAll(regex, replaceWith).replace(" ", "");
                contextMap.getContext().put(key, text);
                logger.info("Replaced the substring with " + regex + " in text:" + text);
            }
        } catch (Exception e) {
            logger.error("Failed to Replace the substring with " + regex + " in text:" + text);
            logger.error(getFailedstep(e));
        }
    }

    @When("^\"(.*?)\" click using JavaScript on \"(.*?)\" element( and tabs-out)? in \"(.*?)\"$")
    public void clickUsingJs(String userType, String elementType, String tabOut, String pageNameCT, DataTable locatorType) {
        String basePageName = "";
        String pageName = "";
        try {
            elements = locatorType.raw();
            for (int i = 1; i < elements.size(); i++) {
                currentElement = elements.get(i).get(0);
                pageName = elements.get(i).get(1);
                if (pageName.isEmpty()) {
                    pageName = basePageName;
                } else {
                    basePageName = pageName;
                }
                WebElement webElement = GetPOWebElements.getBDDElement(pageName, currentElement);
                clickUsingJs(webElement);
                if (tabOut != null) {
                    webElement.sendKeys(Keys.TAB);
                }
            }
        } catch (Exception e) {
            logger.error(getFailedstep(e));
        }
    }

    /**
     * This stepDef can be used for closing existing tab(s) opened, (if any) in Salesforce Lightning Console Apps
     * For examples of how to use this step Def, refer CARE_ASDAC942_Case_Team_Collaboration.feature file
     */
    @When("^\"(.*?)\" clicks on all available elements in \"(.*?)\"$")
    public void clickAllAvailableElements(String userType, String pageName, DataTable locatorType) {
        String basePageName = "";
        pageName = "";
        try {
            elements = locatorType.raw();
            for (int i = 1; i < elements.size(); i++) {
                currentElement = elements.get(i).get(0);
                pageName = elements.get(i).get(1);
                if (pageName.isEmpty()) {
                    pageName = basePageName;
                } else {
                    basePageName = pageName;
                }
                while (GetPOWebElements.getBDDElements(pageName, currentElement).size() > 0) {
                    click(GetPOWebElements.getBDDElement(pageName, currentElement));
                }
            }
        } catch (Exception e) {
            logger.error(getFailedstep(e));
        }
    }

    @And("^\"(.*?)\" performs the specified operation on strings$")
    public void appendTextToVariable(String userType, DataTable dataTable) {
        elements = dataTable.raw();
        for (int i = 1; i < elements.size(); i++) {
            String result = null;
            String firstString = Utils.prepareDataString(elements.get(i).get(0));
            String operation = elements.get(i).get(1);
            String secondString = elements.get(i).get(2);
            if (!secondString.isEmpty()) {
                secondString = Utils.prepareDataString(elements.get(i).get(2));
            } else {
                if (operation.equalsIgnoreCase("substring"))
                    secondString = "0";
            }
            String fetchString = elements.get(i).get(3);
            if (!fetchString.isEmpty()) {
                fetchString = Utils.prepareDataString(elements.get(i).get(3));
            } else {
                fetchString = "0";
            }
            String saveInto = elements.get(i).get(4);

            if (Objects.nonNull(operation) && operation.equalsIgnoreCase("concat")) {
                result = Utils.concatString(firstString, secondString);
            } else if (Objects.nonNull(operation) && operation.equalsIgnoreCase("leftOf")) {
                result = Utils.leftOf(firstString, secondString, Integer.parseInt(fetchString));
            } else if (Objects.nonNull(operation) && operation.equalsIgnoreCase("rightOf")) {
                result = Utils.rightOf(firstString, secondString, Integer.parseInt(fetchString));
            } else if (Objects.nonNull(operation) && operation.equalsIgnoreCase("subString")) {
                result = Utils.subStringMethod(firstString, Integer.parseInt(secondString), Integer.parseInt(fetchString));
            } else if (Objects.nonNull(operation) && operation.equalsIgnoreCase("replace")) {
                result = Utils.replaceString(firstString, secondString, fetchString);
            }

            if (saveInto.isEmpty())
                contextMap.getContext().put(firstString, result);
            else
                contextMap.getContext().put(saveInto, result);

        }
    }

    @When("^\"(.*?)\" performs \"(.*?)\" login$")
    public void performs_login(String userType, String appKeyName) throws Throwable {
        String username = "";
        String password = "";
        try {
//            elements = locatorType.raw();
//            username = elements.get(1).get(0);
//            password = elements.get(1).get(1);
            username = Utils.prepareDataString("/WEBConfig/" + appKeyName + ".UserName.");
            password = Utils.prepareDataString("/WEBConfig/" + appKeyName + ".Password.");
            loginPage(username, password);
            waitForPageLoad(remdriver);
        } catch (Exception e) {
            logger.info("");
        }
    }

    @And("^\"([^\"]*)\" compares SavedUrl with CurrentUrl in \"([^\"]*)\"$")
    public void comparesBannerUrlWithCTAURLIn(String arg0, String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        String savedURL = contextMap.get("$CurrentURL");
        String currentURL = getCurrentPageURL();
        try {
            assertEquals(savedURL, currentURL);
            captureScreenShot(Constants.PASS);
            logger.info("User successfully verified that {} with {} ", savedURL, currentURL);
        } catch (Exception e) {
            logger.info("User Failed to verify that {} with {} ", savedURL, currentURL);
            captureScreenShot(Constants.FAIL);
            logger.error(getFailedstep(e));
        }
    }


    /**
     * Local Storage
     **/

    @And("^\"([^\"]*)\" add the following value in local storage$")
    public void localStorage(String strArg1, DataTable keys) throws Throwable {
        elements = keys.raw();
        RemoteExecuteMethod executeMethod = new RemoteExecuteMethod((RemoteWebDriver) remdriver);
        RemoteWebStorage webStorage = new RemoteWebStorage(executeMethod);
        LocalStorage storage = webStorage.getLocalStorage();

        for (int i = 1; i < elements.size(); i++) {
            String key = elements.get(i).get(0);
            String value = elements.get(i).get(1);
            storage.setItem(key, value);
        }
    }

    @Then("^\"([^\"]*)\" verifies sorting on Corporate application on the \"([^\"]*)\" using below attributes$")
    public void verifiesSortingOnCorporateApplicationOnTheUsingBelowAttributes(String user, String url, DataTable locatorType) throws Throwable {
        List<String> list = new ArrayList<>();
        List<Date> actualDateList = new ArrayList<>();
        List<Date> expectedDateList = new ArrayList<>();
        String page = null;
        String sortBy = null;
        String dataLocator = null;
        elements = locatorType.raw();
        for (int i = 1; i < elements.size(); i++) {
            String action = elements.get(i).get(3);
            if (action.equalsIgnoreCase("click")) {
                String firstElement = elements.get(i).get(0);
                String secondElement = elements.get(i).get(1);
                if (Objects.isNull(page)) {
                    page = elements.get(i).get(2);
                }
                webElement = GetPOWebElements.getBDDElement(page, firstElement);
                Assert.assertTrue(click(webElement));
                webElement = GetPOWebElements.getBDDElement(page, secondElement);
                dataLocator = webElement.getAttribute("data-locator");
                if (dataLocator.contains("sort-by")) {
                    sortBy = webElement.getAttribute("textContent");
                }
                Assert.assertTrue(click(webElement));
            } else if (action.equalsIgnoreCase("list")) {
                String currentElement = elements.get(i).get(0);
                if (Objects.isNull(page)) {
                    page = elements.get(i).get(2);
                }
                webElementLS = GetPOWebElements.getBDDElements(page, currentElement);
                for (WebElement webElementL : webElementLS) {
                    list.add(String.valueOf(webElementL.getText()));
                }
                if (list.contains("Date:")) {
                    SimpleDateFormat formatter = new SimpleDateFormat("MMMM d,yyyy", Locale.ENGLISH);
                    for (int k = 0; k < list.size(); k++) {
                        list.set(k, list.get(k).replace("Date: ", ""));
                        actualDateList.add(formatter.parse(list.get(k)));
                        expectedDateList.add(formatter.parse(list.get(k)));
                    }
                    if (Objects.nonNull(sortBy) && sortBy.equalsIgnoreCase("newest")) {
                        expectedDateList.sort(Collections.reverseOrder());
                        Assert.assertEquals(actualDateList, expectedDateList);
                    }
                    if (Objects.nonNull(sortBy) && sortBy.equalsIgnoreCase("oldest")) {
                        Collections.sort(expectedDateList);
                        Assert.assertEquals(actualDateList, expectedDateList);
                    }
                } else {
                    Assert.assertNotNull(list);
                }
            } else if (action.equalsIgnoreCase("verify")) {
                String currentElement = elements.get(i).get(1);
                currentElement = Utils.prepareDataString(currentElement);
                String key = currentElement;
                for (String str : list) {
                    str = str.toLowerCase();
                    boolean b = str.contains(key.toLowerCase());
                    Assert.assertTrue(b);
                }
            }
        }
    }

    @And("^\"([^\"]*)\" executes the following script in console and verifies the value$")
    public void jsExecutor(String strArg1, DataTable keys) throws Throwable {
        String attributeToEvaluate = null;
        String value = null;
        String scriptToExecute = null;
        elements = keys.raw();
        try {
            for (int i = 1; i < elements.size(); i++) {
                scriptToExecute = elements.get(i).get(0);
                value = elements.get(i).get(1);
                JavascriptExecutor jexecutor = (JavascriptExecutor) remdriver;
                attributeToEvaluate = (String) jexecutor.executeScript(scriptToExecute);
                logger.info("Successfully executed the script", scriptToExecute);
                assertEquals(value, attributeToEvaluate);
                logger.info("Assertion Succesfull " + value + " " + attributeToEvaluate);
            }
        } catch (Exception e) {
            logger.error("Failed to execute the script", scriptToExecute);
            captureScreenShot(Constants.FAIL);
            getFailedstep(e);
        }

    }
}
