package com.qe.test.pageobject;

import com.qe.framework.common.CommonActionHelper;
import com.qe.framework.common.GetPOWebElements;
import com.qe.framework.enums.SelectBy;
import com.qe.test.stepdefinition.web.CommonStepDef;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import static org.junit.Assert.assertEquals;

public class GenericPo extends CommonActionHelper {
    private static final Logger logger = LoggerFactory.getLogger(CommonStepDef.class);
    String objPageNameCT;
    String pageName = "GenericPo";
    private static GenericPo genericPo;

    public static GenericPo getInstance() {
        if (genericPo == null)
            genericPo = new GenericPo();
        return genericPo;
    }

    //--------------Sorting Icon in Plp---------------------------------------------------------------------------------
    @FindBy(xpath = "//button[@data-auto-id='sortByFilterButton']")
    public WebElement btn_sortInNavigationPlp;

    @FindBy(xpath = "//button[@data-auto-id='btnApply']")
    public WebElement btn_sortBtnApplyNavigation;

    @FindBy(xpath = "//button[@data-auto-id='btnClose']")
    public WebElement btn_organicCloseBtn;

    @FindBy(xpath = "//ul[@class=' co-product-list__main-cntr'][1]")
    public WebElement lst_ProductListingSection;

    @FindBy(xpath = "//span[@class='page-navigation__total-items-text']")
    public WebElement lnk_showingItems;

    @FindBy(xpath = "//div[@class='co-pagination']")
    public WebElement lnk_pagination;

    @FindBy(xpath = "//div[@class='co-pagination']//option")
    public WebElement lst_pagination;

    @FindBy(xpath = "//a[@data-auto-id='btnleft']")
    public WebElement btn_leftArrowPagination;

    @FindBy(xpath = "//a[@data-auto-id='btnright']")
    public WebElement btn_rightArrowPagination;

    @FindBy(xpath = "//select[@class='co-dropdown__select co-pagination__select']")
    public WebElement drpdw_paginationSelection;

    @FindBy(xpath = "//button[contains(@aria-label,'Reviews')]")
    public WebElement lnk_Reviews;

    @FindBy(xpath = "//div[@data-auto-id='radio-button-relevance']/label")
    public WebElement lbl_relevance;

    @FindBy(xpath = "//div[@data-auto-id='radio-button-price']/label")
    public WebElement lbl_price;

    @FindBy(xpath = "//*[@data-auto-id='radio-button-sugar']//label")
    public WebElement lbl_sugar;

    @FindBy(xpath = "//*[@data-auto-id='radio-button-salt']//label")
    public WebElement lbl_salt;

    @FindBy(xpath = "//div[@data-auto-id='radio-button-fat']/label")
    public WebElement lbl_fat;

    @FindBy(xpath = "//div[@data-auto-id='radio-button-carbohydrate']/label")
    public WebElement lbl_carbohydrate;

    @FindBy(xpath = "//*[@data-auto-id='radio-button-protein']//label")
    public WebElement lbl_protein;

    @FindBy(xpath = "//div[@data-auto-id='radio-button-fibre']/label")
    public WebElement lbl_fibre;

    @FindBy(xpath = "//div[@data-auto-id='radio-button-energy']/label")
    public WebElement lbl_energy;

    @FindBy(xpath = "//div[@data-auto-id='radio-button-saturatedfat']/label")
    public WebElement lbl_saturatedfat;


    public void verifyStatusOfElementsOnPagination(int page_number, boolean leftArrow, boolean rightArrow) {
        WebElement paginationDropdown = GetPOWebElements.getBDDElement(pageName, "drpdw_paginationSelection");
        selectBy(paginationDropdown, String.valueOf(page_number), SelectBy.TEXT);
        logger.info("We are at Page Number -> " + page_number);
        assertEquals(!leftArrow, Boolean.parseBoolean(getAttributeElement(GetPOWebElements.getBDDElement(pageName, "btn_leftArrowPagination"), "aria-disabled")));
        assertEquals(!rightArrow, Boolean.parseBoolean(getAttributeElement(GetPOWebElements.getBDDElement(pageName, "btn_rightArrowPagination"), "aria-disabled")));
    }
}