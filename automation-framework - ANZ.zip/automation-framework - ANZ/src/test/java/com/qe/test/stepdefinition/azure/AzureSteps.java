package com.qe.test.stepdefinition.azure;

import com.qe.framework.azure.AzureHelper;
import com.qe.framework.azure.AzureVault;
import com.qe.framework.common.*;
import com.qe.test.stepdefinition.web.CommonStepDef;
import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static com.qe.framework.common.Constants.*;
import static com.qe.framework.customexception.ExceptionAndErrors.getFailedstep;
import static com.qe.framework.enums.VerificationType.FILE_NAME_EXT;

public class AzureSteps extends AzureHelper {
    private static final Logger logger = LoggerFactory.getLogger(CommonStepDef.class);
    public static PropertiesHelper propHelper = PropertiesHelper.getInstance();
    List<String> oDataPropertiesToSelect = new ArrayList<>();
    FileHelper fileHelper = new FileHelper();
    CommonActionHelper commonActionHelper = new CommonActionHelper();


    @Given("^update the following keys in Azure Key-Vault$")
    public void testAzureKeyVault(DataTable dataTable) {
        boolean retVal;
        String keyName = "hypothetical-key";
        String keyValue = "hypothetical-value";
        try {
            if (driverType.equalsIgnoreCase("remote")) {
                List<List<String>> elements = dataTable.raw();
                for (int i = 1; i < elements.size(); i++) {
                    keyName = elements.get(i).get(0);
                    keyValue = Utils.prepareDataString(elements.get(i).get(1));
                    keyValue = keyValue.trim();
                    retVal = AzureVault.updateConfig(keyName, keyValue);
                    if (retVal) {
                        logger.info("The Key {} has been updated with value as {} in the Azure Key-Vault", keyName, keyValue);
                    } else {
                        logger.info("There was an error in Vault updating the Key {} with value {}", keyName, keyValue);
                    }
                }
            }
        } catch (Exception ex) {
            getFailedstep(ex.getMessage());
        }
    }

    @Given("^initialize the (container) \"(.+)\" from Azure Storage connection \"(.+)\"$")
    public void initializeAzureStorage(String clientType, String tableOrContainerName, String storageConnectionString) {
        boolean successFlag = false;
        StringBuffer localSummary = new StringBuffer();
        try {
            String connectionString;
            if (driverType.equalsIgnoreCase("local")) {
                connectionString = PropertiesHelper.getConfigPropProperty("/Azure/" + storageConnectionString.toUpperCase() + ".Storage." + targetEnvName);
            } else {
                connectionString = AzureVault.getConfig("/Azure/" + storageConnectionString.toUpperCase() + ".Storage." + targetEnvName);
            }
            Pattern ptrn = Pattern.compile("^(https:\\/\\/)?[a-z0-9]+([\\-\\.]{1}[a-z0-9]+)*\\.[a-z]{2,5}(:[0-9]{1,5})?(\\/.*)?$");
            Matcher matches = ptrn.matcher(connectionString);
            if (matches.find()) {
                connectHttpAzureBlob(connectionString, tableOrContainerName);
                successFlag = true;
            }
            if (successFlag) {
                logger.info("Connection with Azure Storage established and container is Active");
                localSummary.append(HTML.LI + "Connection with Azure Storage established and container " + tableOrContainerName + " is Active" + HTML.LI_CLOSE);
            } else {
                getFailedstep("Connection details are not correctly provided to establish connection");
                localSummary.append(HTML.LI + "Connection details are not correctly provided to establish connection" + HTML.LI_CLOSE);
            }
        } catch (Exception ex) {
            getFailedstep(ex.getMessage());
        }
        commonActionHelper.appendTextInGlobalSummary(localSummary.toString());
    }

    @Then("^(list|download) all Blob Objects from virtual path \"(.+)\" in Azure Storage$")
    public void listAllBlobObjectFromAzure(String actionName, String virtualPath) {
        try {
            listDownloadBlobObjects(actionName, virtualPath);
        } catch (Exception ex) {
            getFailedstep(ex.getMessage());
        }
    }


    @Then("^from \"(.+)\" upload (XML|JSON|CSV) Blob \"(.+)\" in path \"(.+)\" into Azure Storage$")
    public void uploadFromBlobObjectToAzure(String fromFolder, String fileFormat, String inputBlob, String
            virtualPath) {
        inputBlob = inputBlob + "." + fileFormat.trim().toLowerCase();
        try {
            uploadBlobObject(fromFolder, inputBlob, virtualPath);
        } catch (Exception ex) {
//            fail(ex.getMessage());
        }
    }

    @Then("^from \"(.+)\" folder upload (all|verified) (XML|JSON|CSV) Blobs in path \"(.+)\" into Azure Storage$")
    public void uploadFromBlobFolderToAzure(String fromFolder, String status, String fileFormat, String
            virtualPath) {
        StringBuffer localSummary = new StringBuffer();
        List<File> files = new ArrayList<File>();
        String fileName = null;
        try {
            if (status.equalsIgnoreCase("all")) {
                files = fileHelper.readFiles(TESTDATAFOLDERPATH + fromFolder, fileFormat);
            } else if (status.equalsIgnoreCase("verified")) {
                HashMap<File, String> fileStatus = (HashMap<File, String>) FileHelper.fileMap.get(FILE_NAME_EXT);
                for (Map.Entry fileStat : fileStatus.entrySet()) {
                    if (fileStat.getValue().toString().equalsIgnoreCase("pass")) {
                        files.add((File) fileStat.getKey());
                    }
                }
            }
            localSummary.append(HTML.LI + "From folder: " + fromFolder + " upload " + status + " " + fileFormat + " Blobs in path " + virtualPath + " in azure storage." + HTML.LI_CLOSE);
            localSummary.append(HTML.LI + "The uploaded are: ");
            for (File file : files) {
                fileName = file.getName().substring(0, file.getName().lastIndexOf("."));
                uploadFromBlobObjectToAzure(fromFolder, fileFormat, fileName, virtualPath);
                logger.info("Uploading file :: " + file.getName());
                localSummary.append(HTML.LI + file.getName() + ", ");
            }
            localSummary.append(HTML.LI_CLOSE);
            commonActionHelper.appendTextInGlobalSummary(localSummary.toString());
        } catch (Exception ex) {
            getFailedstep(ex.getMessage());
        }
    }


    @Then("^(poll \\d+ times|find|edit|delete) the (XML|JSON|TXT|CSV) Blob \"(.+?)\" in path \"(.+)\" from Azure Storage$")
    public void findEditBlobFromAzureStorage(String actionName, String fileType, String blobName, String
            virtualPath) {
        fileType = fileType.trim().toLowerCase();
        int loopMax = 1;
        int indx = 1;
        if (actionName.startsWith("poll")) {
            actionName = actionName.replace("poll ", "");
            actionName = actionName.replace(" times", "");
            loopMax = (Integer.parseInt(actionName) <= 0) ? 1 : Integer.parseInt(actionName);
        } else {
            loopMax = 1;
        }
        try {
            while (indx <= loopMax) {
                if (findEditDeleteRenameBlobObject(actionName, fileType, blobName, virtualPath, null)) {
                    break;
                } else if (indx == loopMax && actionName.equalsIgnoreCase("poll")) {
                    getFailedstep(blobName + " with " + fileType + " - NOT found after polling several times" + " ..... " + indx);
                }
                indx++;
                Thread.sleep(5000);
            }
        } catch (Exception ex) {
            getFailedstep(ex.getMessage());
        }
    }

    @Then("^(poll \\d+ times|find|edit|delete) the (XML|JSON|TXT|CSV) Blob \"(.+?)\" in path \"(.+)\" from Azure Storage with below metadata$")
    public void findEditBlobFromAzureStorage(String actionName, String fileType, String blobName, String
            virtualPath, DataTable dataTable) {
        fileType = fileType.trim().toLowerCase();
        int loopMax = 1;
        int indx = 1;
        if (actionName.startsWith("poll")) {
            actionName = actionName.replace("poll ", "");
            actionName = actionName.replace(" times", "");
            loopMax = (Integer.parseInt(actionName) <= 0) ? 1 : Integer.parseInt(actionName);
        } else {
            loopMax = 1;
        }
        try {
            while (indx <= loopMax) {
                if (findEditDeleteRenameBlobObject(actionName, fileType, blobName, virtualPath, dataTable)) {
                    logger.info(blobName + " with " + fileType + " - was successfully found after polling " + indx + " times");
                    break;
                } else if (indx == loopMax && actionName.equalsIgnoreCase("poll")) {
                    getFailedstep(blobName + " with " + fileType + " - NOT found after polling several times" + " ..... " + indx);
                }
                indx++;
                Thread.sleep(5000);
            }
        } catch (Exception ex) {
            getFailedstep(ex.getMessage());
        }
    }

    @Then("^(list|download) all Blob Objects from virtual path \"(.+)\" in Azure Storage with below metadata$")
    public void listAllBlobObjectFromAzure(String actionName, String virtualPath, DataTable dataTable) {
        try {
            listDownloadBlobObjectsWithMetaData(actionName, virtualPath, dataTable);
        } catch (Exception ex) {
            getFailedstep(ex.getMessage());
        }
    }
}
