package com.qe.test.stepdefinition.databases;

import com.jayway.jsonpath.JsonPath;
import com.qe.framework.common.*;
import com.qe.framework.db.helpers.SqlDatabaseManager;
import cucumber.api.DataTable;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.sql.SQLException;
import java.util.*;

import static com.qe.framework.common.Constants.RULESFILEPATH;
import static com.qe.framework.common.PropertiesHelper.contextMap;
import static com.qe.framework.enums.VerificationType.FILE_STRUCTURE;
import static org.junit.Assert.*;

public class DBStepDef {

    private static final Logger logger = LoggerFactory.getLogger(DBStepDef.class);
    public static PropertiesHelper loadProps = PropertiesHelper.getInstance();
    SqlDatabaseManager sqlDatabaseManager;
    XMLHelper xmlHelper = new XMLHelper();
    List<List<String>> attributes;
    FileHelper fileHelper = new FileHelper();
    CommonActionHelper commonActionHelper = new CommonActionHelper();

    @Given("^\"(.*?)\" connect to the \"(.*?)\" database$")
    public void connectToDatabase(String user, String dbBaseUrl) throws ClassNotFoundException {
        logger.info("Removing the result set entries from context map...");
        contextMap.getContext().keySet().removeIf(key -> key.contains("rs_"));
        logger.info("Removed the result set entries from context map");
        logger.info("Connecting to the database...");
        sqlDatabaseManager = new SqlDatabaseManager(SqlDatabaseManager.getBaseDbUrl(dbBaseUrl));
        logger.info("Connection to the database is successful...");
    }

    @When("^drop the below tables?$")
    public void dropTables(DataTable attributesTable) {
        attributes = attributesTable.raw();
        String tableName;
        for (int count = 1; count < attributes.size(); count++) {
            tableName = attributes.get(count).get(0);
            try {
                sqlDatabaseManager.executeDatabaseQuery("drop table " + tableName);
            } catch (SQLException sq) {
                logger.info("{} Successfully dropped", tableName);
            }
        }
    }

    @When("^\"(.*?)\" execute the query \"(.*?)\"( and save)?$")
    public void executeQuery(String user, String queryRef, String resultSetStoreAction) throws SQLException {
        sqlDatabaseManager.executeDatabaseQuery(loadProps.getFeedFileQueriesProperty(queryRef));
        try {
            if (resultSetStoreAction.contains("save")) {
                logger.info("Storing the result set into context map...");
                sqlDatabaseManager.storeResultSet();
                logger.info("Stored the result set records in context map");
            }
        } catch (NullPointerException e) {
            logger.info("There is no requirement of storing the result set");
        }
    }

    @When("^\"(.*?)\" execute the query \"(.*?)\" with below attributes( and save)?$")
    public void executeQuery(String user, String queryRef, String action, DataTable attributesTable) throws SQLException {
        String query = loadProps.getFeedFileQueriesProperty(queryRef);
        String queryFilterValued = sqlDatabaseManager.queryFilteredValue(query, attributesTable);
        logger.info("Query to be executed is : " + queryFilterValued);
        sqlDatabaseManager.executeDatabaseQuery(queryFilterValued);
        try {
            if (action.contains("save") || action.contains("store")) {
                logger.info("Storing the result set into context map...");
                sqlDatabaseManager.storeResultSet();
                logger.info("Stored the result set records in context map");
            }
        } catch (NullPointerException e) {
            logger.info("There is no requirement of storing the result set");
        }
    }

    @Then("^\"(.*?)\" close the database connection$")
    public void closeDatabaseConnection(String user) throws SQLException {
        sqlDatabaseManager.closeDatabaseConnection();
    }

    @And("^Get the record count$")
    public int getRecordCount() throws SQLException {
        logger.info("Fetching result set record count...");
        int recordCount = sqlDatabaseManager.getRowsCount();
        logger.info("Result set record count is : " + recordCount);
        return recordCount;
    }

    @And("^Get the column count$")
    public int getColumnCount() throws SQLException {
        logger.info("Fetching result set column count...");
        int columnCount = sqlDatabaseManager.getColumnsCount();
        logger.info("Result set column count is : " + columnCount);
        return columnCount;
    }


    @Then("^\"(.*?)\" verifies the record count is (\\d+)$")
    public void verifyRecordCount(String user, int recordCount) throws SQLException {
        logger.info("Verifying result set record count...");
        assertEquals(getRecordCount(), recordCount);
        logger.info("Verified!!! Result set record count is : " + recordCount);
    }

    @Then("^\"(.*?)\" verifies the column count is (\\d+)$")
    public void verifyColumnCount(String user, int columnCount) throws SQLException {
        logger.info("Verifying result set column count...");
        assertEquals(getColumnCount(), columnCount);
        logger.info("Verified!!! Result set column count is : " + columnCount);
    }

    @Then("^\"(.*?)\" verifies the data is (null|not null) in query result for below attributes:$")
    public void verifyQueryResultSet(String user, String action, DataTable attributesTable) {
        String compareKey = null;
        attributes = attributesTable.raw();
        Set<String> keySet = contextMap.getContext().keySet();
        List<String> listOfKeys = new ArrayList<String>(keySet);

        for (int count = 0; count < attributes.size(); count++) {
            compareKey = "rs_" + attributes.get(count).get(0);
            for (int i = 0; i < listOfKeys.size(); i++) {
                if (listOfKeys.get(i).contains(compareKey)) {
                    if (action.equalsIgnoreCase("not null")) {
                        assertTrue("Context map value of key " + listOfKeys.get(i) + " is Null",
                                contextMap.getContext().get(listOfKeys.get(i)).length() > 0);
                        logger.info("Verified!!! Context map value of key " + listOfKeys.get(i) + " is not Null");
                    } else if (action.equalsIgnoreCase("null")) {
                        assertTrue("Context map value of key " + listOfKeys.get(i) + " is not Null",
                                contextMap.getContext().get(listOfKeys.get(i)).length() <= 0);
                        logger.info("Verified!!! Context map value of key " + listOfKeys.get(i) + " is Null");
                    }
                }
            }
        }
    }

    @Then("^\"(.*?)\" verifies the below column values:$")
    public void verifyColumnValue(String user, DataTable attribute) {
        String expectedValue = "";
        String currentElement = "";
        String operator = null;
        try {
            attributes = attribute.raw();
            for (int i = 1; i < attributes.size(); i++) {
                currentElement = "rs_" + attributes.get(i).get(0);
                expectedValue = attributes.get(i).get(1);
                operator = attributes.get(i).get(2);
                Utils.stringComparisonByOperator(operator, contextMap.getContext().get(currentElement), expectedValue);
            }
        } catch (Exception e) {
            logger.error("Issue is verifying the column value with provided condition" + e.getMessage());
        }
    }

    @When("^\"(.*?)\" loads the (all|csv|xml) files from directory \"(.*?)\" and execute the queries( in batch| separately)? on table \"(.*?)\" using rules \"(.*?)\"$")
    public void loadAllFileAndExecuteQuery(String user, String allFiles, String directory, String action, String tableName, String rulesJson) throws Exception {
        /*Checking if execution result folder is present or not.
		If No, it will create the folder.
		If Yes, it will delete all the files present in the folder. */
        rulesJson = rulesJson + ".json";
        sqlDatabaseManager.createFeedFileExecutionResultDirectory(Constants.FEEDFILEEXECUTIONFAILUREFOLDERPATH);
        sqlDatabaseManager.createFeedFileExecutionResultDirectory(Constants.FEEDFILEEXECUTIONSUCCESSFOLDERPATH);
        sqlDatabaseManager.createFeedFileExecutionResultDirectory(Constants.FEEDFILEEXECUTIONNEUTRALFOLDERPATH);
        File directoryPath = new File(Constants.FEEDFILEINPUTFOLDERPATH + directory);
        rulesJson = xmlHelper.readFileAsString(Constants.RULESFILEPATH + rulesJson);
        List<File> filesList = new ArrayList<>();
        filesList = Arrays.asList(Objects.requireNonNull(directoryPath.listFiles()));
        for (File file : filesList) {
            if (allFiles.equalsIgnoreCase("csv") || allFiles.equalsIgnoreCase("all")) {
                if (fileHelper.getFileExtension(file).equalsIgnoreCase("csv")) {
                    sqlDatabaseManager.loadCSVAndExecuteQuery(file, action, tableName, rulesJson);
                }
            }
            if (allFiles.equalsIgnoreCase("xml") || allFiles.equalsIgnoreCase("all")) {
                if (fileHelper.getFileExtension(file).equalsIgnoreCase("xml")) {
                    sqlDatabaseManager.loadXMLAndExecuteBatchQuery(file, action, tableName, rulesJson);
                }
            }
        }
    }

    @When("^\"(.*?)\" loads the valid files and execute the queries( in batch)? on table \"(.*?)\" using rules \"(.*?)\"$")
    public void loadAllFileAndExecuteQuery(String user, String action, String tableName, String rulesJson) throws Exception {
        /*Checking if execution result folder is present or not.
		If No, it will create the folder.
		If Yes, it will delete all the files present in the folder. */
        rulesJson = rulesJson + ".json";
        sqlDatabaseManager.createFeedFileExecutionResultDirectory(Constants.FEEDFILEEXECUTIONFAILUREFOLDERPATH);
        sqlDatabaseManager.createFeedFileExecutionResultDirectory(Constants.FEEDFILEEXECUTIONSUCCESSFOLDERPATH);
        sqlDatabaseManager.createFeedFileExecutionResultDirectory(Constants.FEEDFILEEXECUTIONNEUTRALFOLDERPATH);
        rulesJson = xmlHelper.readFileAsString(Constants.RULESFILEPATH + rulesJson);
        List<File> filesList = new ArrayList<>();
        HashMap<File, String> fileStatus = (HashMap<File, String>) FileHelper.fileMap.get(FILE_STRUCTURE);
        for (Map.Entry fileStat : fileStatus.entrySet()) {
            if (fileStat.getValue().toString().equalsIgnoreCase("pass")) {
                filesList.add((File) fileStat.getKey());
            }
        }
        for (File file : filesList) {
            if (fileHelper.getFileExtension(file).equalsIgnoreCase("csv")) {
                sqlDatabaseManager.loadCSVAndExecuteQuery(file, action, tableName, rulesJson);
            }
            if (fileHelper.getFileExtension(file).equalsIgnoreCase("xml")) {
                sqlDatabaseManager.loadXMLAndExecuteBatchQuery(file, action, tableName, rulesJson);
            }
        }
    }

    @When("^\"([^\"]*)\" loads the (all|csv|xml) files from directory \"([^\"]*)\" and execute the queries( in batch| separately)? on multiple table using rules \"([^\"]*)\" and below data$")
    public void loadAllFileAndExecuteQueryInMultipleTable(String user, String allFiles, String directory, String action, String rulesJson, List<List<String>> tableNames) throws Exception {
        rulesJson = rulesJson + ".json";
        int length = tableNames.size();
        ArrayList<String> tableColumnList = new ArrayList<>();
        for (int i = 1; i < length; i++) {
            tableColumnList.add(tableNames.get(i).get(0));
            tableColumnList.add(tableNames.get(i).get(1));
        }
        sqlDatabaseManager.createFeedFileExecutionResultDirectory(Constants.FEEDFILEEXECUTIONFAILUREFOLDERPATH);
        sqlDatabaseManager.createFeedFileExecutionResultDirectory(Constants.FEEDFILEEXECUTIONSUCCESSFOLDERPATH);
        sqlDatabaseManager.createFeedFileExecutionResultDirectory(Constants.FEEDFILEEXECUTIONNEUTRALFOLDERPATH);
        rulesJson = xmlHelper.readFileAsString(Constants.RULESFILEPATH + rulesJson);
        File directoryPath = new File(Constants.FEEDFILEINPUTFOLDERPATH + directory);
        List<File> filesList;
        filesList = Arrays.asList(Objects.requireNonNull(directoryPath.listFiles()));
        for (File file : filesList) {
            if (allFiles.equalsIgnoreCase("csv") || allFiles.equalsIgnoreCase("all")) {
                if (fileHelper.getFileExtension(file).equalsIgnoreCase("csv")) {
                    sqlDatabaseManager.loadCSVAndExecuteQueryMultipleTable(file, action, tableColumnList, rulesJson);
                }
            }
            if (allFiles.equalsIgnoreCase("xml") || allFiles.equalsIgnoreCase("all")) {
                if (fileHelper.getFileExtension(file).equalsIgnoreCase("xml")) {
                    sqlDatabaseManager.loadXMLAndExecuteBatchQueryMultipleTable(file, action, tableColumnList, rulesJson);
                }
            }
        }
    }


    @When("^\"(.*?)\" verifies the updated record count$")
    public void verifyUpdatedRecordsCount(String user) throws SQLException {
        sqlDatabaseManager.verifyRecordCount();
    }

    @When("^\"(.*?)\" verifies the columns in table \"(.*?)\" against rule \"(.*?)\"$")
    public void verifyColumnNamesInTable(String user, String tableName, String rulesFile) throws SQLException {
        try {
            rulesFile = rulesFile + ".json";
            String query = loadProps.getFeedFileQueriesProperty("tmpl_selectQuery");
            query = query.replaceAll("\\{", "")
                    .replaceAll("\\}", "")
                    .replace("$tableName", tableName);
            sqlDatabaseManager.executeDatabaseQuery(query);
            rulesFile = xmlHelper.readFileAsString(Constants.RULESFILEPATH + rulesFile);
            logger.info("Verifying result set columns...");
            assertEquals(sqlDatabaseManager.processColumnTypeToDataTypeMapping(sqlDatabaseManager.getColumnType()), xmlHelper.getColumnDataTypeFromRules(rulesFile));
            logger.info("Verified!!! Result set columns.");
        } catch (Exception e) {
            logger.error(e.getMessage());
            fail();
        }
    }

    @When("^\"(.*?)\" (slow|fast) compares data in \"(.*?)\" with data inserted in table \"(.*?)\" with raw data against rule \"(.*?)\"$")
    public void compareRawAndTableData(String user, String process, String directory, String tableName, String rulesFile) throws SQLException {
        try {
            File directoryPath = new File(Constants.FEEDFILEINPUTFOLDERPATH + directory);
            List<File> filesList = new ArrayList<>();
            rulesFile = rulesFile + ".json";
            String fileName = null;
            filesList = Arrays.asList(Objects.requireNonNull(directoryPath.listFiles()));
            for (File file : filesList) {
                fileName = file.getName();
                fileName = fileName.substring(0, fileName.indexOf("."));
                if (process.equalsIgnoreCase("slow")) {
                    sqlDatabaseManager.slowCompareDBRecord(rulesFile, fileName, tableName);
                } else if (process.equalsIgnoreCase("fast")) {
                    sqlDatabaseManager.fastCompareDBRecord(rulesFile, fileName, tableName);
                }
            }
            logger.info("Data comparison successful for files against inserted records in table :: " + tableName);
        } catch (Exception e) {
            commonActionHelper.appendTextInGlobalSummary(e.getMessage());
            logger.error(e.getMessage());
        }
    }

    private void createTableDefinition(String tableName, String rulesFile, List<List<String>> dTable) {
        StringBuffer localSummary = new StringBuffer();
        String mappingRule = null;

        rulesFile = rulesFile + ".json";
        rulesFile = xmlHelper.readFileAsString(Constants.RULESFILEPATH + rulesFile);
        Map<String, String> columnList = xmlHelper.getColumnDataTypeFromRules(rulesFile);
        List<String> primaryKeyColumns = xmlHelper.getPrimaryKeyColumnsFromRules(rulesFile);
        if (PropertiesHelper.getConfigPropProperty("dbType").equalsIgnoreCase("mysql")) {
            mappingRule = "mysql-mapping.json";
        }
        File ruleFile = new File(RULESFILEPATH + mappingRule);
        String ruleJson = xmlHelper.readFileAsString(ruleFile.getPath());
        Map<String, Object> jsonObject = JsonPath.read(ruleJson, "$");

        int imaxLoop;

        if (Objects.isNull(dTable)) {
            imaxLoop = 1;

        } else {
            imaxLoop = dTable.size();
        }

        for (int indx = 1; indx <= imaxLoop; indx++) {
            String query = loadProps.getFeedFileQueriesProperty("tmpl_createTable");
            try {
                StringBuilder columns = new StringBuilder();
                for (Map.Entry<String, String> column : columnList.entrySet()) {
                    String clmn = "";
                    for (Map.Entry<String, Object> mapNode : jsonObject.entrySet()) {
                        if (mapNode.getKey().equalsIgnoreCase(column.getValue())) {
                            List<String> datatype = (List<String>) mapNode.getValue();
                            clmn = column.getKey() + " " + datatype.get(0);
                            break;
                        }
                    }
                    if (primaryKeyColumns.contains(column.getKey())) {
                        clmn = clmn + " primary key";
                    }
                    //if dTable and col name is present in the list
                    if (dTable != null) {
                        String columnName = dTable.get(indx).get(1);
                        String[] columnsList = columnName.split(",");
                        int size = Utils.ifAnyItemsMatchInTargetList(clmn.substring(0, clmn.indexOf(" ")), Arrays.asList(columnsList));
                        if (size > 0)
                            columns.append(clmn).append(",");
                    } else if (tableName != null) {
                        columns.append(clmn).append(",");
                    }

                }
                columns = new StringBuilder(columns.toString().replace("VARCHAR", "VARCHAR(255)"));
                columns = new StringBuilder(columns.substring(0, columns.lastIndexOf(",")));
                localSummary.append("\n").append(columns).append(HTML.LI_CLOSE);

                if (dTable != null) {
                    tableName = dTable.get(indx).get(0);
                }
                query = query.replace("{", "")
                        .replace("}", "")
                        .replace("$tableName", tableName);
                localSummary.append(HTML.LI + "Creates table: ").append(tableName).append(" from rules: ").append(rulesFile).append(" with columns: ");
                query = query.replace("$columnName", columns.toString());
                SqlDatabaseManager.getStatement().execute(query);
                logger.info(tableName + " Table created successfully.");
                commonActionHelper.appendTextInGlobalSummary(localSummary.toString());
            } catch (Exception e) {
                commonActionHelper.appendTextInGlobalSummary(HTML.BR + HTML.ERROR + e.getMessage() + HTML.ERROR_CLOSE + HTML.HR);
                logger.error(e.getMessage());
            }
        }

    }

    @When("^\"(.*?)\" creates table using the below attributes and rule \"(.*?)\"$")
    public void createTableUsingRulesDataTable(String user, String rulesFile, List<List<String>> dTable) throws
            SQLException {
        createTableDefinition(null, rulesFile, dTable);
    }

    @When("^\"(.*?)\" creates table \"(.*?)\" using rule \"(.*?)\"$")
    public void createTableUsingRules(String user, String tableName, String rulesFile) throws SQLException {
        createTableDefinition(tableName, rulesFile, null);
    }

    @And("^\"([^\"]*)\" reads data from database view and validate against rule$")
    public void readsDataFromDatabaseViewWriteItInCSVAndValidateAgainstRule(String adminUser, DataTable dataTable) throws Throwable {
        List<List<String>> dTable = dataTable.raw();
        for (int i = 1; i < dTable.size(); i++) {
            String table = dTable.get(i).get(0);
            String rulesJson = dTable.get(i).get(1);
            commonActionHelper.appendTextInGlobalSummary(HTML.TABLE + HTML.TR + HTML.TH + "Reads data from database view/table: " + table + " and validate against rule: " + rulesJson + HTML.TH_CLOSE + HTML.TR_CLOSE);
            sqlDatabaseManager.fetchRecordFromDB(table, rulesJson);
        }
    }

    @Then("^\"([^\"]*)\" reads data from table-view and compare (with transformation )?using below datatable$")
    public void readsDataFromTableAndViewAndCompareAgainstRuleUsingBelowDatatable(String adminUser, String transfrom, DataTable dataTable) throws Throwable {
        List<List<String>> dTable = dataTable.raw();
        for (int i = 1; i < dTable.size(); i++) {
            String table = dTable.get(i).get(0);
            String view = dTable.get(i).get(1);
            String rulesJson = dTable.get(i).get(2);

            sqlDatabaseManager.readsDataFromTableAndViewCompare(table, view, rulesJson, transfrom);
        }

    }


}