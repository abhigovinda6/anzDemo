package com.qe.test.stepdefinition.api;

import com.qe.framework.api.helpers.APIHelper;
import com.qe.framework.common.Constants;
import com.qe.framework.common.ContextMap;
import com.qe.framework.customexception.ExceptionAndErrors;
import com.qe.test.stepdefinition.web.CommonStepDef;
import cucumber.api.java.en.Then;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class CommonResponseStepDef extends APIHelper {
    private static final Logger logger = LoggerFactory.getLogger(CommonResponseStepDef.class);
    private static CommonResponseStepDef objcom = null;
    String apiBaseUrl = null;
    APIHandlingStepDef api = new APIHandlingStepDef();
    CommonStepDef commonStepDef = new CommonStepDef();
    ContextMap cookie = new ContextMap();
    String cookieValue = null;

    public static CommonResponseStepDef getInstance() {
        if (objcom == null)
            objcom = new CommonResponseStepDef();
        return objcom;
    }


    @Then("^\"(.*?)\" gets a cookie by name \"(.*?)\"$")
    public void getCookieValueFromResponse(String user, String cookieName) {
        try {
            if (response != null) {
                cookie.put(cookieName, response.cookie(cookieName));
                logger.info("Cookie Value : " + cookie.get(cookieName));
            } else {
                logger.warn("Response is null");
            }
        } catch (Exception e) {
            ExceptionAndErrors.getAPIFailedstep(e.getMessage());
        }
    }

    @Then("^\"(.*?)\" gets all cookies$")
    public void getCookieValueFromResponse(String user) {
        try {
            if (response != null) {
                cookie.putAll(response.getCookies());
                logger.debug("Cookie values : " + cookie.getContext());
            } else {
                logger.warn("Response is null");
            }
        } catch (Exception e) {
            ExceptionAndErrors.getAPIFailedstep(e.getMessage());
        }
    }

    @Then("^\"(.*?)\" saves response in file \"(.*?)\" in \"(.*?)\" folder$")
    public void savesResponseInFile(String user, String fileName, String folder) throws IOException {
        String path = "";
        String[] locationParam = folder.split("-");
        if (locationParam[0].equalsIgnoreCase("api")) {
            if (locationParam[1].equalsIgnoreCase("Request"))
                path = Constants.JSONREQUESTFOLDERPATH;
            else if (locationParam[1].equalsIgnoreCase("Response"))
                path = Constants.JSONRESPONSEFOLDERPATH;
            else {
                path = Constants.JSONEXTERNALFOLDERPATH;
            }
        } else {
            path = Constants.JSONEXTERNALFOLDERPATH;
        }


        File directory = new File(path);
        if (!directory.exists()) {
            directory.mkdir();
            logger.info("Directory created : " + directory.getName());
        }
        FileWriter responseWriter = new FileWriter(path + fileName + ".json");
        try {
            String json = getApiResponse();
            responseWriter.write(json);
            logger.info(fileName + ".json created.");
        } catch (Exception e) {
            ExceptionAndErrors.getAPIFailedstep(e.getMessage());
        } finally {
            try {
                responseWriter.flush();
                responseWriter.close();
            } catch (Exception e) {
                ExceptionAndErrors.getAPIFailedstep(e.getMessage() + " FileName::" + fileName);
            }

        }
    }

}


