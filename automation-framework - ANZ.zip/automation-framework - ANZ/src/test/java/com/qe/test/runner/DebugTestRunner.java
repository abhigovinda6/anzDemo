package com.qe.test.runner;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)

@CucumberOptions
        (features = "src/test/resources/features/SAMPLES",
                tags = {"~@norun"},
                glue = "com.qe.test.stepdefinition",
                monochrome = true,
                plugin = {"pretty", "html:target/cucumber-reports/cucumber-html-reports", "json:target/cucumber-reports/cucumber-html-reports/common.json"}
        )
public class DebugTestRunner {

}
