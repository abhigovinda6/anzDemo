package QualityGate;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.json.simple.parser.ParseException;
import org.junit.Test;
import org.junit.platform.runner.JUnitPlatform;
import org.junit.runner.RunWith;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;

import static com.qe.framework.common.Constants.USERDIR;
import static java.lang.System.out;
import static org.junit.Assert.assertTrue;

@RunWith(JUnitPlatform.class)
public class QualityGateProcessor {

    int thisFileScenarios;
    float totalScenarios;
    float totalPassed;
    float totalFailed;

    boolean thisScenaioStatus;
    String fileContent;


    Map<String, Integer> percentRuleSet = new HashMap<>();

    Map<String, List<Integer>> percentRuleSetStats = new HashMap<String, List<Integer>>() {{
        put("p1", Arrays.asList(0, 0));
        put("p2", Arrays.asList(0, 0));
        put("p3", Arrays.asList(0, 0));
        put("p4", Arrays.asList(0, 0));
    }};

    private List<File> readFilesInFolder(String directory) {
        List<File> filesList;
        List<File> files = new ArrayList<>();
        try {
            File dir = new File(directory);
            if (dir.exists() && dir.isDirectory()) {
                filesList = Arrays.asList(Objects.requireNonNull(dir.listFiles()));
                List<File> fileLst = new ArrayList<>(filesList);
                files.addAll(fileLst);
                return files;
            }
        } catch (Exception e) {
            out.println(e.getMessage());
        }
        return Collections.emptyList();
    }

    private boolean analyzeCucumberJsonFiles(String t_percentRuleSet) throws IOException {
        List<File> files = readFilesInFolder(USERDIR + "/target/cucumber-parallel/json/");
        File gateFolder = new File(USERDIR + "/target/QualityGateStats");
        boolean statusMkDir;

        if (files.isEmpty()) {
            out.println("No cucumber files available to process");
            return false;
        }
        statusMkDir = gateFolder.mkdirs();


        List<String> optimizedList = new ArrayList<>();
        ObjectMapper objectMapper = new ObjectMapper();

        totalScenarios = 0;
        totalPassed = 0;
        totalFailed = 0;
        for (File file : files) {
            fileContent = new String(Files.readAllBytes(file.toPath()));
            fileContent = fileContent.substring(1, fileContent.length() - 1);

            JsonNode root = objectMapper.readTree(fileContent);
            thisFileScenarios = root.get("elements").size();

            for (int indx = 0; indx < thisFileScenarios; indx++) {
                JsonNode thisScenario = root.get("elements").get(indx);
                String thisScenarioKeyword = thisScenario.get("keyword").asText().toLowerCase();
                if (thisScenarioKeyword.contains("scenario")) {
                    totalScenarios++;
                    JsonNode thisScenarioAllSteps = thisScenario.get("steps");
                    JsonNode thisScenarioAllTags = thisScenario.get("tags");

                    thisScenaioStatus = true;
                    boolean thisScenarioStatus = findingThisScenarioOverallStatus(thisScenarioAllSteps);
                    findingThisScenarioPriorityStats(thisScenarioAllTags, thisScenarioStatus);
                }
            }
        }

        float totalPercentage = 0.0f;
        if (t_percentRuleSet.equalsIgnoreCase("p0=999")) {
            totalPercentage = Float.parseFloat(String.valueOf((totalPassed * 100) / totalScenarios));
        } else {
            totalScenarios = 0;
            totalPassed = 0;
            totalFailed = 0;
            float thisPercentage;
            float thisTotalScenarios;
            float thisPassedScenarios;
            for (Map.Entry<String, List<Integer>> node : percentRuleSetStats.entrySet()) {
                List<Integer> tmpVals = percentRuleSetStats.get(node.getKey());
                if (percentRuleSet.get(node.getKey()) != null) {
                    thisTotalScenarios = tmpVals.get(0);
                    thisPassedScenarios = tmpVals.get(1);
                    if (percentRuleSet.get(node.getKey()) == 0) {
                        totalPercentage = totalPercentage + 100.0f;
                    } else {
                        if (thisTotalScenarios == 0.0f) {
                            thisPercentage = 100.0f;
                        } else {
                            thisPercentage = (thisPassedScenarios / thisTotalScenarios) * 100;
                        }
                        totalScenarios = totalScenarios + thisTotalScenarios;
                        totalPassed = totalPassed + thisPassedScenarios;
                        totalFailed = totalFailed + (thisTotalScenarios - thisPassedScenarios);
//                        out.println(node.getKey() + " " + thisPassedScenarios + " " + thisTotalScenarios + " " + thisPercentage);
                        if (thisPercentage >= percentRuleSet.get(node.getKey())) {
                            totalPercentage = totalPercentage + 100.0f;
                        } else {
                            totalPercentage = totalPercentage + thisPercentage;
                        }
                    }
                }
            }
            totalPercentage = totalPercentage / percentRuleSet.size();
        }
//        All Info
//        out.println("QUALITY GATE STATS\nPercentage: " + totalPercentage + ", Total Scenarios " + totalScenarios + " Total Passed " + totalPassed + ", Total Failed " + totalFailed);
        out.println("QUALITY GATE STATS\nPercentage: " + totalPercentage);
        optimizedList.add(String.valueOf(totalPercentage));
//        optimizedList.add(String.valueOf(totalScenarios));
//        optimizedList.add(String.valueOf(totalPassed));
//        optimizedList.add(String.valueOf(totalFailed));
        writeOutputFeatureFile(gateFolder, optimizedList);
        return true;
    }

    private void findingThisScenarioPriorityStats(JsonNode thisScenarioAllTags, boolean thisScenarioStatus) {
        int thisScenarioTagsSize = thisScenarioAllTags.size();
        String thisTagName;
        int totalOfPriorityTag;
        int totalPassOfPriorityTag;
        for (int indj = 0; indj < thisScenarioTagsSize; indj++) {
            thisTagName = thisScenarioAllTags.get(indj).get("name").textValue().replace("@", "");
            if (percentRuleSet.containsKey(thisTagName)) {
                List<Integer> tmpVals = percentRuleSetStats.get(thisTagName);
                totalOfPriorityTag = tmpVals.get(0);
                totalPassOfPriorityTag = tmpVals.get(1);
                totalOfPriorityTag++;
                if (thisScenarioStatus) {
                    totalPassOfPriorityTag++;
                }
                tmpVals.set(0, totalOfPriorityTag);
                tmpVals.set(1, totalPassOfPriorityTag);
                percentRuleSetStats.put(thisTagName, tmpVals);
            }
        }
    }

    private boolean findingThisScenarioOverallStatus(JsonNode thisScenarioAllSteps) {
        int thisScenrioStepsSize = thisScenarioAllSteps.size();
        String thisStepStatus;
        for (int indj = 0; indj < thisScenrioStepsSize; indj++) {
            thisStepStatus = thisScenarioAllSteps.get(indj).get("result").get("status").textValue();
            if (!thisStepStatus.equalsIgnoreCase("passed")) {
                thisScenaioStatus = false;
                break;
            }
        }
        if (thisScenaioStatus) {
            totalPassed++;
        } else {
            totalFailed++;
        }
        return thisScenaioStatus;
    }

    private void updatePercentRuleSetWithUserRuleSet(String t_percentRuleSet) {
        String[] ary_percentRuleSet = t_percentRuleSet.split(",");

        String[] itm;
        for (String aryItm : ary_percentRuleSet) {
            itm = aryItm.split("=");
            percentRuleSet.put(itm[0], Integer.parseInt(itm[1]));
        }
    }


    private void writeOutputFeatureFile(File gateFolder, List<String> optimizedList) {
        Path outputFile = Paths.get(gateFolder + File.separator + "QualityGate.txt");
        try {
            Files.write(outputFile, optimizedList);
            out.println("Successfully written " + outputFile.getFileName());
        } catch (Exception e) {
            out.println(e.getMessage());
        }
    }

    @Test
    public void analyzeQualityGateStats() throws IOException, ParseException {
        String t_percentRuleSet;
        t_percentRuleSet = System.getProperty("ruleset");
        if (t_percentRuleSet == null || t_percentRuleSet.equalsIgnoreCase("{overall}")) {
            t_percentRuleSet = "{p0=999}";
        }
        t_percentRuleSet = t_percentRuleSet.replaceAll("[^p0-9=,]+", "");
        updatePercentRuleSetWithUserRuleSet(t_percentRuleSet);
        boolean getAnalyzeStatus = analyzeCucumberJsonFiles(t_percentRuleSet);
        assertTrue(getAnalyzeStatus);
    }
}
