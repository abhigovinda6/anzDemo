package com.qe.framework.common;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.jayway.jsonpath.JsonPath;
import com.qe.framework.api.helpers.APIHelper;
import com.qe.framework.enums.VerificationType;
import net.minidev.json.JSONArray;
import org.json.XML;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.*;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import static com.qe.framework.common.Constants.FEEDFILEREPORTS_DATAQUALITY;
import static com.qe.framework.common.Constants.RULESFILEPATH;
import static com.qe.framework.customexception.ExceptionAndErrors.getFailedstep;
import static com.qe.framework.enums.VerificationType.DATA_QUALITY;
import static com.qe.framework.enums.VerificationType.FILE_STRUCTURE;
import static org.junit.Assert.assertEquals;

public class XMLHelper extends FileHelper {

    public static final String DOT_SQL_MAPPING = ".sql-mapping";
    public static final String OUTPUT_FILE = "OutputFile.csv";

    private static final Logger logger = LoggerFactory.getLogger(XMLHelper.class);
    static FileHelper fileHelper = new FileHelper();
    static CSVHelper csvHelper = new CSVHelper();
    APIHelper apiHelper = new APIHelper();
    LinkedHashMap<String, String> nodeValues = new LinkedHashMap<>();
    int j = 0;
    String xmlJson;
    String ruleJson;
    Map<String, Object> xmlJsonPath;
    Map<String, Object> rulesJsonPath;

    public Document loadFile(File file) {
        Document xmlDoc = null;
        try {
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            xmlDoc = dBuilder.parse(file);
            xmlDoc.getDocumentElement().normalize();
            logger.debug("Loaded {} in XML Document Builder", file.getName());
        } catch (Exception e) {
            logger.error(e.getMessage());
        }
        return xmlDoc;
    }

    public void xmlToCsv(File file) throws IOException {
        String fileName = file.getName().replace(".xml", "");
        File outPutFile = new File(FEEDFILEREPORTS_DATAQUALITY + fileName + "_" + OUTPUT_FILE);
        String path = null;
        if (outPutFile.exists()) {
            path = outPutFile.getPath();
        } else {
            File directory = new File(FEEDFILEREPORTS_DATAQUALITY);
            if (!directory.exists()) {
                directory.mkdirs();
            }
            path = outPutFile.getPath();
        }
        Document doc = loadFile(file);
        if (fileName.toLowerCase().contains("taxonomy")) {
            FeedFileParser.parseTaxonomyFileToCSV(path, doc);
        }
        else if (fileName.toLowerCase().contains("grg_products")) {
            FeedFileParser.parseProductFileToCSV(path, doc);
        }
        else if (fileName.toLowerCase().contains("grg_list_price")) {
            FeedFileParser.parsePriceFileToCSV(path, doc);
        }
        else if (fileName.toLowerCase().contains("grg_catalog")) {
            FeedFileParser.parseGeorgeTaxonomyFileToCSV(path, doc);
        }
        else if (fileName.toLowerCase().contains("ghs_product")){
            FeedFileParser.parseGHSProductFileToCSV(path, doc);
        }
        else if (fileName.toLowerCase().contains("ghs_bundle")){
            FeedFileParser.parseGHSBundleFileToCSV(path, doc);
        }
    }

    public List<String> getHeaders(Document xmlDoc) {
        NodeList headerNode = null;
        Node node = null;
        List<String> headers = new ArrayList<>();
        try {
            headerNode = xmlDoc.getElementsByTagName("Header");
            for (int i = 0; i < headerNode.getLength(); i++) {
                node = headerNode.item(i);
                if (node.getNodeType() == Node.ELEMENT_NODE) {
                    headers.add(node.getNodeValue());
                }
            }
        } catch (Exception e) {
            logger.error(e.getMessage());
        }
        return headers;
    }

    public Node getRootNode(Document xmlDoc) {
        Node rootNode = null;
        try {
            rootNode = xmlDoc.getDocumentElement();
        } catch (Exception e) {
            logger.error(e.getMessage());
        }
        assert rootNode != null;
        logger.debug("Root Node is :: {}", rootNode.getNodeName());
        return rootNode;
    }

    public void verifyHeaderCount(Document xmlDoc, int expectedHeaderCount) {
        int actualSize = 0;
        try {
            actualSize = getHeaders(xmlDoc).size();
            assertEquals(actualSize, expectedHeaderCount);
            logger.info("Header count matching with expected : {}", expectedHeaderCount);
        } catch (Exception e) {
            getFailedstep(e.getMessage() + " Header count not matching with expected : " + expectedHeaderCount + "!=" + actualSize);
        }
    }

    public String parseXMLtoJSON(File file) throws IOException {
        String jsonString = null;
        try {
            BufferedReader reader = new BufferedReader(new FileReader(file));
            String xmlText = reader.lines().collect(Collectors.joining(System.lineSeparator()));
            org.json.JSONObject json = XML.toJSONObject(xmlText);
            jsonString = json.toString();
            ObjectMapper mapper = new ObjectMapper();
            Object obj = mapper.readValue(jsonString, Object.class);
            logger.info(mapper.writerWithDefaultPrettyPrinter().writeValueAsString(obj));
        } catch (Exception e) {
            logger.error("Cannot parse {} to JSON. {}", file.getName(), e.getMessage());
            appendTextInGlobalSummary(HTML.ERROR + "Cannot parse " + file.getName() + " to JSON. " + e.getMessage());
        }
        logger.debug("{} parsed as JSON", file.getName());
        return jsonString;
    }

    public boolean checkMandatory(String xmlJson, String rulesJsonPath) {
        int i = 0;
        String mandatoryValue = null;
        String mandatoryRule = null;
        try {
            int size = 0;
            mandatoryValue = rulesJsonPath.substring(rulesJsonPath.lastIndexOf("."));
            mandatoryRule = rulesJsonPath.substring(0, rulesJsonPath.lastIndexOf("."));
            mandatoryRule = mandatoryRule.replace("[0]", "[*]");
            try {
                JSONArray jsonArray = JsonPath.read(xmlJson, mandatoryRule);
                size = jsonArray.size();
            } catch (Exception e) {
                Map<String, String> objectMap = JsonPath.read(xmlJson, mandatoryRule);
                size = objectMap.keySet().size();
            }
            for (i = 0; i < size; i++) {
                JsonPath.read(xmlJson, mandatoryRule.replace("[*]", "[" + i + "]") + mandatoryValue);
            }
        } catch (Exception e) {
            appendTextInGlobalSummary(HTML.TR + HTML.TD + HTML.ERROR + " Failure in data at index : " + (i + 1) + " at node :: " + mandatoryRule.replace("[*]", "[" + i + "]") + mandatoryValue + HTML.TD_CLOSE + HTML.TR_CLOSE);
            logger.error(e.getMessage());
            return false;
        }
        return true;
    }

    public boolean checkAllXMLFiles(List<File> files, String rule, VerificationType checkType) {
        Map<File, String> fileStructure = new HashMap<>();
        StringBuffer localSummary = new StringBuffer();
        boolean flag = true;
        int pass = 0;
        int fail = 0;
        try {
            logger.debug("Checking all XML files against rule :: {}", rule);
            File ruleFile = new File(RULESFILEPATH + rule);
            int toggleCount = 1;
            for (File file : files) {
                xmlJson = parseXMLtoJSON(file);
                ruleJson = readFileAsString(ruleFile.getPath());
                logger.info("Checking XML file {} against rule :: {}", file.getName(), rule);
                if (checkType.equals(FILE_STRUCTURE)) {
                    appendTextInGlobalSummary(HTML.BR + HTML.LI + "<div onclick=\"myFunction('Toggle" + toggleCount + "')\">Structure Check for file :: "
                            + file.getName() + " <a href='#'>(click to view details)</a>" + HTML.DIV_CLOSE + HTML.LI_CLOSE + "<div id=\"Toggle" + toggleCount + "\" style=\"display:none\">" + HTML.TABLE);
                    flag = checkXMLFile(xmlJson, ruleJson);
                    if (flag) {
                        fileStructure.put(file, "pass");
                        pass++;
                    } else {
                        fileStructure.put(file, "fail");
                        fail++;
                    }
                    appendTextInGlobalSummary(HTML.TABLE_CLOSE + HTML.DIV_CLOSE);
//                    toggleCount++;
                } else if (checkType.equals(DATA_QUALITY)) {
                    boolean isFileStructureChecked = false;
                    if (FileHelper.fileMap.contains(FILE_STRUCTURE)) {
                        isFileStructureChecked = true;
                        if (isFileStructureChecked) {
                            HashMap<File, String> temp = (HashMap<File, String>) FileHelper.fileMap.get(FILE_STRUCTURE);
                            if (!temp.containsKey(file)) {
                                isFileStructureChecked = false;
                            }
                        }
                    }
                    if (!isFileStructureChecked) {
                        appendTextInGlobalSummary(HTML.BR + HTML.LI + "<div onclick=\"myFunction('Toggle" + toggleCount + "')\">Structure Check for file :: "
                                + file.getName() + " <a href='#'>(click to view details)</a>" + HTML.DIV_CLOSE + HTML.LI_CLOSE + "<div id=\"Toggle" + toggleCount + "\" style=\"display:none\">" + HTML.TABLE);
                        flag = checkXMLFile(xmlJson, ruleJson);
                        if (!flag) {
                            appendTextInGlobalSummary(HTML.LI + "File Structure for " + file.getName() + " invalid." + HTML.LI_CLOSE);
                            fileStructure.put(file, "fail");
                            fail++;
                            appendTextInGlobalSummary(HTML.TABLE_CLOSE + HTML.DIV_CLOSE);
                            logger.info(Utils.prepareDataString(GLOBAL_SUMMARY));
                            toggleCount++;
                            continue;
                        }
                        appendTextInGlobalSummary(HTML.TABLE_CLOSE + HTML.DIV_CLOSE);
                        logger.info(Utils.prepareDataString(GLOBAL_SUMMARY));
                    }
                    flag = checkXMLDataQuality(xmlJson, ruleJson, file.getName());
                    if (flag) {
                        fileStructure.put(file, "pass");
                        pass++;
                    } else {
                        fileStructure.put(file, "fail");
                        fail++;
                    }
                }
                toggleCount++;
            }
            if (FileHelper.fileMap.contains(checkType)) {
                fileStructure.putAll((Map<? extends File, ? extends String>) FileHelper.fileMap.get(FILE_STRUCTURE));
            }
            if (checkType.equals(FILE_STRUCTURE)) {
                appendTextInGlobalSummary(HTML.DIV_CLOSE);
            }
            FileHelper.fileMap.put(checkType, fileStructure);
            appendTextInGlobalSummary(HTML.TABLE + HTML.TR + HTML.TH + "Validating the " + checkType + " of files" + HTML.TH_CLOSE + HTML.TR_CLOSE);
            localSummary.append(HTML.TR + HTML.TD + "Total files: " + HTML.TD_CLOSE + HTML.TD).append(files.size()).append(HTML.TD_CLOSE);
            localSummary.append(HTML.TR + HTML.TD + "Passed : " + HTML.TD_CLOSE + HTML.TD).append(pass).append(HTML.TD_CLOSE);
            localSummary.append(HTML.TR + HTML.TD + "Failed : " + HTML.TD_CLOSE + HTML.TD).append(fail).append(HTML.TD_CLOSE).append(HTML.TABLE_CLOSE);

            appendTextInGlobalSummary(localSummary.toString());
        } catch (Exception e) {
            logger.error(e.getMessage());
            return false;
        }
        return flag;
    }

    public boolean checkXMLFile(String xmlJson, String ruleJson) {
        boolean flag = true;
        try {
            JSONHelper jsonHelper1 = new JSONHelper();
            JSONHelper jsonHelper2 = new JSONHelper();
            xmlJsonPath = jsonHelper1.listJsonKeyValues(xmlJson);
            rulesJsonPath = jsonHelper2.listJsonKeyValues(ruleJson);
            for (Map.Entry node : rulesJsonPath.entrySet()) {
                if (node.getKey().toString().contains("mandatory") && (boolean) node.getValue()) {
                    if (!checkMandatory(xmlJson, node.getKey().toString().replace(".mandatory", ""))) {
                        flag = false;
                    }
                }
            }
            if (flag) {
                appendTextInGlobalSummary(HTML.TR + HTML.TD + "Structure check passed for file." + HTML.TD_CLOSE + HTML.TR_CLOSE);
                logger.debug("Mandatory Value check passed for file.");
            }
        } catch (Exception e) {
            appendTextInGlobalSummary(HTML.TR + HTML.TD + "Structure check failed for file :: " + e.getMessage() + HTML.TD_CLOSE);
            logger.error("Structure check for XML file failed. {}", e.getMessage());
            return false;
        }
        return flag;
    }

    public boolean checkXMLDataQuality(String xmlJson, String ruleJson, String file) {
        boolean dataTypeFlag = true;
        boolean lengthFlag = true;
        boolean maxLengthFlag = true;
        boolean nullCheckFlag = true;
        boolean regexFlag = true;
        boolean precisionFlag = true;
        boolean status = true;
        try {
            String nodeRule;
            String checkRule = null;
            JSONHelper jsonHelper1 = new JSONHelper();
            xmlJsonPath = jsonHelper1.listJsonKeyValues(xmlJson);
            Map<String, Map<Boolean, String>> map = new HashMap<>();
            for (Map.Entry node : xmlJsonPath.entrySet()) {
                Map<Boolean, String> map1 = new HashMap<>();
                nodeRule = (String) node.getKey();
                checkRule = nodeRule;
                nodeRule = nodeRule.replaceAll("\\[\\d+\\]", "[0]");
                Map<String, Object> jsonObject = JsonPath.read(ruleJson, nodeRule);
                if (jsonObject.get("dataType") != null) {
                    dataTypeFlag = checkDataType((String) jsonObject.get("dataType"), String.valueOf(node.getValue()));
                }
                if (jsonObject.get("length") != null) {
                    lengthFlag = checkLength(Integer.parseInt(String.valueOf(jsonObject.get("length"))), String.valueOf(node.getValue()));
                }
                if (jsonObject.get("max-length") != null) {
                    maxLengthFlag = checkMaxLength(Integer.parseInt(String.valueOf(jsonObject.get("max-length"))), String.valueOf(node.getValue()));
                }
                if (jsonObject.get("null-check") != null) {
                    nullCheckFlag = nullCheck((Boolean) jsonObject.get("null-check"), String.valueOf(node.getValue()));
                }
                if (jsonObject.get("checkRegex") != null) {
                    regexFlag = checkRegex(String.valueOf(jsonObject.get("regex")), String.valueOf(node.getValue()));
                }
                if (jsonObject.get("precision-raw") != null) {
                    precisionFlag = checkPrecision((LinkedHashMap<String, Object>) jsonObject.get("precision-raw"), String.valueOf(node.getValue()));
                }
                status = dataTypeFlag && lengthFlag && maxLengthFlag && nullCheckFlag && regexFlag && precisionFlag;
                if (!status) {
                    StringBuilder s = new StringBuilder();
                    if (!dataTypeFlag) {
                        s.append("dataType" + " ");
                    }
                    if (!lengthFlag) {
                        s.append("length" + " ");
                    }
                    if (!maxLengthFlag) {
                        s.append("max-length" + " ");
                    }
                    if (!nullCheckFlag) {
                        s.append("null-check" + " ");
                    }
                    if (!regexFlag) {
                        s.append("checkRegex" + " ");
                    }
                    if (!precisionFlag) {
                        s.append("precision" + " ");
                    }
                    map1.clear();
                    map1.put(status, " failed at " + s + "," + checkRule);
                } else {
                    if (map1.containsKey(true) || map1.isEmpty()) {
                        map1.put(status, "satisfied all rules," + checkRule);
                    }
                }
                map.put(checkRule, map1);
                //logger.debug("Data Quality check for XML file failed.");
            }
            writeXMLRuleMatchingInfo("dataQuality_" + file, map);
            for (Map.Entry<String, Map<Boolean, String>> entry : map.entrySet()) {
                for (Map.Entry<Boolean, String> entry1 : entry.getValue().entrySet()) {
                    logger.info(entry1.getValue());
                }
            }
            status = dataTypeFlag && lengthFlag && maxLengthFlag && nullCheckFlag && regexFlag && precisionFlag;
        } catch (Exception e) {
            logger.error("Data Quality check for XML file failed. {}", e.getMessage());
            return false;
        }
        if (status) {
            logger.debug("Data Quality check for XML file passed.");
        }
        return (status);
    }

    public void writeXMLRuleMatchingInfo(String fileName, Map<String, Map<Boolean, String>> map) {
        String path = FEEDFILEREPORTS_DATAQUALITY;
        File directory = new File(path);
        if (!directory.exists()) {
            directory.mkdir();
            logger.info("Directory created : {}", directory.getName());
        }
        String file = fileName.substring(0, fileName.indexOf("."));
        StringBuilder stringBuffer = new StringBuilder();
        stringBuffer.append("Status,Failure,Path\n");
        for (Map.Entry<String, Map<Boolean, String>> entry : map.entrySet()) {
            for (Map.Entry<Boolean, String> entry1 : entry.getValue().entrySet()) {
                stringBuffer.append(entry1.getKey() + "," + entry1.getValue() + "," + "\n");
            }
        }
        CSVHelper cvHelper = new CSVHelper();
        cvHelper.fileWriterXLS(file, path, stringBuffer.toString());
        appendTextInGlobalSummary(HTML.LI + "The Report for data quality check of file: " + fileName + " is stored at " + path + HTML.LI_CLOSE);
    }

    public boolean checkDataType(String ruleValue, String value) {
        try {
            if (ruleValue.equalsIgnoreCase("Number")) {
                try {
                    Long.parseLong(value);
                } catch (NumberFormatException e) {
                    return false;
                }
            } else if (ruleValue.equalsIgnoreCase("Float")) {
                try {
                    Double.parseDouble(value);
                } catch (NumberFormatException e) {
                    return false;
                }
            } else {
                return true;
            }
        } catch (Exception e) {
            logger.error(e.getMessage());
            return false;
        }
        return true;
    }

    public boolean checkMaxLength(int ruleValue, String value) {
        boolean status = true;
        try {
            if (value.length() <= ruleValue) {
                return status;
            } else {
                return false;
            }
        } catch (Exception e) {
            logger.error(e.getMessage());
        }
        return false;
    }

    public boolean checkLength(int ruleValue, String value) {
        boolean status = true;
        try {
            if (value.length() == ruleValue) {
                return status;
            } else {
                return false;
            }
        } catch (Exception e) {
            logger.error(e.getMessage());
        }
        return false;
    }

    public boolean nullCheck(boolean ruleValue, String value) {
        boolean status = true;
        try {
            if (!ruleValue) {
                if (value.equalsIgnoreCase("null") && value != null && value.length() != 0) {
                    return false;
                }
            }
        } catch (Exception e) {
            logger.error(e.getMessage());
            return false;
        }
        return status;
    }

    public boolean checkRegex(String ruleValue, String value) {
        boolean status = true;
        try {
            if (!ruleValue.equalsIgnoreCase("regex pattern expected")) {
                Pattern pattern = Pattern.compile(ruleValue);
                Matcher matcher = pattern.matcher(value);
                status = matcher.matches();
                return status;
            } else {
                return true;
            }
        } catch (Exception e) {
            logger.error(e.getMessage());
        }
        return false;
    }

    public boolean checkPrecision(Map<String, Object> ruleValue, String value) {
        boolean status = true;
        try {
            if (!((boolean) ruleValue.get("rounding"))) {
                if (value.contains(".")) {
                    status = false;
                }
            }
            if (!((boolean) ruleValue.get("trailing-zero"))) {
                if (value.contains(".") && (value.charAt(value.length() - 1) == '0')) {
                    status = false;
                }
            }
            return status;
        } catch (Exception e) {
            logger.error(e.getMessage());
        }
        return false;
    }

    public Map<String, Object> filterSQLMapping(String ruleJson, String xmlJson) {
        HashMap<String, Object> csvMapping = new HashMap<>();
        try {
            JSONHelper jsonHelper1 = new JSONHelper();
            String nodePath = null;
            String columnName = null;
            Map<String, Object> ruleJsonPath = jsonHelper1.listJsonKeyValues(ruleJson);
            String columnValue = null;
            for (Map.Entry node : ruleJsonPath.entrySet()) {
                nodePath = node.getKey().toString();
                if (nodePath.contains(DOT_SQL_MAPPING) && (boolean) node.getValue()) {
                    nodePath = nodePath.substring(0, nodePath.lastIndexOf("."));
                    columnName = JsonPath.read(ruleJson, nodePath + ".csv-mapping");
                    try {
                        columnValue = JsonPath.read(xmlJson, nodePath).toString();
                    } catch (Exception e) {
                        columnValue = "";
                    }
                    csvMapping.put(columnName, columnValue);
                }
            }
        } catch (Exception e) {
            logger.error(e.getMessage());
        }
        return csvMapping;
    }

    public Map<String, Object> filterBatchSQLMapping(String ruleJson, String xmlJson, String action) {
        HashMap<String, Object> csvMapping = new HashMap<>();
        int size = 0;
        try {
            JSONHelper jsonHelper1 = new JSONHelper();
            Map<String, Object> ruleJsonPath = jsonHelper1.listJsonKeyValues(ruleJson);
            String nodePath = null;
            String columnName = null;
            for (Map.Entry node : ruleJsonPath.entrySet()) {
                nodePath = node.getKey().toString();
                if (nodePath.contains(DOT_SQL_MAPPING) && (boolean) node.getValue()) {
                    nodePath = nodePath.substring(0, nodePath.lastIndexOf("."));
                    columnName = JsonPath.read(ruleJson, nodePath + ".csv-mapping");
                    nodePath = nodePath.replace("[0]", "[*]");
                    JSONArray jsonArray = JsonPath.read(xmlJson, nodePath);
                    if (jsonArray.size() > 0) {
                        size = jsonArray.size();
                        String[] columnValues = new String[size];
                        for (int i = 0; i < size; i++) {
                            try {
                                columnValues[i] = JsonPath.read(xmlJson, nodePath.replace("[*]", "[" + i + "]")).toString();
                            } catch (Exception e) {
                                columnValues[i] = "";
                            }
                        }
                        csvMapping.put(columnName, columnValues);
                    } else {
                        nodePath = nodePath.replace("[*]", "");
                        String[] columnValues = new String[1];
                        columnValues[0] = JsonPath.read(xmlJson, nodePath).toString();
                        csvMapping.put(columnName, columnValues);
                    }
                }
            }
        } catch (Exception e) {
            logger.error(e.getMessage());
        }
        return csvMapping;
    }

    public void createDefaultRule(File ruleBasicStructure, File file, String fileName, String extension) {
        try {
            String updateRulePath;
            String nodePath;
            String jsonFile = null;
            if (file.length() == 0) {
                appendTextInGlobalSummary(HTML.LI + "File is Empty :: " + file.getName() + HTML.LI_CLOSE);
                logger.warn("File is Empty :: {}", file.getName());
                return;
            }
            if (extension.equalsIgnoreCase("xml")) {
                jsonFile = parseXMLtoJSON(file);
            } else if (extension.equalsIgnoreCase("csv")) {
                jsonFile = csvHelper.parseCSVtoJSON(file);
            }
            String ruleBasicJson = readFileAsString(ruleBasicStructure.getPath());
            JSONHelper jsonHelper = new JSONHelper();
            Map<String, Object> fileMap = jsonHelper.listJsonKeyValues(jsonFile);
            JSONParser parser = new JSONParser();
            JSONObject ruleJsonObject;
            for (Map.Entry node : fileMap.entrySet()) {
                nodePath = node.getKey().toString();
                updateRulePath = nodePath.substring(nodePath.lastIndexOf(".") + 1);
                ruleBasicJson = jsonHelper.updateJSONValue(ruleBasicJson, "csv-mapping", updateRulePath);
                ruleJsonObject = (JSONObject) parser.parse(ruleBasicJson);
                jsonFile = jsonHelper.updateJSONValue(jsonFile, nodePath, ruleJsonObject);
            }
            jsonFile = jsonHelper.beautify(jsonFile);
            jsonHelper.savesResponseInFile(fileName, jsonFile);
            appendTextInGlobalSummary(HTML.LI + "Created Rule file named: " + fileName + " from content file named: " + file.getName() + HTML.LI_CLOSE);
        } catch (Exception e) {
            appendTextInGlobalSummary(HTML.LI + "Created Rule file failed: " + fileName + " from content file named: " + file.getName() + HTML.LI_CLOSE);
            appendTextInGlobalSummary(HTML.ERROR + " " + e.getMessage());
            logger.error(e.getMessage());
        }
    }

    public List<String> getColumnFromRules(String ruleJson) {
        ArrayList<String> columns = new ArrayList<>();
        try {
            JSONHelper jsonHelper1 = new JSONHelper();
            String nodePath = null;
            String columnName = null;
            Map<String, Object> ruleJsonPath = jsonHelper1.listJsonKeyValues(ruleJson);
            for (Map.Entry node : ruleJsonPath.entrySet()) {
                nodePath = node.getKey().toString();
                if (nodePath.contains(DOT_SQL_MAPPING) && (boolean) node.getValue()) {
                    nodePath = nodePath.substring(0, nodePath.lastIndexOf("."));
                    columnName = JsonPath.read(ruleJson, nodePath + ".csv-mapping");
                    columns.add(columnName);
                }
            }
        } catch (Exception e) {
            logger.error(e.getMessage());
        }
        logger.info("Columns from rules are : {}", columns);
        return columns;
    }

    public Map<String, String> getColumnDataTypeFromRules(String ruleJson) {
        HashMap<String, String> columnsDataType = new HashMap<>();
        try {
            JSONHelper jsonHelper1 = new JSONHelper();
            String nodePath = null;
            String columnName = null;
            String dataType = null;
            Map<String, Object> ruleJsonPath = jsonHelper1.listJsonKeyValues(ruleJson);
            for (Map.Entry node : ruleJsonPath.entrySet()) {
                nodePath = node.getKey().toString();
                if (nodePath.contains(DOT_SQL_MAPPING) && (boolean) node.getValue()) {
                    nodePath = nodePath.substring(0, nodePath.lastIndexOf("."));
                    columnName = JsonPath.read(ruleJson, nodePath + ".csv-mapping");
                    dataType = JsonPath.read(ruleJson, nodePath + ".dataType");
                    columnsDataType.put(columnName, dataType);
                }
            }
        } catch (Exception e) {
            logger.error(e.getMessage());
        }
        logger.info("Columns DataType from rules are : {}", columnsDataType);
        return columnsDataType;
    }

    public List<String> getPrimaryKeyColumnsFromRules(String ruleJson) {
        ArrayList<String> columns = new ArrayList<>();
        try {
            JSONHelper jsonHelper1 = new JSONHelper();
            String nodePath = null;
            String columnName = null;
            boolean primaryKey;
            Map<String, Object> ruleJsonPath = jsonHelper1.listJsonKeyValues(ruleJson);
            for (Map.Entry node : ruleJsonPath.entrySet()) {
                nodePath = node.getKey().toString();
                if (nodePath.contains(DOT_SQL_MAPPING) && (boolean) node.getValue()) {
                    nodePath = nodePath.substring(0, nodePath.lastIndexOf("."));
                    columnName = JsonPath.read(ruleJson, nodePath + ".csv-mapping");
                    try {
                        primaryKey = JsonPath.read(ruleJson, nodePath + ".primary-key");
                        if (primaryKey) {
                            columns.add(columnName);
                        }
                    } catch (Exception e) {
                    }
                }
            }
        } catch (Exception e) {
            logger.error(e.getMessage());
        }
        logger.info("Columns from rules are : {}", columns);
        return columns;
    }

    public List<String> applyRuleOnRow(List<String> headers, List<String> rec, Map<String, Object> rulesJsonPath, String ruleJson) {
        /*
         * Required : ColumnName, Row, Rule
         * Where Column Name is same as csv_Mapping
         * Apply rule
         */
        List<String> processedRecord = new ArrayList<>();
        for (int i = 0; i < rec.size(); i++) {
            String cellValue = rec.get(i);
            processedRecord.add(i, cellValue);
            for (String rule : rulesJsonPath.keySet()) {
                if (rule.contains("csv-mapping")) {
                    String property = (String) rulesJsonPath.get(rule);
                    if (property.equals(headers.get(i).replace("\uFEFF", ""))) {
                        Map<String, Object> ruleMap = JsonPath.read(ruleJson, rule.replace(".csv-mapping", ""));
                        if (ruleMap.get("precision-db") != null) {
                            processedRecord.set(i, applyPrecision((LinkedHashMap<String, Object>) ruleMap.get("precision-db"), cellValue));
                        }
                    }
                }
            }
        }
        logger.debug("Processed record ::{}", processedRecord);
        return processedRecord;
    }

    public String applyPrecision(Map<String, Object> ruleValue, String value) {
        String processedValue = null;
        try {
            StringBuilder format = new StringBuilder("#.");
            DecimalFormat df = null;
            if (checkDataType("Float", value)) {
                double newValue = Double.parseDouble(value);
                if (ruleValue.get("rounding") != null && (boolean) ruleValue.get("rounding")) {
                    if (ruleValue.get("decimal-points") != null) {
                        int decimalPoints = (int) ruleValue.get("decimal-points");
                        for (int i = 0; i < decimalPoints; i++) {
                            format.append("#");
                        }
                        df = new DecimalFormat(format.toString());
                    }
                    if (ruleValue.get("ceiling") != null) {
                        if (ruleValue.get("ceiling").toString().equalsIgnoreCase("upper")) {
                            assert df != null;
                            df.setRoundingMode(RoundingMode.CEILING);
                        }
                        if (ruleValue.get("ceiling").toString().equalsIgnoreCase("lower")) {
                            df.setRoundingMode(RoundingMode.FLOOR);
                        }
                    }
                    assert df != null;
                    processedValue = df.format(newValue);
                }
                if (ruleValue.get("trailing-zero") != null && (boolean) ruleValue.get("trailing-zero")) {
                    StringBuilder sb = new StringBuilder(processedValue);
                    if (sb.indexOf(".") != -1) {
                        while (sb.indexOf(".") < sb.length() - 1 && sb.charAt(sb.length() - 1) == '0') {
                            sb.setLength(sb.length() - 1);
                        }
                    }
                    if (sb.indexOf(".") == sb.length() - 1) {
                        sb.setLength(sb.length() - 1);
                    }
                    processedValue = sb.toString();
                }
            }
        } catch (Exception e) {
            logger.error(e.getMessage());
        }
        return processedValue;
    }
}
