package com.qe.framework.security.helpers;

import com.qe.framework.common.CommonActionHelper;
import com.qe.framework.customexception.ExceptionAndErrors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.zaproxy.clientapi.core.ClientApiException;

public class ZapCore extends CommonActionHelper implements ZapAbstraction {

    private ZapIntegration zapApi;

    public ZapCore(ZapIntegration zapApi) {
        this.zapApi = zapApi;
    }

    private static final Logger logger = LoggerFactory.getLogger(ZapCore.class);

    public void doSpidering() throws InterruptedException {
        logger.info("Spider started.");
        int progress;
        String spiderTaskId;
        try {
            spiderTaskId = zapApi.getSpiderTaskId();

            do {
                Thread.sleep(1000);
                progress = zapApi.getSpiderProgress(spiderTaskId);

                logger.info("Spider progress : : {} %", progress);
            }
            while (progress < 100);
            logger.info("Spider complete");

        } catch (ClientApiException | InterruptedException e) {
            logger.error(ExceptionAndErrors.getFailedstep(e));

        }
    }


    public void doPassiveScan() throws ClientApiException, InterruptedException {
        logger.info("Passive scanning started.");
        int recordsToScan;
        do {
            Thread.sleep(500);
            recordsToScan = zapApi.getNumberOfUnscannedRecods();
            logger.info("There is still {} records to scan", recordsToScan);
        } while (recordsToScan != 0);
        logger.info("Passive scan completed");
    }


    public void doActiveScan() throws ClientApiException, InterruptedException {
        logger.info("Active scanning started.");
        String activeScanTaskId = zapApi.getActiveScanTaskId();
        int progress;
        do {
            Thread.sleep(3000);
            progress = zapApi.getActiveScanProgress(activeScanTaskId);
            logger.info("Active Scan progress : {} %", progress);
        } while (progress < 100);
        logger.info("Active Scan complete");
    }
}


