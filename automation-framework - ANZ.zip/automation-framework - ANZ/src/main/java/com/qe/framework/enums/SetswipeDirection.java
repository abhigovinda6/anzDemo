package com.qe.framework.enums;

public enum SetswipeDirection {
    UP,
    DOWN,
    LEFT,
    RIGHT;
}
