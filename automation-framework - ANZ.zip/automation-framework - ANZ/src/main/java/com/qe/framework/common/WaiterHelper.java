package com.qe.framework.common;

import com.qe.framework.web.helpers.WebDriverHelper;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import static com.qe.framework.common.Constants.pageLoadWaitTime;

public class WaiterHelper extends WebDriverHelper {
    private static final Logger logger = LoggerFactory.getLogger(WaiterHelper.class);

    //Wait for JQuery Load
    public static void waitForJQueryLoad() {
        boolean jQueryFlag = false;
        try {
            ExpectedCondition<Boolean> pageLoadCondition = remdriver -> ((Long) ((JavascriptExecutor) remdriver).executeScript("return jQuery.active") == 0);
            WebDriverWait wait = new WebDriverWait(remdriver, pageLoadWaitTime);
            wait.until(pageLoadCondition);
            logger.debug("JQuery is Ready!");
            jQueryFlag = true;
        } catch (Exception e) {
            logger.error("JQuery Wait exception msg::{}", e.getMessage());
        }
        logger.debug("JQuery wait time seconds: {} :: isPageLoaded: {}", pageLoadWaitTime, jQueryFlag);
    }


    //    ::FUTURE::
    //Wait for Angular Load
    public static void waitForAngularLoad() {
        boolean angularFlag = false;
        String angularReadyScript = "return angular.element(document).injector().get('$http').pendingRequests.length === 0";
        try {
            ExpectedCondition<Boolean> pageLoadCondition = remdriver -> Boolean.valueOf(((JavascriptExecutor) remdriver).executeScript(angularReadyScript).toString());
            WebDriverWait wait = new WebDriverWait(remdriver, pageLoadWaitTime);
            wait.until(pageLoadCondition);
            logger.debug("ANGULAR is Ready!");
            angularFlag = true;
        } catch (Exception e) {
            logger.error("ANGULAR Wait exception msg:: {}", e.getMessage());
        }
        logger.debug("ANGULAR wait time seconds: {} :: isPageLoaded: {}", pageLoadWaitTime, angularFlag);
    }

    //Wait Until JS Ready
    public static void waitUntilJSReady() {
        boolean pageLoadwaitFlag = false;
        try {
            ExpectedCondition<Boolean> pageLoadCondition = remdriver -> ((JavascriptExecutor) remdriver).executeScript("return document.readyState").equals("complete");
            WebDriverWait wait = new WebDriverWait(remdriver, pageLoadWaitTime);
            wait.until(pageLoadCondition);
            pageLoadwaitFlag = true;
        } catch (Exception e) {
            logger.error("Page Load Wait exception msg:: {}", e.getMessage());
        }
        logger.debug("Page load wait time seconds: {} :: isPageLoaded: {}", pageLoadWaitTime, pageLoadwaitFlag);
    }

    //Wait Until JQuery and JS Ready
    public static void waitUntilJQueryReady() {
        JavascriptExecutor jsExec = (JavascriptExecutor) remdriver;

        //First check that JQuery is defined on the page. If it is, then wait AJAX
        boolean jQueryDefined = (Boolean) jsExec.executeScript("return typeof jQuery != 'undefined'");
        if (jQueryDefined) {
            //Wait JQuery Load
            waitForJQueryLoad();

            //Wait JS Load
            waitUntilJSReady();
        } else {
            logger.debug("jQuery is not defined on this site!");
        }
    }

    //Wait Until Angular and JS Ready
    public static void waitUntilAngularReady() {
        JavascriptExecutor jsExec = (JavascriptExecutor) remdriver;

        //First check that ANGULAR is defined on the page. If it is, then wait ANGULAR
        boolean angularUnDefined = (Boolean) jsExec.executeScript("return window.angular === undefined");
        if (!angularUnDefined) {
            boolean angularInjectorUnDefined = (boolean) jsExec.executeScript("return angular.element(document).injector() === undefined");
            if (!angularInjectorUnDefined) {
                //Wait Angular Load
                waitForAngularLoad();

                //Wait JS Load
                waitUntilJSReady();

            } else {
                logger.debug("Angular injector is not defined on this site!");
            }
        } else {
            logger.debug("Angular is not defined on this site!");
        }
    }

    //Wait Until JQuery Angular and JS is ready
    public static void waitJQueryAngular() {
        waitUntilJQueryReady();
        waitUntilAngularReady();
    }

    public static void sleep(Integer seconds) throws InterruptedException {
        long secondsLong = seconds;
        Thread.sleep(secondsLong);
    }
}
