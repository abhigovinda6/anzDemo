package com.qe.framework.customexception;

public class AtmJiraException extends Exception {

    private static final long serialVersionUID = 1L;

    public AtmJiraException(String message) {
        super(message);
    }

}
