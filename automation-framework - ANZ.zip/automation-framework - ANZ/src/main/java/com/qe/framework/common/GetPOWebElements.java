package com.qe.framework.common;

import com.qe.framework.customexception.ExceptionAndErrors;
import com.qe.framework.enums.LocatorTypeEnum;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

import static com.qe.framework.common.CommonActionHelper.executeJS;
import static com.qe.framework.common.CommonActionHelper.fluentwaitForElement;
import static org.junit.Assert.assertTrue;

public class GetPOWebElements {

    private GetPOWebElements() {
        throw new IllegalStateException("Utility class");
    }

    private static final Logger logger = LoggerFactory.getLogger(GetPOWebElements.class);
    private static final String COM_QE_TEST_PAGEOBJECT = "com.qe.test.pageobject.";
    private static final String WEB_ELEMENT = "WebElement [";
    private static final String CANNOT_RETRIVE = "]  can't be retrieved. Might be Incorrect locator type or Element is not persent in object repository.";

    public static WebElement getBDDElement(String pageName, String currentElement) {
        WebDriver remdriver = Constants.remdriver;

        WebElement webElement = null;
        Class<?> className = null;

        try {
            className = Class.forName(COM_QE_TEST_PAGEOBJECT + pageName);
        } catch (ClassNotFoundException e) {
            logger.debug("The class {} isn't available on classpath", pageName);
            logger.error(e.getMessage());
            ExceptionAndErrors.getFailedstep(e);
        }
        try {
            By locator = getFindByLocatorFromAnnotaion(className, currentElement);
            if (Utils.isWebTest(null)) {
                assertTrue(fluentwaitForElement(locator));
            } else {
                Thread.sleep(2000);
            }
            webElement = remdriver.findElement(locator);
        } catch (IllegalArgumentException | NoSuchFieldException | SecurityException e) {
            logger.debug("WebElement {} can't be retrieved. Incorrect locator passed.", currentElement);
            logger.error(e.getMessage());
            throw new IllegalArgumentException(WEB_ELEMENT + currentElement + CANNOT_RETRIVE);
        } catch (Exception e) {
            ExceptionAndErrors.getFailedstep(e, webElement);
        }
        if (Utils.isWebTest(null)) {
            executeJS("arguments[0].style.border='2px solid blue'", webElement);
        }
        return webElement;
    }

    public static List<WebElement> getBDDElements(String pageName, String currentElement) throws InterruptedException {
        WebDriver remdriver = Constants.remdriver;
        List<WebElement> webElement = null;
        Class<?> className = null;

        try {
            className = Class.forName(COM_QE_TEST_PAGEOBJECT + pageName);
        } catch (ClassNotFoundException e) {
            logger.debug("The class {} isn't available on classpath", pageName);
            logger.error(e.getMessage());
            ExceptionAndErrors.getFailedstep(e);
        }
        try {
            By locator = getFindByLocatorFromAnnotaion(className, currentElement);
            webElement = remdriver.findElements(locator);
            Thread.sleep(1000);
        } catch (IllegalArgumentException | NoSuchFieldException | SecurityException e) {
            logger.debug("WebElement {} can't be retrieved. Incorrect locator passed.", currentElement);
            logger.error(e.getMessage());
            throw new IllegalArgumentException(WEB_ELEMENT + currentElement + CANNOT_RETRIVE);
        } catch (NoSuchElementException e) {
            ExceptionAndErrors.getFailedstep(e);
        }

        return webElement;
    }

    public static By getBDDByElement(String pageName, String currentElement) {
        Class<?> className = null;
        By locator = null;

        try {
            className = Class.forName(COM_QE_TEST_PAGEOBJECT + pageName);
        } catch (ClassNotFoundException e) {
            logger.debug("The class {} isn't available on classpath", pageName);
            logger.error(e.getMessage());
        }
        try {
            assert className != null;
            locator = getFindByLocatorFromAnnotaion(className, currentElement);

        } catch (IllegalArgumentException | NoSuchFieldException | SecurityException e) {
            logger.debug("WebElement can't be retrieved. Incorrect locator passed.");
            logger.error(e.getMessage());
            throw new IllegalArgumentException("WebElement can't be retrieved");
        }
        return locator;
    }

    public static String getBDDElementString(String pageName, String currentElement) {
        WebElement webElement = null;
        String typeofLocator = null;
        Class<?> className = null;
        try {
            className = Class.forName(COM_QE_TEST_PAGEOBJECT + pageName);
        } catch (ClassNotFoundException e) {
            logger.debug("The class {} isn't available on classpath", pageName);
            logger.error(e.getMessage());
            ExceptionAndErrors.getFailedstep(e);
        }
        if (className == null) {
            throw new IllegalArgumentException("Please create the relevant PO class. ClassName is null");
        }
        try {
            FindBy annotationValue = className.getField(currentElement).getAnnotation(FindBy.class);
            typeofLocator = annotationValue.xpath();

        } catch (IllegalArgumentException | NoSuchFieldException | SecurityException e) {
            logger.debug("WebElement {} can't be retrieved. Incorrect locator passed.", currentElement);
            logger.error(e.getMessage());
            throw new IllegalArgumentException(WEB_ELEMENT + currentElement + CANNOT_RETRIVE);
        } catch (Exception e) {
            ExceptionAndErrors.getFailedstep(e, webElement);
        }

        return typeofLocator;
    }

    // common code to this class - return By object from Annotation
    private static By getFindByLocatorFromAnnotaion(Class<?> className, String currentElement) throws NoSuchFieldException {
        String typeofLocator = null;

        FindBy annotationValue = className.getField(currentElement).getAnnotation(FindBy.class);
        int firstIndexOf = currentElement.indexOf("_");
        int lastIndexOf = currentElement.lastIndexOf("_");
        typeofLocator = (firstIndexOf != lastIndexOf
                ? currentElement.substring(lastIndexOf + 1).trim()
                : lastIndexOf != -1 ? "xpath" : null);

        By locator = null;
        LocatorTypeEnum ltEnum = LocatorTypeEnum.valueOf(typeofLocator);
        switch (ltEnum) {
            case id:
                locator = By.id(annotationValue.id());
                break;
            case name:
                locator = By.name(annotationValue.name());
                break;
            case css:
                locator = By.cssSelector(annotationValue.css());
                break;
            case linkText:
                locator = By.linkText(annotationValue.linkText());
                break;
            case partialLinkText:
                locator = By.partialLinkText(annotationValue.partialLinkText());
                break;
            case tagName:
                locator = By.tagName(annotationValue.tagName());
                break;
            case xpath:
                locator = By.xpath(annotationValue.xpath());
                break;
            case className:
                locator = By.className(annotationValue.className());
                break;
            default:
                locator = By.xpath(annotationValue.xpath());
                break;
        }
        return locator;
    }
}
