package com.qe.framework.security.helpers;

import com.qe.framework.common.CommonActionHelper;
import com.qe.framework.common.PropertiesHelper;
import com.qe.framework.common.Utils;
import com.qe.framework.customexception.ExceptionAndErrors;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.zaproxy.clientapi.core.ApiResponse;
import org.zaproxy.clientapi.core.ApiResponseElement;
import org.zaproxy.clientapi.core.ClientApi;
import org.zaproxy.clientapi.core.ClientApiException;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

public class ZapIntegration extends CommonActionHelper {

    public PropertiesHelper webPropHelper = PropertiesHelper.getInstance();
    private final String zapAddress = PropertiesHelper.getConfigPropProperty("ZAP_ADDRESS");
    private final int zapPort = Integer.parseInt(PropertiesHelper.getConfigPropProperty("ZAP_PORT"));
    private final String zapApiKey = PropertiesHelper.getConfigPropProperty("ZAP_API_KEY");
    private static final String CONTEXTID = "1";
    private static final String CONTEXT_NAME = "Default Context";
    private static final String UTF_8 = "UTF-8";

    private String target;
    private ClientApi api;

    private static final Logger logger = LoggerFactory.getLogger(ZapIntegration.class);


    public ZapIntegration(String target) throws ClientApiException {
        this.target = target;
        api = new ClientApi(zapAddress, zapPort, zapApiKey);
        try {
            api.context.newContext(CONTEXT_NAME + "_1");
        } catch (Exception e) {
            logger.info("Context already exists");
        }
        api.context.includeInContext(CONTEXT_NAME + "_1", target + ".*");
    }

    public int getSpiderProgress(String taskId) {
        String status = null;
        try {
            status = ((ApiResponseElement) api.spider.status(taskId)).getValue();

        } catch (ClientApiException e) {
            logger.error(ExceptionAndErrors.getFailedstep(e));

        }
        return Integer.parseInt(status);
    }

    public int getActiveScanProgress(String taskId) {
        String status = null;
        try {
            status = ((ApiResponseElement) api.ascan.status(taskId)).getValue();

        } catch (ClientApiException e) {
            logger.error(ExceptionAndErrors.getFailedstep(e));

        }
        return Integer.parseInt(status);
    }

    public int getNumberOfAlerts() throws ClientApiException {
        return Integer.parseInt(((ApiResponseElement) api.core.numberOfAlerts(target)).getValue());
    }

    public int getNumberOfUnscannedRecods() throws ClientApiException {
        return Integer.parseInt(((ApiResponseElement) api.pscan.recordsToScan()).getValue());
    }

    public String getActiveScanTaskId() throws ClientApiException {
        return ((ApiResponseElement) getScanApiResponse()).getValue();
    }

    public String getSpiderTaskId() throws ClientApiException {
        return ((ApiResponseElement) getSpideringApiResponse()).getValue();
    }

    public void generateHtmlReport(String filePath) throws IOException {
        String report;

        try (FileWriter fWriter = new FileWriter(filePath); BufferedWriter writer = new BufferedWriter(fWriter)) {
            report = new String(api.core.htmlreport(), StandardCharsets.UTF_8);
            writer.write(report);
        } catch (ClientApiException | IOException e) {
            logger.error(ExceptionAndErrors.getFailedstep(e));
        }
    }

    @SuppressWarnings("unused")
    public void printAlerts() {
        try {
            logger.info("Alerts:");
            logger.info(new String(api.core.xmlreport(), StandardCharsets.UTF_8));
        } catch (ClientApiException e) {
            logger.error(ExceptionAndErrors.getFailedstep(e));

        }
    }

    private ApiResponse getSpideringApiResponse() throws ClientApiException {
        return api.spider.scan(target, null, null, null, null);

    }

    private ApiResponse getScanApiResponse() throws ClientApiException {
        return api.ascan.scan(target, "True", "False", null, null, null);
    }

    private static void setIncludeAndExcludeInContext(ClientApi clientApi) throws UnsupportedEncodingException, ClientApiException, ClientApiException {
        String includeInContext = "http://localhost:8080/bodgeit.*";
        String excludeInContext = "http://localhost:8080/bodgeit/logout.jsp";

        clientApi.context.includeInContext(CONTEXT_NAME, includeInContext);
        clientApi.context.excludeFromContext(CONTEXT_NAME, excludeInContext);
    }


    private static void setLoggedInIndicator(ClientApi clientApi) throws UnsupportedEncodingException, ClientApiException {
        // Prepare values to set, with the logged in indicator as a regex matching the logout link
        String loggedInIndicator = "<a href=\"logout.jsp\">Logout</a>";

        // Actually set the logged in indicator
        clientApi.authentication.setLoggedInIndicator(CONTEXTID, java.util.regex.Pattern.quote(loggedInIndicator));

        // Check out the logged in indicator that is set
        logger.debug("Configured logged in indicator regex: {}",
                ((ApiResponseElement) clientApi.authentication.getLoggedInIndicator(CONTEXTID)).getValue());
    }

    private static void setFormBasedAuthenticationForBodgeit(ClientApi clientApi) throws ClientApiException,
            UnsupportedEncodingException {
        // Setup the authentication method

        String loginUrl = "http://localhost:8080/bodgeit/login.jsp";
        String loginRequestData = "username={%username%}&password={%password%}";

        // Prepare the configuration in a format similar to how URL parameters are formed. This
        // means that any value we add for the configuration values has to be URL encoded.
        StringBuilder formBasedConfig = new StringBuilder();
        formBasedConfig.append("loginUrl=").append(URLEncoder.encode(loginUrl, UTF_8));
        formBasedConfig.append("&loginRequestData=").append(URLEncoder.encode(loginRequestData, UTF_8));

        logger.info("Setting form based authentication configuration as: {}"
                , formBasedConfig);
        clientApi.authentication.setAuthenticationMethod(CONTEXTID, "formBasedAuthentication",
                formBasedConfig.toString());

        // Check if everything is set up ok
        logger.debug("Authentication config: {}", clientApi.authentication.getAuthenticationMethod(CONTEXTID).toString(0));
    }

    private static String setUserAuthConfigForBodgeit(ClientApi clientApi) throws ClientApiException, UnsupportedEncodingException {
        // Prepare info
        String user = "Test User";
        String username = "test@example.com";
        String password = "weakPassword";

        //Make sure the user is registered
        registerUser(username, password);

        // Make sure we have at least one user
        String userId = extractUserId(clientApi.users.newUser(CONTEXTID, user));

        // Prepare the configuration in a format similar to how URL parameters are formed. This
        // means that any value we add for the configuration values has to be URL encoded.
        StringBuilder userAuthConfig = new StringBuilder();
        userAuthConfig.append("username=").append(URLEncoder.encode(username, UTF_8));
        userAuthConfig.append("&password=").append(URLEncoder.encode(password, UTF_8));

        logger.debug("Setting user authentication configuration as: {}", userAuthConfig);
        clientApi.users.setAuthenticationCredentials(CONTEXTID, userId, userAuthConfig.toString());
        clientApi.users.setUserEnabled(CONTEXTID, userId, "true");
        clientApi.forcedUser.setForcedUser(CONTEXTID, userId);
        clientApi.forcedUser.setForcedUserModeEnabled(true);

        // Check if everything is set up ok
        logger.debug("Authentication config: {}", clientApi.users.getUserById(CONTEXTID, userId).toString(0));
        return userId;
    }

    public static void registerUser(String user, String password) {
        String registerUrl = "http://localhost:8080/bodgeit/register.jsp";
        remdriver.get(registerUrl);

        WebElement link = remdriver.findElement(By.name("username"));
        link.sendKeys(user);

        link = remdriver.findElement(By.name("password1"));
        link.sendKeys(password);

        link = remdriver.findElement(By.name("password2"));
        link.sendKeys(password);

        link = remdriver.findElement(By.id("submit"));
        link.click();


    }

    private static String extractUserId(ApiResponse response) {
        return ((ApiResponseElement) response).getValue();
    }

    private void scanAsUser(ClientApi clientApi, String userId) throws ClientApiException {
        clientApi.spider.scanAsUser(CONTEXTID, userId, target, null, "true", null);
    }

    public void authenticateUser() throws ClientApiException, UnsupportedEncodingException {
        ClientApi apiNew = new ClientApi(zapAddress, zapPort, zapApiKey);
        setIncludeAndExcludeInContext(apiNew);
        setFormBasedAuthenticationForBodgeit(apiNew);
        setLoggedInIndicator(apiNew);
        String userId = setUserAuthConfigForBodgeit(apiNew);
        scanAsUser(apiNew, userId);
    }


}
