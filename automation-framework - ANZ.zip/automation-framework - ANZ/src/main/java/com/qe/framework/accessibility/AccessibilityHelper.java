package com.qe.framework.accessibility;

import com.deque.axe.AXE;
import com.qe.framework.common.Constants;
import com.qe.framework.common.Utils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.openqa.selenium.WebDriver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.net.URL;
import java.util.List;

import static com.qe.framework.common.Constants.AXEFOLDERPATH;

public class AccessibilityHelper {
    private static final Logger logger = LoggerFactory.getLogger(AccessibilityHelper.class);

    public JSONArray axeProcessor(String pageName, String whichTags, List<String> tagList, List<String> impactLevelList) {
        JSONObject currObject;
        JSONArray currTags;
        String currImpactLevel;
        JSONArray finalViolations = new JSONArray();
        WebDriver remdriver;

        remdriver = Constants.remdriver;
        URL scriptUrl = AccessibilityHelper.class.getResource("/axemain/axe.min.js");
        JSONObject responseJSON = new AXE.Builder(remdriver, scriptUrl)
                .options("{runOnly: [" + whichTags + "]}").skipFrames().setTimeout(90)
//                .options("{runOnly: ['wcag2a', 'wcag2aa']}")
                .analyze();

        JSONArray violations = responseJSON.getJSONArray("violations");

        if (violations.length() == 0) {
            logger.info("No AXE Violation found on the page: {}", pageName);
        } else {
            pageName = pageName.trim();
            pageName = pageName.replaceAll("\\s+", " ");
            pageName = pageName.replace(" ", "_");
            Utils.createFolder(AXEFOLDERPATH);
            AXE.writeResults(AXEFOLDERPATH + pageName, responseJSON);

            // Cleanup the Violation that dont match the WCAG criteria

            logger.info(" TOTAL VIOLATIOS: {}", violations.length());
            for (int aryLoop = 0; aryLoop < violations.length(); aryLoop++) {
                currObject = violations.getJSONObject(aryLoop);
                currTags = currObject.getJSONArray("tags");
                currImpactLevel = currObject.getString("impact");
                logger.info(" VIOLATIOS : {}  has Tags {} : and ImpactLevel: {}", aryLoop, currTags, currImpactLevel);

                List<String> sampleList = Utils.jsonarraytostringlist(currTags);

                int resultFoundTags = 0;
                int resultFoundImpact = 0;
                resultFoundTags = Utils.countIfAnyItemsMatchInTwoLists(sampleList, tagList);
                resultFoundImpact = Utils.ifAnyItemsMatchInTargetList(currImpactLevel, impactLevelList);

                if (resultFoundImpact == 0 && resultFoundTags > 0) {
                    logger.info(" No Violations found with given Category and Impact Level");
                } else if (resultFoundTags == 0) {
                    logger.info(" No Violations found with given Category");
                } else {
                    finalViolations.put(currObject);
                    logger.info(" -------------->>> ADDED");
                }
            }
        }
        return finalViolations;
    }

}