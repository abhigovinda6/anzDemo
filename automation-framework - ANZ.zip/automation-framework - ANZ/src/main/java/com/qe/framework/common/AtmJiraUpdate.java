package com.qe.framework.common;

import com.qe.framework.customexception.AtmJiraException;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class AtmJiraUpdate {

    private AtmJiraUpdate() {
        throw new IllegalStateException("Utility class");
    }
    public static void updateTestCaseStatus(String status, String testCaseId) throws AtmJiraException {
        PropertiesHelper atmJiraPropHelper = PropertiesHelper.getInstance();

        RestAssured.baseURI = atmJiraPropHelper.getJiraAtmProperty("ATM_Url");
        String testCycle = atmJiraPropHelper.getJiraAtmProperty("Test_Cycle");
        String apiKey = atmJiraPropHelper.getJiraAtmProperty("API_key");

        String requestBody = "{\n\"status\": \"" + status + "\"\n}";
        Response response = RestAssured.given().contentType(ContentType.JSON).header("Authorization", "Basic ".concat(apiKey))
                .body(requestBody)
                .post("/testrun/" + testCycle + "/testcase/" + testCaseId + "/testresult");

        if (response.getStatusCode() == 500)
            throw new AtmJiraException("Technical error: Illegal Argument is passed. Please check your authorization code.");
        else if (response.getStatusCode() == 404)
            throw new AtmJiraException(testCycle + " doesn't exist. Please verify or create a new cycle in Jira");
        else if (response.getStatusCode() == 400)
            throw new AtmJiraException(response.asString());
    }
}
