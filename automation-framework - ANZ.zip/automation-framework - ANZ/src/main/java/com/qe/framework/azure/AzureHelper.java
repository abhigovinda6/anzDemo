package com.qe.framework.azure;

import com.microsoft.azure.storage.AccessCondition;
import com.microsoft.azure.storage.CloudStorageAccount;
import com.microsoft.azure.storage.StorageException;
import com.microsoft.azure.storage.blob.*;
import com.qe.framework.common.CommonActionHelper;
import com.qe.framework.common.FileHelper;
import com.qe.framework.common.HTML;
import cucumber.api.DataTable;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.net.URI;
import java.net.URISyntaxException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static com.qe.framework.common.Constants.*;
import static com.qe.framework.customexception.ExceptionAndErrors.getFailedstep;
import static com.qe.framework.enums.VerificationType.BLOB_DOWNLOADED;
import static org.junit.Assert.assertTrue;

public class AzureHelper {
    private static final Logger logger = LoggerFactory.getLogger(AzureHelper.class);
    CommonActionHelper commonActionHelper = new CommonActionHelper();
    private CloudBlobContainer container = null;

    public void connectAzureBlob(String storageConnectionString, String containerName, String clientType) {
        CloudStorageAccount storageAccount;
        CloudBlobClient blobClient;
        container = null;
        try {
            if (clientType.equalsIgnoreCase("table")) {
                getFailedstep("The Table client in not yet implemented with Acct-Name/SAS combinations");
            } else {
                storageAccount = CloudStorageAccount.parse(storageConnectionString);
                blobClient = storageAccount.createCloudBlobClient();
                container = blobClient.getContainerReference(containerName);
            }
        } catch (StorageException ex) {
            logger.info(String.format("Error returned from the service. Http code: %d and error code: %s",
                    ex.getHttpStatusCode(), ex.getErrorCode()));
        } catch (Exception ex) {
            getFailedstep(ex.getMessage());
        }
    }

    public void connectHttpAzureBlob(String storageConnectionString, String tableOrContainerName) {

        container = null;
        try {
            storageConnectionString = storageConnectionString.replace("{containerName}", tableOrContainerName);
            container = new CloudBlobContainer(new URI(storageConnectionString));
        } catch (StorageException ex) {
            logger.info(String.format("Error returned from the service. Http code: %d and error code: %s",
                    ex.getHttpStatusCode(), ex.getErrorCode()));
        } catch (Exception ex) {
            getFailedstep(ex.getMessage());
        }
    }


    public void listDownloadBlobObjects(String actionName, String virtualPath) {
        // Listing contents of container
        StringBuilder localSummary = new StringBuilder();
        boolean actionFlag;
        String listPrefix;
        StringBuilder downloadPath = null;
        ArrayList<String> blobsDownloaded = new ArrayList<>();
        actionFlag = actionName.equalsIgnoreCase("download");
        logger.info("Printing the list of all BLOBS");
        if (actionFlag && virtualPath != null && virtualPath.length() > 0) {
            listPrefix = virtualPath;
            downloadPath = createVirtualFolders(virtualPath);
        } else {
            listPrefix = null;
        }
        try {
            localSummary.append(HTML.LI).append(Character.toUpperCase(actionName.charAt(0))).append(actionName.substring(1)).append(" all the BLOB objects and they are:").append(HTML.LI_CLOSE);
            localSummary.append(HTML.UL);
            for (ListBlobItem blobItem : container.listBlobs(listPrefix, true)) {
                logger.info("URI of blob is: {}", blobItem.getUri());
                if (actionFlag) {
                    CloudBlob blob = (CloudBlob) blobItem;
                    blob.download(new FileOutputStream(downloadPath + blob.getName().replace(virtualPath + "/", "")));
                    blobsDownloaded.add(blob.getName());
                }
                localSummary.append(HTML.LI).append(blobItem.getUri()).append(HTML.LI_CLOSE);
            }
            localSummary.append(HTML.UL_CLOSE);
            FileHelper.fileMap.put(BLOB_DOWNLOADED, blobsDownloaded);
            commonActionHelper.appendTextInGlobalSummary(localSummary.toString());
        } catch (StorageException ex) {
            logger.info(String.format("Error returned from the service. Http code: %d and error code: %s",
                    ex.getHttpStatusCode(), ex.getErrorCode()));
        } catch (Exception ex) {
            getFailedstep(ex.getMessage());
        }
    }


    private StringBuilder createVirtualFolders(String rawVirtualPath) {
        String[] virtualPaths = rawVirtualPath.split("/");
        File folder;
        StringBuilder bld = new StringBuilder();
        bld.append(DOWNLOADFEEDSFOLDERPATH);
        for (String vpath : virtualPaths) {
            String dynaPath = bld.toString();
            folder = new File(dynaPath + File.separator + vpath);
            if (!folder.exists()) {
                folder.mkdirs();
            }
            bld.append(vpath + File.separator);
        }
        return bld;
    }

    public void uploadBlobObject(String fromFolder, String blobName, String
            virtualPath) throws
            IOException, URISyntaxException, StorageException {
        CloudBlockBlob cBlob;

        if (fromFolder == null) {
            fromFolder = "";
        } else {
            fromFolder = fromFolder + File.separator;
        }
        File sourceFile = new File(TESTDATAFOLDERPATH + fromFolder + blobName);
        //create the TEMP folder if it doesnt exist
        File folder;
        folder = new File(TESTDATAFOLDERPATH + "Temp");
        if (!folder.exists()) {
            folder.mkdirs();
        }
        File destinationFile = null;
        destinationFile = new File(TESTDATAFOLDERPATH + "Temp");
        deleteDirectory(destinationFile);

        destinationFile = new File(TESTDATAFOLDERPATH + TEMPUNDERFOLDERPATH + blobName);

        Files.copy(sourceFile.toPath(), destinationFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
        boolean anySuccess = destinationFile.renameTo(new File(TESTDATAFOLDERPATH + TEMPUNDERFOLDERPATH + blobName));
        assertTrue(anySuccess);
        sourceFile = new File(TESTDATAFOLDERPATH + TEMPUNDERFOLDERPATH + blobName);

        FileHelper fileHelper = new FileHelper();
        String processedPayload = fileHelper.readFileAsString(sourceFile.getAbsolutePath());
        FileWriter fileAppend = new FileWriter(sourceFile, false);
        try (Writer outFile = new BufferedWriter(fileAppend)) {
            outFile.write(processedPayload);
        }

        if (virtualPath != null) {
            cBlob = container.getBlockBlobReference(virtualPath + "/" + sourceFile.getName());
        } else {
            cBlob = container.getBlockBlobReference(sourceFile.getName());
        }
        // uploading file as Blob
        AccessCondition accessCondition = AccessCondition.generateIfNotModifiedSinceCondition(new Date());
        try {
            if (sourceFile.getName().toLowerCase().contains(".json")) {
                cBlob.getProperties().setContentType("application/json");
            } else if (sourceFile.getName().toLowerCase().contains(".xml")) {
                cBlob.getProperties().setContentType("application/xml");
            } else if (sourceFile.getName().toLowerCase().contains(".txt")) {
                cBlob.getProperties().setContentType("text/csv");
            }
            logger.info("Attempting to upload the Blob {}", sourceFile.getName());
            cBlob.uploadFromFile(sourceFile.getAbsolutePath(), accessCondition, null, null);
            logger.info("The specified blob {} has been uploaded", sourceFile.getName());
        } catch (StorageException storageException) {
            getFailedstep("Exception while uploading Blob file. -->\n" + storageException.getMessage());
        }
        Files.deleteIfExists(sourceFile.toPath());
        sourceFile = null;
    }

    public void deleteDirectory(File directoryToBeDeleted) throws IOException {
        File[] allContents = directoryToBeDeleted.listFiles();
        if (allContents != null) {
            for (File file : allContents) {
                Files.delete(file.toPath());
            }
        }
    }

    private void renameBlobFile(String virtualPath, CloudBlob downBlob, String toBlobName, String fileType) throws
            URISyntaxException, StorageException {
        String virtualPathSep = "/";
        String newFileName = virtualPath + virtualPathSep + toBlobName + "." + fileType;
        CloudBlockBlob newBlob = container.getBlockBlobReference(newFileName);
        if (!newBlob.exists()) {
            newBlob.startCopy(downBlob.getUri());
            logger.info("The specified blob {} exists now", newBlob.getName());
            downBlob.deleteIfExists();
        }
    }

    private String findFastSearchFrag(String virtualPath, String blobName, String fileType) {
        String fastSearchFrag;
        int lenBlob = blobName.length();
        if (lenBlob < 6) {
            fastSearchFrag = virtualPath + "/" + blobName + "." + fileType;
        } else {
            fastSearchFrag = virtualPath + "/" + blobName;
        }
        return fastSearchFrag;
    }

    private boolean processBlobMeta(DataTable attributesTable, CloudBlob downBlob) {
        boolean blobProcessed = false;
        if (attributesTable != null && !downBlob.getMetadata().isEmpty()) {
            List<List<String>> attributes = attributesTable.raw();
            for (int i = 1; i < attributes.size(); i++) {
                List<String> dataRow = attributes.get(i);
                blobProcessed = downBlob.getMetadata().get(dataRow.get(0)).equals(dataRow.get(1));
            }
        } else if (attributesTable != null && downBlob.getMetadata().isEmpty()) {
            getFailedstep("Implementation TBD - Failing at the moment since META was never fulfilled at Azure");
        }
        return blobProcessed;
    }

    private void editAndUploadBlobFile(CloudBlob downBlob, String blobName, String virtualPath, DataTable attributesTable) {
        FileWriter fileAppend = null;
        try {
            downBlob.download(new FileOutputStream(DOWNLOADFEEDSFOLDERPATH + File.separator + downBlob.getName()));
            File sourceFile = new File(DOWNLOADFEEDSFOLDERPATH + File.separator + downBlob.getName());
            fileAppend = new FileWriter(sourceFile, true);
            try (Writer outFile = new BufferedWriter(fileAppend)) {
                outFile.append(' ');
            }
            CloudBlockBlob upBlob = container.getBlockBlobReference(virtualPath + "/" + sourceFile.getName());
            upBlob.uploadFromFile(sourceFile.getAbsolutePath());
            logger.info("Blob name: {} successfully edited and uploaded", blobName);
        } catch (Exception e) {
            getFailedstep("Found the given Blob name: " + blobName + " but it could not be edited or uploaded");
        }
    }

    private void blobNewEditCharter(CloudBlob downBlob, String blobName, String virtualPath, DataTable attributesTable) {
        createVirtualFolders(virtualPath);
        editAndUploadBlobFile(downBlob, blobName, virtualPath, attributesTable);
    }

    private void blobEditDeleteRenameCharter(String actionName, CloudBlob downBlob, String toBlobName, String
            fileType, String virtualPath) throws StorageException, URISyntaxException {
        if (actionName.equalsIgnoreCase("rename")) {
            renameBlobFile(virtualPath, downBlob, toBlobName, fileType);
        } else if (actionName.equalsIgnoreCase("delete")) {
            toBlobName = downBlob.getName();
            downBlob.deleteIfExists();
            logger.info("Successfully deleted the Blob: {}", toBlobName);
        }
    }

    private void reckonFoundBlobObject(String actionName, boolean foundFlag, boolean blobProcessed, String fileType, String
            blobName, String whichState) {
        if (!actionName.equalsIgnoreCase("poll")) {
            if (foundFlag) {
                if (blobProcessed) {
                    logger.info("Successfully Found Blob name: {} as {}, in Processed state", blobName, fileType);
                } else {
                    logger.info("Successfully Found Blob name: {} as {}", blobName, fileType);
                }
            } else {
                if (whichState != null && whichState.equalsIgnoreCase("unavailable")) {
                    logger.info(" {} as {} was not found as expected", blobName, fileType);
                } else {
                    getFailedstep(String.format("The given Blob name: %s as %s was not found", blobName, fileType));
                }
            }
        }
    }

    public boolean findEditDeleteRenameBlobObject(String actionName, String fileType, String blobName, String
            virtualPath, DataTable attributesTable) throws
            StorageException, URISyntaxException {
        CloudBlob downBlob = null;
        boolean foundFlag = false;
        boolean blobProcessed = false;
        String fastSearchFrag;
        fastSearchFrag = findFastSearchFrag(virtualPath, blobName, fileType);
        for (ListBlobItem blobItem : container.listBlobs(fastSearchFrag, true)) {
            downBlob = (CloudBlob) blobItem;
            if (downBlob.getName().contains(blobName) && downBlob.getName().contains(fileType)) {
                downBlob.downloadAttributes();
                blobProcessed = processBlobMeta(attributesTable, downBlob);
                foundFlag = true;
                break;
            }
        }
        if (foundFlag && !actionName.equalsIgnoreCase("poll")) {
            if (actionName.equalsIgnoreCase("edit")) {
                blobNewEditCharter(downBlob, null, virtualPath, attributesTable);
            } else {
                blobEditDeleteRenameCharter(actionName, downBlob, blobName, fileType, virtualPath);
            }
        }
        reckonFoundBlobObject(actionName, foundFlag, blobProcessed, fileType, blobName, "nothing");
        return foundFlag;
    }

    public void listDownloadBlobObjectsWithMetaData(String actionName, String virtualPath, DataTable attributesTable) {
        // Listing contents of container
        boolean actionFlag;
        String listPrefix;
        StringBuilder downloadPath = null;
        StringBuilder localSummary = new StringBuilder();
        ArrayList<String> blobsDownloaded = new ArrayList<>();
        localSummary.append(HTML.LI).append(Character.toUpperCase(actionName.charAt(0))).append(actionName.substring(1)).append(" all the BLOB objects and they are:").append(HTML.LI_CLOSE);
        actionFlag = actionName.equalsIgnoreCase("download");
        logger.info("Printing the list of all BLOBS");
        if (actionFlag && virtualPath != null && virtualPath.length() > 0) {
            listPrefix = virtualPath;
            downloadPath = createVirtualFolders(virtualPath);
        } else {
            listPrefix = null;
        }
        try {
            localSummary.append(HTML.UL);
            for (ListBlobItem blobItem : container.listBlobs(listPrefix, true)) {
                logger.info("URI of blob is: {}", blobItem.getUri());
                localSummary.append(HTML.LI + blobItem.getUri() + HTML.LI_CLOSE);
                if (actionFlag) {
                    CloudBlob blob = (CloudBlob) blobItem;
                    blob.downloadAttributes();
                    if (processBlobMeta(attributesTable, blob)) {
                        blob.download(new FileOutputStream(downloadPath + blob.getName().replace(virtualPath + "/", "")));
                        blobsDownloaded.add(blob.getName());
                    }
                }
            }
            localSummary.append(HTML.UL_CLOSE);
            FileHelper.fileMap.put(BLOB_DOWNLOADED, blobsDownloaded);
            commonActionHelper.appendTextInGlobalSummary(localSummary.toString());
        } catch (StorageException ex) {
            logger.info(String.format("Error returned from the service. Http code: %d and error code: %s",
                    ex.getHttpStatusCode(), ex.getErrorCode()));
        } catch (Exception ex) {
            getFailedstep(ex.getMessage());
        }
    }
}