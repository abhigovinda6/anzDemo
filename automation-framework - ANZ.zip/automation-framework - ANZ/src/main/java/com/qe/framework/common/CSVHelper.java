package com.qe.framework.common;

import com.jayway.jsonpath.JsonPath;
import com.qe.framework.enums.VerificationType;
import org.apache.commons.collections.map.HashedMap;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.apache.commons.io.FilenameUtils;
import org.apache.poi.ss.usermodel.ConditionalFormattingRule;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.PatternFormatting;
import org.apache.poi.ss.usermodel.SheetConditionalFormatting;
import org.apache.poi.ss.util.CellRangeAddressList;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.json.CDL;
import org.json.JSONArray;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.util.*;

import static com.qe.framework.common.Constants.*;
import static com.qe.framework.customexception.ExceptionAndErrors.getFailedstep;
import static com.qe.framework.enums.VerificationType.DATA_QUALITY;
import static com.qe.framework.enums.VerificationType.FILE_STRUCTURE;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class CSVHelper extends CommonActionHelper {

    private static final Logger logger = LoggerFactory.getLogger(CSVHelper.class);
    private static final String UFEFF = "\uFEFF";
    private static final String MANDATORY = "mandatory";
    private static final String PRECISION_RAW = "precision-raw";
    private static final String LENGTH = "length";
    private static final String DATA_TYPE = "dataType";
    private static final String HAS = " has ";
    private static final String DOT_CSV_MAPPING = ".csv-mapping";
    private static final String SLASH_D = "_\\d+";
    private static final String CSV_MAPPING = "csv-mapping";
    static XMLHelper xmlHelper = new XMLHelper();

    public CSVParser loadFile(String filepath) {
        CSVParser csvParser = null;
        try {
            logger.info("Loading the csv File....");
            Reader reader = new FileReader(filepath);
            csvParser = CSVFormat.DEFAULT.builder().setHeader().build().parse(reader);
            logger.info("Successfully Loaded the csv File.");
        } catch (Exception e) {
            logger.error("Failed to load csv file: {}", filepath);
            logger.error(e.toString());
            getFailedstep(e);
        }
        return csvParser;
    }

    public CSVParser loadFile(File file) {
        CSVParser csvParser = null;
        try {
            logger.info("Loading the csv File....");
            Reader reader = new FileReader(file);
            csvParser = CSVFormat.DEFAULT.builder().setHeader().build().parse(reader);
            logger.info("Successfully Loaded the csv File.");
        } catch (Exception e) {
            logger.error("Failed to load csv file: ");
            logger.error(e.toString());
            getFailedstep(e);
        }
        return csvParser;
    }

    //------------------------Getters-------------------------

    public List<String> getHeaders(CSVParser csvParser) {
        List<String> headers = new ArrayList<>();
        List<String> result = new ArrayList<>();
        try {
            logger.info("Getting the headers list....");
            headers = csvParser.getHeaderNames();
            for (String header : headers) {
                result.add(header.replace(UFEFF, ""));
            }
            logger.info("Successfully got the headers list");
        } catch (Exception e) {
            logger.error("Failed to get the Headers List");
            logger.error(e.toString());
            getFailedstep(e);
        }
        return result;
    }

    public String getHeaderAtIndex(CSVParser csvParser, int index) {
        return getHeaders(csvParser).get(index);
    }

    /**
     * <Header, Index>
     */
    public Map<String, Integer> getHeadersWithIndex(CSVParser csvParser) {
        Map<String, Integer> headers = new HashMap<>();
        try {
            logger.info("Getting the headers list with index....");
            headers = csvParser.getHeaderMap();
            logger.info("Successfully got the headers list with index");
        } catch (Exception e) {
            logger.error("Failed to get the Headers List");
            logger.error(e.toString());
            getFailedstep(e);
        }
        return headers;
    }

    public List<String> getRow(CSVParser csvParser, int index) {
        List<String> row = new ArrayList<>();
        try {
            logger.info("Fetching the row on index: {}", index);
            row = csvParser.getRecords().get(index).toList();
            logger.info("Successfully fetched the row at index: {}", index);
        } catch (Exception e) {
            logger.error("Failed to fetch the row at index: {}", index);
            logger.error(e.toString());
            getFailedstep(e);
        }
        return row;
    }

    public List<List<String>> getRows(CSVParser csvParser) {
        List<List<String>> rows = new ArrayList<>();
        try {
            logger.info("Fetching the rows........");
            Iterator<CSVRecord> iterator = csvParser.iterator();
            int rowCount = 1;
            try {
                while (iterator.hasNext()) {
                    rows.add(iterator.next().toList());
                    rowCount++;
                }
            } catch (Exception e) {
                logger.error("Failed to fetch row no {}", rowCount);
                logger.error(e.getMessage());
                appendTextInGlobalSummary(HTML.LI + HTML.ERROR + " Failed to fetch row no " + rowCount);
                appendTextInGlobalSummary("Reason: " + e + HTML.LI_CLOSE);
                getFailedstep(e);
            }
            logger.info("Successfully fetched the rows.");
        } catch (Exception e) {
            logger.error("Failed to fetch the row");
            logger.error(e.toString());
            getFailedstep(e);
        }
        return rows;
    }

    public List<String> getColumn(CSVParser csvParser, int index) {
        List<String> column = new ArrayList<>();
        try {
            logger.info("Fetching the column at index: {}", index);
            Iterator<CSVRecord> iterator = csvParser.iterator();
            while (iterator.hasNext()) {
                column.add(iterator.next().get(index));
            }
            logger.info("Successfully fetched the column at index: " + index);
        } catch (Exception e) {
            logger.error("Failed to fetch the column at index: " + index);
            logger.error(e.toString());
            getFailedstep(e);
        }
        return column;
    }

    public List<String> getColumn(CSVParser csvParser, String header) {
        List<String> column;
        column = iterateInFileOrCSV(header, csvParser);
        return column;
    }

    public List<String> getColumn(File file, String header) {
        List<String> column;
        CSVHelper csvHelper = new CSVHelper();
        CSVParser csvParser = csvHelper.loadFile(file);
        column = iterateInFileOrCSV(header, csvParser);
        return column;
    }

    private List<String> iterateInFileOrCSV(String header, CSVParser csvParser) {
        List<String> column = new ArrayList<>();
        try {
            logger.info("Fetching the column at header: {}", header);
            for (CSVRecord strings : csvParser) {
                column.add(strings.get(header));
            }
            logger.info("Successfully fetched the column at header: {}", header);
        } catch (Exception e) {
            logger.error("Failed to fetch the column at header: {}", header);
            logger.error(e.toString());
            getFailedstep(e);
        }
        return column;
    }

    //----------------------Validations----------------------------------

    public void verifyHeaderCount(CSVParser csvParser, int expectedHeaderCount) {
        try {
            logger.info("verifying the header count with expected....");
            int actualSize = getHeaders(csvParser).size();
            logger.info("actual size: {}", actualSize);
            logger.info("expected size: {}", expectedHeaderCount);
            assertEquals(actualSize, expectedHeaderCount);
            logger.info("successfully verified the header count with expected");
        } catch (Exception e) {
            logger.error("Failed to verify the header count with expected");
            logger.error(e.toString());
            getFailedstep(e);
        } catch (AssertionError e) {
            logger.error("Failed to verify the header count with expected");
            logger.error(e.toString());
            getFailedstep(e);
        }
    }

    public void verifyHeaderNameWithRegexAtIndex(CSVParser csvParser, int index, String expectedHeaderRegex) {
        try {
            logger.info("verifying the header name with expected at index: {}", index);
            logger.info("expected pattern: {}", expectedHeaderRegex);
            assertTrue(Utils.verfiyTextUsingRegex(getHeaders(csvParser).get(index).trim(), expectedHeaderRegex));
            logger.info("Successfully verified the header name with expected at index: {}", index);
        } catch (Exception e) {
            logger.error("Failed to verify the header name with expected at index: {}", index);
            logger.error(e.toString());
            getFailedstep(e);
        } catch (AssertionError e) {
            logger.error("Failed to verify the header name with expected at index: {}", index);
            logger.error(e.toString());
            getFailedstep(e);
        }
    }

    public void verifyHeadersWithRegex(CSVParser csvParser, String expcetedRegex) {
        logger.info("verifying the header names with expected regex");
        logger.info("expected pattern: {}", expcetedRegex);

        for (String header : getHeaders(csvParser)) {
            try {
                assertTrue(Utils.verfiyTextUsingRegex(header, expcetedRegex));
                logger.info("Successfully verified the header name: {} with expected regex: {}", header, expcetedRegex);
            } catch (Exception e) {
                logger.error("Failed to verify the header name: {} with expected regex: {}", header, expcetedRegex);
                logger.error(e.toString());
                getFailedstep(e);
            } catch (AssertionError e) {
                logger.error("Failed to verify the header name: {} with expected regex: {}", header, expcetedRegex);
                logger.error(e.toString());
                getFailedstep(e);
            }
        }
    }

    public void verifyHeadersWithExpectedList(CSVParser csvParser, List<String> expectedList) {
        logger.info("verifying the headers with expected list....");
        for (int i = 0; i < getHeaders(csvParser).size(); i++) {
            verifyHeaderNameWithRegexAtIndex(csvParser, i, expectedList.get(i));
        }
    }

    private void iterateInColumnsByHeaderOrIndex(List<String> column, String expectedPattern) {
        for (String rec : column) {
            try {
                assertTrue(Utils.verfiyTextUsingRegex(rec, expectedPattern));
                logger.info("Successfully verified the record: {} with expected pattern: {}", rec, expectedPattern);
            } catch (Exception e) {
                logger.error("Failed to verify the record:{} with expected pattern:{}", rec, expectedPattern);
                logger.error(e.toString());
                getFailedstep(e);
            } catch (AssertionError e) {
                logger.error("Failed to verify the record:{} with expected pattern: {}", rec, expectedPattern);
                logger.error(e.toString());
                getFailedstep(e);
            }
        }
    }

    public void verifyColumnValuesWithExpectedRegex(CSVParser csvParser, String expectedPattern, int index) {

        logger.info("verifying the column values with expectedPattern");
        List<String> column = getColumn(csvParser, index);
        iterateInColumnsByHeaderOrIndex(column, expectedPattern);
    }

    public void verifyColumnValuesWithExpectedRegex(CSVParser csvParser, String expectedPattern, String header) {
        logger.info("verifying the column values with expectedPattern");
        List<String> column = getColumn(csvParser, header);
        iterateInColumnsByHeaderOrIndex(column, expectedPattern);
    }

    public void verifyRowWithListAtIndex(CSVParser csvParser, int index, List<String> expectedRow) {
        logger.info("verifying the row with expectedList at index: {}", index);
        List<String> row = getRow(csvParser, index);
        for (int i = 0; i < row.size(); i++) {
            String expectedPattern = "";
            String actualRecord = "";
            try {
                actualRecord = row.get(i);
                expectedPattern = expectedRow.get(i);
                assertTrue(Utils.verfiyTextUsingRegex(actualRecord, expectedPattern));
                logger.info("Successfully verified the record: {} with expected pattern: {}", actualRecord, expectedPattern);
            } catch (Exception e) {
                logger.error("Failed to verify the record:-{} with expected pattern: {}", actualRecord, expectedPattern);
                logger.error(e.toString());
                getFailedstep(e);
            } catch (AssertionError e) {
                logger.error("Failed to verify the record- {} with expected pattern: {}", actualRecord, expectedPattern);
                logger.error(e.toString());
                getFailedstep(e);
            }
            logger.info("Successfully verified the row with expectedList at index: {}", index);
        }
    }
   // ::FUTURE::
    public void verifyHeaderWithPolicy(CSVParser csvParser, String policy) {
        FileHelper fileHelper = new FileHelper();
        Map<String, Object> policyHeader = fileHelper.readPolicyObject("content.csv.header", "");
        for (String key : policyHeader.keySet()) {
            if (key.equalsIgnoreCase("name_all_withList")) {
                List<String> expectedHeaders = (ArrayList<String>) policyHeader.get(key);
                verifyHeadersWithExpectedList(csvParser, expectedHeaders);
            } else if (key.equalsIgnoreCase("count")) {
                verifyHeaderCount(csvParser, (int) policyHeader.get(key));
            } else if (key.equalsIgnoreCase("name_all_withRegex")) {
                verifyHeadersWithRegex(csvParser, (String) policyHeader.get(key));
            } else if (key.contains("name_atIndex_")) {
                int index = Integer.parseInt(Utils.findValueWithPattern(key, SLASH_D).replace("_", ""));
                verifyHeaderNameWithRegexAtIndex(csvParser, index, (String) policyHeader.get(key));
            } else if (key.contains("length_AtIndex_")) {
                int index = Integer.parseInt(Utils.findValueWithPattern(key, SLASH_D).replace("_", ""));
                Utils.verifyLenqthOfText(getHeaders(csvParser).get(index), (int) policyHeader.get(key));
            }
        }
    }

    public void verifyColumnsWithPolicy(CSVParser csvParser, String policy) {
        FileHelper fileHelper = new FileHelper();
        Map<String, Object> policyHeader = fileHelper.readPolicyObject("content.csv.column", "");
        for (String key : policyHeader.keySet()) {
            if (key.contains("name_-h")) {
                verifyColumnValuesWithExpectedRegex(csvParser, (String) policyHeader.get(key), key.replace("name_-h", ""));
            } else if (key.contains("name_atIndex_")) {
                int index = Integer.parseInt(Utils.findValueWithPattern(key, SLASH_D).replace("_", ""));
                verifyColumnValuesWithExpectedRegex(csvParser, (String) policyHeader.get(key), index);
            }
        }
    }

    public void verifyRowsWithPolicy(CSVParser csvParser, String policy) {
        FileHelper fileHelper = new FileHelper();
        Map<String, Object> policyHeader = fileHelper.readPolicyObject("content.csv.row", "");
        for (String key : policyHeader.keySet()) {
            if (key.contains("row_atIndex_")) {
                int index = Integer.parseInt(Utils.findValueWithPattern(key, SLASH_D).replace("_", ""));
                verifyRowWithListAtIndex(csvParser, index, (List<String>) policyHeader.get(key));
            }
        }
    }

    public String parseCSVtoJSON(File file) throws IOException {
        String json = null;
        StringBuilder sb = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new FileReader(file.getAbsolutePath()))) {
            String line = null;
            int index = 0;
            while (((line = reader.readLine()) != null) && index < 2) {
                sb.append(line).append("\n");
                index++;
            }
            JSONArray array = new JSONArray(CDL.toJSONArray(sb.toString()).toString());
            json = array.toString();
            json = json.substring(1, json.length() - 1).replace(UFEFF, "");
        } catch (IOException e) {
            logger.error("Exception found in parseCSVtoJSON function {}", e.getMessage());
        }
        return json;
    }

    public Map<String, Object> filterSQLMapping(String ruleJson, File csv) {
        HashMap<String, Object> csvMapping = new HashMap<>();
        CSVHelper csvHelper = new CSVHelper();
        try {
            JSONHelper jsonHelper1 = new JSONHelper();
            String nodePath = null;
            String columnName = null;
            Map<String, Object> ruleJsonPath = jsonHelper1.listJsonKeyValues(ruleJson);
            String columnValue = null;
            for (Map.Entry node : ruleJsonPath.entrySet()) {
                nodePath = node.getKey().toString();
                if (nodePath.contains(".sql-mapping") && (boolean) node.getValue()) {
                    nodePath = nodePath.substring(0, nodePath.lastIndexOf("."));
                    columnName = JsonPath.read(ruleJson, nodePath + DOT_CSV_MAPPING);
                    try {
                        columnValue = csvHelper.getColumn(csv, columnName).get(0);
                    } catch (Exception e) {
                        columnValue = "";
                    }
                    csvMapping.put(columnName, columnValue);
                }
            }
        } catch (Exception e) {
            logger.error(e.getMessage());
        }
        return csvMapping;
    }

    public Map<String, Object> filterBatchSQLMapping(String ruleJson, File csv) {
        HashMap<String, Object> csvMapping = new HashMap<>();
        CSVHelper csvHelper = new CSVHelper();
        try {
            JSONHelper jsonHelper1 = new JSONHelper();
            Map<String, Object> ruleJsonPath = jsonHelper1.listJsonKeyValues(ruleJson);
            String nodePath = null;
            String columnName = null;
            for (Map.Entry node : ruleJsonPath.entrySet()) {
                nodePath = node.getKey().toString();
                if (nodePath.contains(".sql-mapping") && (boolean) node.getValue()) {
                    nodePath = nodePath.substring(0, nodePath.lastIndexOf("."));
                    columnName = JsonPath.read(ruleJson, nodePath + DOT_CSV_MAPPING);
                    List<String> columnValues;
                    columnValues = csvHelper.getColumn(csv, columnName);
                    csvMapping.put(columnName, columnValues);
                }
            }
        } catch (Exception e) {
            logger.error(e.getMessage());
        }
        return csvMapping;
    }

    public boolean compareCSVs(File file1, File file2) {
        return compareCSVs(file1, file2, null);
    }

    public boolean compareCSVs(File file1, File file2, String reportPath) {
        StringBuilder summary = new StringBuilder();
        CSVHelper csvHelper = new CSVHelper();
        List<String> headersFile1 = new ArrayList<>();
        List<String> headersFile2 = new ArrayList<>();
        List<List<String>> rowsFile1 = null;
        List<List<String>> rowsFile2 = null;
        CSVParser cfile2;
        CSVParser cfile1;
        boolean result = true;

        if (FilenameUtils.getExtension(file1.getName()).equalsIgnoreCase("xlsx")) {
            XSSFWorkbook workbook = csvHelper.loadExcelFile(file1);
            headersFile1 = getExcelHeader(workbook);
            rowsFile1 = getExcelRows(workbook);
        } else if (FilenameUtils.getExtension(file1.getName()).equalsIgnoreCase("csv")) {
            cfile1 = csvHelper.loadFile(file1);
            headersFile1 = csvHelper.getHeaders(cfile1);
            rowsFile1 = csvHelper.getRows(cfile1);
        }

        if (FilenameUtils.getExtension(file2.getName()).equalsIgnoreCase("xlsx")) {
            XSSFWorkbook workbook = csvHelper.loadExcelFile(file2);
            headersFile2 = getExcelHeader(workbook);
            rowsFile2 = getExcelRows(workbook);
        } else if (FilenameUtils.getExtension(file2.getName()).equalsIgnoreCase("csv")) {
            cfile2 = csvHelper.loadFile(file2);
            headersFile2 = csvHelper.getHeaders(cfile2);
            rowsFile2 = csvHelper.getRows(cfile2);
        }
        boolean isFilesEmpty = headersFile1.isEmpty() && headersFile2.isEmpty() && Objects.requireNonNull(rowsFile1).isEmpty() && Objects.requireNonNull(rowsFile2).isEmpty();
        if (isFilesEmpty) {
            appendTextInGlobalSummary(HTML.TR + HTML.TD + file1.getName() + HTML.TD_CLOSE + HTML.TD + file2.getName() + HTML.TD_CLOSE + HTML.TD + "Both Files are empty" + HTML.TD_CLOSE + HTML.TD + HTML.TD_CLOSE + HTML.TR_CLOSE);
            return false;
        }
        //verify headers
        if (headersFile1.size() == headersFile2.size()) {
            for (int i = 0; i < headersFile1.size(); i++) {
                if (headersFile1.get(i).replace(UFEFF, "").equals(headersFile2.get(i).replace(UFEFF, "")))
                    summary.append(headersFile1.get(i).replace(UFEFF, ""));
                else {
                    summary.append("File: ").append(file1.getName()).append(HAS).append(headersFile1.get(i)).append(" != File: ").append(file2.getName()).append(HAS).append(headersFile2.get(i)).append(" header");
                    result = false;
                }
            }
        } else {
            summary.append("Header count is not matched File: ").append(file1.getName()).append(HAS).append(headersFile1.size()).append(" != File: ").append(file2.getName()).append(HAS).append(headersFile2.size()).append(" headers");
            result = false;
        }

        for (int i = 0; i < rowsFile1.size(); i++) {
            summary.append("\n");
            for (int j = 0; j < rowsFile1.get(i).size(); j++) {
                if (rowsFile1.get(i).get(j).equals(rowsFile2.get(i).get(j)))
                    summary.append(rowsFile1.get(i).get(j) + ", ");
                else {
                    summary.append(rowsFile1.get(i).get(j) + " != " + (rowsFile2.get(i).get(j)) + ", ");
                    result = false;
                }
            }
        }
        String reportFileName = file1.getName().substring(0, file1.getName().indexOf(".")) + "-vs-" + file2.getName().substring(0, file2.getName().indexOf("."));
        fileWriterXLS(reportFileName, reportPath, summary.toString());
        //logs
        if (appendTextInContextMap("isTableReq", "") != null) {
            StringBuilder localSummary = new StringBuilder();

            localSummary.append(HTML.TR + HTML.TD).append(file1.getName()).append(HTML.TD_CLOSE).append(" ").append(HTML.TD).append(file2.getName()).append(HTML.TD_CLOSE).append(" ");
            if (result)
                localSummary.append(HTML.TD + " identical " + HTML.TD_CLOSE);
            else
                localSummary.append(HTML.TD + " not identical. " + HTML.TD_CLOSE);
            localSummary.append(HTML.TD + "<a href=").append(reportFileName).append(">Download</a>").append(HTML.TD_CLOSE).append(HTML.TR_CLOSE);
            appendTextInGlobalSummary(localSummary.toString());
        } else
            appendTextInGlobalSummary(HTML.LI + "The comparison File can be found at folder: " + FEEDFILEREPORTS + " with name " + reportFileName);

        return result;
    }

    public void fileWriter(String fileName, String content) {
        String path = Constants.FEEDFILEREPORTS;
        File directory = new File(path);
        if (!directory.exists()) {
            directory.mkdir();
            logger.info("Directory created : {}", directory.getName());
        }
        path = Constants.FEEDFILEREPORTS + fileName;
        File fileObject = new File(path);
        try {
            if (fileObject.exists()) {
                fileObject.delete();
            }
            if (!fileObject.exists()) {
                fileObject.createNewFile();
            }
            FileWriter writer = new FileWriter(fileObject);
            writer.write(content);
            writer.close();
        } catch (IOException e) {
            logger.error("Exception found fileWriter in function {}", e.getMessage());
        }
    }

    public XSSFWorkbook loadExcelFile(File file) {
        XSSFWorkbook workbook = null;
        try {
            FileInputStream inputStream = new FileInputStream(file.getAbsolutePath());
            workbook = new XSSFWorkbook(inputStream);
        } catch (Exception e) {
            logger.info(e.getMessage());
        }
        return workbook;
    }

    public List<List<String>> getExcelRows(XSSFWorkbook workbook) {
        List<List<String>> list = new ArrayList<>();
        XSSFSheet sheet = workbook.getSheetAt(0);
        int rows = sheet.getLastRowNum();
        int cols = 0;
        if (sheet.getRow(1) != null)
            cols = sheet.getRow(1).getLastCellNum();
        for (int r = 0; r <= rows; r++) {
            XSSFRow row = sheet.getRow(r);
            List ls = new ArrayList();
            for (int c = 0; c < cols; c++) {
                XSSFCell cell = row.getCell(c);
                ls.add(c, cell.toString());
            }
            list.add(r, ls);
        }
        if (!list.isEmpty())
            list.remove(0);
        return list;
    }

    public List getExcelHeader(XSSFWorkbook workbook) {
        List list = new ArrayList();
        XSSFSheet sheet = workbook.getSheetAt(0);
        XSSFRow row = sheet.getRow(0);
        int cols = 0;
        if (sheet.getRow(1) != null)
            cols = sheet.getRow(1).getLastCellNum();
        for (int c = 0; c < cols; c++) {
            XSSFCell cell = row.getCell(c);
            list.add(c, cell.toString());
        }
        return list;
    }

    public boolean checkAllCSVFiles(List<File> files, String rule, VerificationType checkType) {
        Map<File, String> fileStructure = new HashMap<>();
        boolean flag = true;
        try {
            StringBuilder localSummary = new StringBuilder();
            appendTextInGlobalSummary(HTML.TABLE + HTML.TR + HTML.TH + "Validating the " + checkType.toString() + " of files" + HTML.TH_CLOSE + HTML.TR_CLOSE);
            logger.debug("Checking all CSV files against rule :: {}", rule);
            int pass = 0;
            int fail = 0;
            File ruleFile = new File(RULESFILEPATH + rule);
            for (File file : files) {
                String ruleJson = xmlHelper.readFileAsString(ruleFile.getPath());
                logger.info("Checking XML file {} against rule :: {}", file.getName(), rule);
                if (checkType.equals(FILE_STRUCTURE)) {
                    flag = checkCSVFile(file, ruleJson);
                    if (flag) {
                        fileStructure.put(file, "pass");
                        pass++;
                    } else {
                        fileStructure.put(file, "fail");
                        fail++;
                    }
                } else if (checkType.equals(DATA_QUALITY)) {
                    boolean isFileStructureChecked = false;
                    if (FileHelper.fileMap.contains(FILE_STRUCTURE)) {
                        isFileStructureChecked = true;
                        HashMap<File, String> temp = (HashMap<File, String>) FileHelper.fileMap.get(FILE_STRUCTURE);
                        if (!temp.containsKey(file)) {
                            isFileStructureChecked = false;
                        }
                    }
                    if (!isFileStructureChecked) {
                        flag = checkCSVFile(file, ruleJson);
                        if (!flag) {
                            appendTextInGlobalSummary(HTML.LI + "File Structure for " + file.getName() + " invalid." + HTML.LI_CLOSE);
                            fileStructure.put(file, "fail");
                            fail++;
                            continue;
                        }
                    }
                    flag = checkCSVDataQuality(file, ruleJson);
                    if (flag) {
                        fileStructure.put(file, "pass");
                        pass++;
                    } else {
                        fileStructure.put(file, "fail");
                        fail++;
                    }
                }
            }
            if (FileHelper.fileMap.contains(checkType)) {
                fileStructure.putAll((Map<? extends File, ? extends String>) FileHelper.fileMap.get(FILE_STRUCTURE));
            }
            FileHelper.fileMap.put(checkType, fileStructure);
            localSummary.append(HTML.TR + HTML.TD + "Total files: " + HTML.TD_CLOSE + HTML.TD).append(files.size()).append(HTML.TD_CLOSE);
            localSummary.append(HTML.TR + HTML.TD + "Passed : " + HTML.TD_CLOSE + HTML.TD).append(pass).append(HTML.TD_CLOSE);
            localSummary.append(HTML.TR + HTML.TD + "Failed : " + HTML.TD_CLOSE + HTML.TD).append(fail).append(HTML.TD_CLOSE);
            localSummary.append(HTML.TABLE_CLOSE);
            appendTextInGlobalSummary(localSummary.toString());
        } catch (Exception e) {
            logger.error(e.getMessage());
            return false;
        }
        return flag;
    }

    public boolean checkCSVDataQuality(File file, String ruleJson) {
        appendTextInGlobalSummary(HTML.LI + "Checking data Quality of file: " + file.getName() + HTML.LI_CLOSE);
        boolean fileStatus = true;
        try {
            JSONHelper jsonHelper = new JSONHelper();
            Map<String, Object> rulesJsonPath = jsonHelper.listJsonKeyValues(ruleJson);
            CSVHelper csvHelper = new CSVHelper();
            CSVParser csvParser = csvHelper.loadFile(file);
            List<List<String>> rows = csvHelper.getRows(csvParser);
            List<String> headers = csvHelper.getHeaders(csvParser);
            int headerCount = headers.size();
            List<List<Map<Boolean, String>>> result = new ArrayList<>();
            if (rows.isEmpty()) {
                Map<Boolean, String> map = new HashMap<>();
                map.put(false, "File doesn't have any data");
                List<Map<Boolean, String>> ls = new ArrayList<>();
                ls.add(map);
                result.add(ls);
            } else {
                for (int i = 0; i < rows.size(); i++) {
                    List<Map<Boolean, String>> list = new ArrayList<>();
                    boolean rowStaus = true;
                    if (headerCount != rows.get(i).size()) {
                        HashedMap map = new HashedMap();
                        HashedMap map1 = new HashedMap();
                        map.put(false, "false");
                        map1.put(false, "Row count miss-matched with header");
                        list.add(0, map);
                        list.add(1, map1);
                    } else {
                        for (int k = 0; k < rows.get(0).size(); k++) {
                            String cellValue = rows.get(i).get(k);
                            boolean status = true;
                            Map<Boolean, String> map = new HashMap<>();
                            for (String rule : rulesJsonPath.keySet()) {
                                boolean lengthFlag = true;
                                boolean dataTypeFlag = true;
                                boolean maxLengthFlag = true;
                                boolean nullCheckFlag = true;
                                boolean precisionFlag = true;
                                boolean regexFlag = true;
                                if (rule.contains(CSV_MAPPING)) {
                                    String propertry = (String) rulesJsonPath.get(rule);
                                    if (propertry.equals(headers.get(k).replace(UFEFF, ""))) {
                                        Map<String, Object> ruleMap = JsonPath.read(ruleJson, rule.replace(DOT_CSV_MAPPING, ""));
                                        if (ruleMap.get(DATA_TYPE) != null) {
                                            dataTypeFlag = xmlHelper.checkDataType((String) ruleMap.get(DATA_TYPE), cellValue);
                                        } else if (ruleMap.get(LENGTH) != null) {
                                            lengthFlag = xmlHelper.checkLength((int) ruleMap.get(LENGTH), cellValue);
                                        } else if (ruleMap.get("max-length") != null) {
                                            maxLengthFlag = xmlHelper.checkMaxLength((int) ruleMap.get("max-length"), cellValue);
                                        } else if (ruleMap.get("null-check") != null) {
                                            nullCheckFlag = xmlHelper.nullCheck((Boolean) ruleMap.get("null-check"), cellValue);
                                        } else if (ruleMap.get("checkRegex") != null) {
                                            regexFlag = xmlHelper.checkRegex(String.valueOf(ruleMap.get("regex")), cellValue);
                                        } else if (ruleMap.get(PRECISION_RAW) != null) {
                                            precisionFlag = xmlHelper.checkPrecision((LinkedHashMap<String, Object>) ruleMap.get(PRECISION_RAW), cellValue);
                                        }
                                    }
                                    status = (maxLengthFlag && lengthFlag && dataTypeFlag && nullCheckFlag && regexFlag && precisionFlag);
                                    if (!status) {
                                        rowStaus = false;
                                        fileStatus = false;
                                        logger.error("validation failed at row: {} and column: {}", i, k);
                                        StringBuilder s = new StringBuilder();
                                        if (!dataTypeFlag) {
                                            s.append(DATA_TYPE + " ");
                                        } else if (!lengthFlag) {
                                            s.append(LENGTH + " ");
                                        } else if (!maxLengthFlag) {
                                            s.append("maxLength" + " ");
                                        } else if (!nullCheckFlag) {
                                            s.append("nullCheck" + " ");
                                        } else if (!regexFlag) {
                                            s.append("regex" + " ");
                                        } else if (!precisionFlag) {
                                            s.append(PRECISION_RAW + " ");
                                        }
                                        map.clear();
                                        map.put(status, " failed at rule(s) " + s);
                                    } else {
                                        if (map.containsKey(true) || map.isEmpty()) {
                                            map.put(status, "statisfied all rules");
                                        }
                                    }
                                }
                            }
                            list.add(k, map);
                        }
                        Map<Boolean, String> rowmap = new HashMap<>();
                        rowmap.put(rowStaus, String.valueOf(rowStaus));
                        list.add(0, rowmap);
                    }
                    result.add(i, list);
                }
            }
            writeCSVRuleMatchingInfo("dataQuality_" + file.getName(), result, headers);
        } catch (Exception e) {
            logger.error("Data Quality check for XML file failed. {}", e.getMessage());
        }
        return fileStatus;
    }

    public boolean checkCSVFile(File file, String ruleJson) {
        boolean fileStatus = true;

        try {
            JSONHelper jsonHelper = new JSONHelper();
            Map<String, Object> rulesJsonPath = jsonHelper.listJsonKeyValues(ruleJson);

            CSVHelper csvHelper = new CSVHelper();
            CSVParser csvParser = csvHelper.loadFile(file);
            List<List<String>> rows = csvHelper.getRows(csvParser);
            List<String> headers = csvHelper.getHeaders(csvParser);
            int headerCount = headers.size();
            List<List<Map<Boolean, String>>> result = new ArrayList<>();

            boolean headerMandatory = true;
            StringBuilder headerFailure = new StringBuilder();
            for (String rule : rulesJsonPath.keySet()) {
                if (rule.contains(CSV_MAPPING)) {
                    Map<String, Object> ruleMap = JsonPath.read(ruleJson, rule.replace(DOT_CSV_MAPPING, ""));
                    if (ruleMap.get(MANDATORY) != null && (Boolean) ruleMap.get(MANDATORY) && (!headers.contains(ruleMap.get(CSV_MAPPING)))) {
                        headerFailure.append(ruleMap.get(CSV_MAPPING)).append(", ");
                        headerMandatory = false;
                    }
                }
            }
            if (!headerMandatory) {
                appendTextInGlobalSummary(HTML.ERROR + " Column(s) that didn't exist in file are " + headerFailure);
                Map<Boolean, String> map = new HashMap();
                map.put(false, " Column(s) that didn't exist in file are " + headerFailure);
                List<Map<Boolean, String>> ls = new ArrayList<>();
                ls.add(map);
                result.add(ls);
                fileStatus = false;
            } else {
                if (rows.isEmpty()) {
                    Map<Boolean, String> map = new HashMap<>();
                    map.put(false, "File doesn't have any data" + headerFailure);
                    List<Map<Boolean, String>> ls = new ArrayList<>();
                    ls.add(map);
                    result.add(ls);
                } else {
                    for (int i = 0; i < rows.size(); i++) {
                        List<Map<Boolean, String>> list = new ArrayList<>();
                        Boolean rowStaus = true;
                        if (headerCount != rows.get(i).size()) {
                            Map<Boolean, String> map = new HashedMap();
                            Map<Boolean, String> map1 = new HashedMap();
                            map.put(false, "false");
                            map1.put(false, "Row count miss-matched with header");
                            list.add(0, map);
                            list.add(1, map1);
                        } else {
                            for (int k = 0; k < rows.get(0).size(); k++) {
                                Map<Boolean, String> map = new HashMap<>();
                                String cellValue = rows.get(i).get(k);
                                for (String rule : rulesJsonPath.keySet()) {
                                    boolean mandatoryFlag = true;
                                    if (rule.contains(CSV_MAPPING)) {
                                        String propertry = (String) rulesJsonPath.get(rule);
                                        if (propertry.equals(headers.get(k).replace(UFEFF, ""))) {
                                            Map<String, Object> ruleMap = JsonPath.read(ruleJson, rule.replace(DOT_CSV_MAPPING, ""));
                                            if (ruleMap.get(MANDATORY) != null && (Boolean) ruleMap.get(MANDATORY)) {
                                                mandatoryFlag = !cellValue.isEmpty();
                                            }
                                        }
                                        if (!mandatoryFlag) {
                                            rowStaus = false;
                                            logger.error("validation failed at row: {} and column: {}", i, k);
                                            fileStatus = false;
                                            map.put(false, "failed the structure check");
                                        } else
                                            map.put(true, "passed the structure check");
                                    }
                                }
                                list.add(k, map);
                            }
                            Map<Boolean, String> rowmap = new HashMap<>();
                            rowmap.put(rowStaus, String.valueOf(rowStaus));
                            list.add(0, rowmap);
                        }
                        result.add(i, list);
                    }
                }
            }
            writeCSVRuleMatchingInfo("fileStructure_" + file.getName(), result, headers);
        } catch (Exception e) {
            logger.error("Structure check for XML file failed. {}", e.getMessage());
        }
        return fileStatus;
    }

    public void fileWriterXLS(String fileName, String path, String content) {
        if (path == null) {
            path = Constants.FEEDFILEREPORTS + "Others/";
            File directory = new File(path);
            if (!directory.exists()) {
                directory.mkdir();
                logger.info("Directory created : {}", directory.getName());
            }
        }
        XLSHelper xlsHelper = new XLSHelper();
        XSSFWorkbook workbook = xlsHelper.createWorkBook();
        XSSFSheet sheet = xlsHelper.createSheet(workbook, "Sheet1");
        String[] rows = content.split("\n");
        int totalRows = rows.length;
        int columnCount = 0;
        try {
            columnCount = rows[1].split(",").length;
        } catch (IndexOutOfBoundsException e) {
            columnCount = rows[0].split(",").length;
        }
        //Conditional Formatting
        SheetConditionalFormatting sheetCF = sheet.getSheetConditionalFormatting();
        ConditionalFormattingRule rule = sheetCF.createConditionalFormattingRule("=ISNUMBER(SEARCH(\"!=\",A1))");
        PatternFormatting fill = rule.createPatternFormatting();
        fill.setFillBackgroundColor(IndexedColors.RED.index);
        fill.setFillPattern(PatternFormatting.SOLID_FOREGROUND);
        CellRangeAddressList addressList = new CellRangeAddressList(0, totalRows, 0, columnCount);
        sheetCF.addConditionalFormatting(addressList.getCellRangeAddresses(), rule);

        SheetConditionalFormatting sheetCF2 = sheet.getSheetConditionalFormatting();
        ConditionalFormattingRule rule2 = sheetCF2.createConditionalFormattingRule("=ISNUMBER(SEARCH(\"fail\",A1))");
        PatternFormatting fill2 = rule2.createPatternFormatting();
        fill2.setFillBackgroundColor(IndexedColors.RED.index);
        fill2.setFillPattern(PatternFormatting.SOLID_FOREGROUND);
        sheetCF2.addConditionalFormatting(addressList.getCellRangeAddresses(), rule2);

        int rowCount = 0;
        for (String row : rows) {
            XSSFRow xssfRow = xlsHelper.createRow(sheet, rowCount);
            int cellCount = 0;
            for (String cell : row.split(",")) {
                XSSFCell xssfCell = xlsHelper.createCell(xssfRow, cellCount);
                xlsHelper.putValueInCell(xssfCell, cell);
                cellCount++;
            }
            rowCount++;
        }

        xlsHelper.writeXLSFile(workbook, fileName, path);
    }

    public void fileWriterXLS(String fileName, String content) {
        fileWriterXLS(fileName, null, content);
    }

    public void writeCSVRuleMatchingInfo(String fileName, List<List<Map<Boolean, String>>> result, List<String> headers) {
        String path = FEEDFILEREPORTS;
        if (fileName.contains("dataQuality")) {
            path = FEEDFILEREPORTS_DATAQUALITY;
        } else if (fileName.contains("fileStructure"))
            path = Constants.FEEDFILEREPORTS_FILESTRUCTURE;
        File directory = new File(path);
        if (!directory.exists()) {
            directory.mkdir();
            logger.info("Directory created : " + directory.getName());
        }
        fileName = fileName.substring(0, fileName.indexOf("."));
        StringBuilder stringBuffer = new StringBuilder();
        stringBuffer.append("Overall,");
        for (String header : headers) {
            stringBuffer.append(header + ",");
        }
        stringBuffer.append("\n");
        for (List<Map<Boolean, String>> ls : result) {
            for (Map<Boolean, String> map : ls) {
                Map.Entry<Boolean, String> entry = map.entrySet().iterator().next();
                stringBuffer.append(entry.getValue()).append(",");
            }
            stringBuffer.append("\n");
        }
        fileWriterXLS(fileName, path, stringBuffer.toString());
        appendTextInGlobalSummary(HTML.LI + "The Report for file check: " + fileName.substring(fileName.indexOf("_") + 1) + " is stored at " + path + HTML.LI_CLOSE);
    }


}



