package com.qe.framework.security.helpers;

import org.zaproxy.clientapi.core.ClientApiException;

public interface ZapAbstraction {

    void doSpidering() throws ClientApiException, InterruptedException;

    void doPassiveScan() throws ClientApiException, InterruptedException;

    void doActiveScan() throws ClientApiException, InterruptedException;

}
