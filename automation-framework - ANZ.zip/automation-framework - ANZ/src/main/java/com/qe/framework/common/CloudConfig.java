package com.qe.framework.common;

import com.jayway.jsonpath.JsonPath;
import com.qe.framework.api.helpers.APIHelper;
import io.restassured.specification.RequestSpecification;
import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;

import static com.qe.framework.common.Constants.*;
import static com.qe.framework.customexception.ExceptionAndErrors.getFailedstep;


public class CloudConfig {
    private static final Logger logger = LoggerFactory.getLogger(CloudConfig.class);
    private static final Map<String, String> contextMap = new HashMap<>();
    private static final String DEVICE_PROPERTIES = "DEVICE_PROPERTIES";
    private static final String PLATFORM_NAME = "platformName";
    private static final String BROWSER_NAME = "browsername";

    private static final String RESOLUTION = "resolution";
    private static final String BROWSER_TYPE = "browserType";
    private static final String BROWSER_VERSION = "browserversion";
    private static final String PLATFORM_VERSION = "platformversion";
    private static final String WEB_DEVICE = "$.web.device";
    private static final String INCORRECT_CONFIGURATION_FOR = "Incorrect configuration for ";
    private static final String TO_BE_SETUP_CORRECTLY = " to be setup correctly";
    private static final String FORK_COUNT = ", forkCount: ";
    private static String urlTemplate = "https://asda.perfectomobile.com/services/handsets/{deviceName}?operation=info&securityToken={securityToken}";
    String devicesRemote = "{\"web\"" + ": {" + "device1:{\"browserType\":\"Chrome\",\"browserVersion\":\"100\",\"platformName\":\"Windows\",\"platformVersion\":\"11\",\"resolution\":\"1920x1080\"},";
    int count = 1;

    public static void loadWebDeviceCombinations() throws IOException {
        String browserProperties = null;
        if (driverType.equalsIgnoreCase("local")) {
            browserProperties = new String(Files.readAllBytes(Paths.get(DEVICESLOCAL)));
        } else {
            if (Utils.isWebTest(null)) {
                browserProperties = getAvailableWebDevice();
            } else if (Utils.isMobileTest(null)) {
                browserProperties = getShellReservedDevices();  //new String(Files.readAllBytes(Paths.get(DEVICESREMOTE)));
            }
        }
        contextMap.put(DEVICE_PROPERTIES, browserProperties);
    }

    public static String getShellReservedDevices() {
        StringBuilder remoteDevicesJSON = new StringBuilder("{ \"mobile\": {");

        reservedDevices = System.getProperty("SuccessfulDevices");

        if (reservedDevices != null) {
            String[] successfulDevices = reservedDevices.split(",");
            int countOfDevices = Integer.parseInt(successfulDevices[0]);
            String[] tmpDeviceSplit;

            for (int indx = 1; indx <= countOfDevices; indx++) {
                tmpDeviceSplit = successfulDevices[indx].split("/");
                remoteDevicesJSON.append("\"device").append(indx).append("\": { \"deviceName\": \"").append(tmpDeviceSplit[0]).append("\", ");
                remoteDevicesJSON.append("\"platformName\": \"").append(tmpDeviceSplit[1]).append("\", ");
                if (tmpDeviceSplit[1].equalsIgnoreCase("android")) {
                    remoteDevicesJSON.append("\"browserType\": \"").append("chrome").append("\" } ");
                } else if (tmpDeviceSplit[1].equalsIgnoreCase("ios")) {
                    remoteDevicesJSON.append("\"browserType\": \"").append("safari").append("\" } ");
                }
                if (indx < countOfDevices) {
                    remoteDevicesJSON.append(", ");
                }
            }
        }

        remoteDevicesJSON.append("} }");
        return remoteDevicesJSON.toString();
    }

    public static int getCountByTargetedDeviceType() {
        Map<String, String> brwSpecs;
        int counter = 0;

        Map<String, String> webDevices = getWebDeviceSpecs("$.mobile");
        int sizeWebDevices = webDevices == null ? 0 : webDevices.size();
        for (int indx = 1; indx <= sizeWebDevices; indx++) {
            brwSpecs = getWebDeviceSpecs("$.mobile.device" + indx);
            assert brwSpecs != null;
            if (targetedMobileDeviceName.equalsIgnoreCase(brwSpecs.get(PLATFORM_NAME))) {
                counter++;
            }
        }
        return counter;
    }

    public static String getAvailableWebDevice() {

        ArrayList<String> inputResolutionList;
        ArrayList<String> inputBrowsersList;
        ArrayList<String> inputBrowserVersionList;
        ArrayList<String> inputPlatform;
        ArrayList<String> inputPlatformVersion;

        String cloudgetBrowserUrl = "https://asda.perfectomobile.com/web/api/v1/config/devices";
        String regex = "\\d+";
        String devices = "";
        String deviceStatusXML = "";
        Map<String, String> template = new HashMap<>();
        CloudConfig cloudConfig = new CloudConfig();
        RequestSpecification request = null;
        APIHelper apiHelper = new APIHelper();
        APIHelper.setHeader("Perfecto-Authorization", cloudSecurityToken);

        if (Objects.isNull(userDeviceMatrix) || userDeviceMatrix.isEmpty()) {
            inputResolutionList = cloudConfig.valuesfromPropertyFile(baseDeviceMatrix, RESOLUTION);
            inputBrowsersList = cloudConfig.valuesfromPropertyFile(baseDeviceMatrix, BROWSER_NAME);
            inputBrowserVersionList = cloudConfig.valuesfromPropertyFile(baseDeviceMatrix, BROWSER_VERSION);
            inputPlatform = cloudConfig.valuesfromPropertyFile(baseDeviceMatrix, PLATFORM_NAME);
            inputPlatformVersion = cloudConfig.valuesfromPropertyFile(baseDeviceMatrix, PLATFORM_VERSION);
            logger.info("Requested Device Matrix : {}", baseDeviceMatrix);
        } else {
            inputResolutionList = cloudConfig.valuesfromPropertyFile(userDeviceMatrix, RESOLUTION);
            if (Objects.isNull(inputResolutionList) || inputResolutionList.isEmpty())
                inputResolutionList = cloudConfig.valuesfromPropertyFile(baseDeviceMatrix, RESOLUTION);
            inputBrowsersList = cloudConfig.valuesfromPropertyFile(userDeviceMatrix, BROWSER_NAME);
            if (Objects.isNull(inputBrowsersList) || inputBrowsersList.isEmpty())
                inputBrowsersList = cloudConfig.valuesfromPropertyFile(baseDeviceMatrix, BROWSER_NAME);
            inputBrowserVersionList = cloudConfig.valuesfromPropertyFile(userDeviceMatrix, BROWSER_VERSION);
            if (Objects.isNull(inputBrowserVersionList) || inputBrowserVersionList.isEmpty())
                inputBrowserVersionList = cloudConfig.valuesfromPropertyFile(baseDeviceMatrix, BROWSER_VERSION);
            inputPlatform = cloudConfig.valuesfromPropertyFile(userDeviceMatrix, PLATFORM_NAME);
            if (Objects.isNull(inputPlatform) || inputPlatform.isEmpty())
                inputPlatform = cloudConfig.valuesfromPropertyFile(baseDeviceMatrix, PLATFORM_NAME);
            inputPlatformVersion = cloudConfig.valuesfromPropertyFile(userDeviceMatrix, PLATFORM_VERSION);
            if (Objects.isNull(inputPlatformVersion) || inputPlatformVersion.isEmpty())
                inputPlatformVersion = cloudConfig.valuesfromPropertyFile(baseDeviceMatrix, PLATFORM_VERSION);
            logger.info("Requested Device Matrix : {}", userDeviceMatrix);
        }
        // Get call to perfect devices Uri to get the Json for available devices
        request = apiHelper.buildAPICall(null);
        APIHelper.triggerAPICall(cloudgetBrowserUrl, "GET", request);
        deviceStatusXML = apiHelper.toString();
        JSONObject jsonObject = new JSONObject(deviceStatusXML);

        //Fetch OS/Platform
        JSONArray platform = jsonObject.getJSONArray("desktopDevices");
        for (int os = 0; os < platform.length(); os++) {
            if (cloudConfig.validateString(platform.getJSONObject(os).get("os").toString(), inputPlatform)) {
                template.put(PLATFORM_NAME, platform.getJSONObject(os).get("os").toString());

                // Fetching the required resolutions
                JSONArray resolution = platform.getJSONObject(os).getJSONArray("resolutions");
                for (int res = 0; res < resolution.length(); res++) {
                    if (cloudConfig.validateString(resolution.get(res).toString(), inputResolutionList)) {
                        template.put(RESOLUTION, resolution.get(res).toString());
                        JSONArray osVersions = platform.getJSONObject(os).getJSONArray("osVersions");

                        // Fetching the required Platform Version
                        for (int osversion = 0; osversion < osVersions.length(); osversion++) {
                            JSONObject platformVersions = platform.getJSONObject(os).getJSONArray("osVersions").getJSONObject(osversion);
                            if (cloudConfig.validateString(platformVersions.get("osVersion").toString(), inputPlatformVersion)) {
                                template.put("platformVersion", platformVersions.get("osVersion").toString());
                                JSONArray browserArray = platformVersions.getJSONArray("browsers");

                                // Fetching the required Browser
                                for (int b = 0; b < browserArray.length(); b++) {
                                    JSONObject browser = browserArray.getJSONObject(b);
                                    if (cloudConfig.validateString(browser.get("browser").toString(), inputBrowsersList)) {
                                        template.put(BROWSER_TYPE, browser.get("browser").toString());

                                        //Fetching Browser Versions
                                        JSONArray browserVersions = browser.getJSONArray("browserVersions");
                                        for (int i = 0; i < browserVersions.length(); i++) {
                                            if ((browserVersions.get(i).toString()).matches(regex) && cloudConfig.validateString(browserVersions.get(i).toString(), inputBrowserVersionList)) {
                                                template.put("browserVersion", browserVersions.get(i).toString());
                                                devices = cloudConfig.storeInStringJson(template);
                                                int lastCharacter = devices.lastIndexOf(",");
                                                devices = devices.substring(0, lastCharacter) + "} }";
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

            }
        }
        logger.info("The Total Number Of Devices Available For Requested Device Matrix: {}", cloudConfig.count);
        if (devices.isEmpty()) {
            int lastCharacter = cloudConfig.devicesRemote.lastIndexOf(",");
            devices = cloudConfig.devicesRemote.substring(0, lastCharacter) + "} }";
        }
        return devices;
    }

    public static Map<String, String> getWebDeviceSpecs(String devicePath) {
        Map<String, String> properties = null;
        if (devicePath == null) {
            logger.debug("Device Path cannot be null");
        }
        if (contextMap.containsKey(DEVICE_PROPERTIES)) {
            properties = JsonPath.read(contextMap.get(DEVICE_PROPERTIES), devicePath);

        }
        return properties;
    }

    public static String getRemoteReleasedMobile() throws InterruptedException {
        String availableBrowser = null;
        Map<String, String> brwSpecs;
        String remoteDeviceName;
        boolean deviceStatus = false;
        int threshold;

        Map<String, String> webDevices = getWebDeviceSpecs("$.mobile");
        int sizeWebDevices = webDevices == null ? 0 : webDevices.size();
        threshold = sizeWebDevices * 5;

        if (targetedMobileDeviceName == null || targetedMobileDeviceName.equalsIgnoreCase("any")) {
            while (threshold > 0) {
                for (int indx = 1; indx <= sizeWebDevices; indx++) {
                    brwSpecs = getWebDeviceSpecs("$.mobile.device" + indx);
                    assert brwSpecs != null;
                    remoteDeviceName = brwSpecs.get("deviceName");
                    deviceStatus = findIfDeviceFreeOnPerfecto(remoteDeviceName);
                    if (deviceStatus) {
                        availableBrowser = "$.mobile.device" + indx;
                        logger.info("----------------->> engaging DEVICE : -------- {}", remoteDeviceName);
                        break;
                    } else {
                        logger.error("Threashold: {}... attempted to engage device {} but found in use", threshold, remoteDeviceName);
                    }
                }
                threshold--;
            }
        } else {
            availableBrowser = getTargetedReleasedMobileDevice(sizeWebDevices);
        }
        return availableBrowser;
    }

    private static String getTargetedReleasedMobileDevice(int sizeWebDevices) throws InterruptedException {
        Map<String, String> brwSpecs;
        String remoteDeviceName;
        boolean deviceStatus;
        String availableBrowser = "";
        int threshold = sizeWebDevices * 5;
        while (threshold > 0) {
            availableBrowser = null;
            for (int indx = 1; indx <= sizeWebDevices; indx++) {
                brwSpecs = getWebDeviceSpecs("$.mobile.device" + indx);
                assert brwSpecs != null;
                if (targetedMobileDeviceName.equalsIgnoreCase(brwSpecs.get(PLATFORM_NAME))) {
                    remoteDeviceName = brwSpecs.get("deviceName");
                    deviceStatus = findIfDeviceFreeOnPerfecto(remoteDeviceName);
                    logger.info("Device {}, Status {}, :: {} - {}", remoteDeviceName, deviceStatus, threshold, indx);
                    if (deviceStatus) {
                        availableBrowser = "$.mobile.device" + indx;
                        logger.debug("Found targeted Device {} at {}", targetedMobileDeviceName, availableBrowser);
                        break;
                    } else {
                        logger.error("this Threashold: {}... attempted to engage device {} but found in use", threshold, remoteDeviceName);
                    }
                }
            }
            if (availableBrowser != null) {
                break;
            }
            threshold--;
        }
        return availableBrowser;
    }

    private static boolean findIfDeviceFreeOnPerfecto(String remoteDeviceName) throws InterruptedException {
        String getURL;
        int sleepRandom;
        APIHelper apiHelper = new APIHelper();
        RequestSpecification request;
        String deviceStatusXML = "";

        urlTemplate = urlTemplate.replace("{securityToken}", cloudSecurityToken);
        getURL = urlTemplate;
        getURL = getURL.replace("{deviceName}", remoteDeviceName);
//              Let any other Fork pickup a device
        sleepRandom = Utils.getRandomNumberInRange(1, 10) + Utils.getRandomNumberInRange(5, 15);
        if (sleepRandom > 15) {
            sleepRandom = sleepRandom - 8;
        }
        sleepRandom = sleepRandom * 1000;
        logger.info("Waiting in queue {} seconds", sleepRandom);
        Thread.sleep(sleepRandom);
        request = apiHelper.buildAPICall(null);
        APIHelper.triggerAPICall(getURL, "GET", request);
        deviceStatusXML = apiHelper.toString();
        if (deviceStatusXML != null && deviceStatusXML.length() > 0) {
            logger.info("Device {} Status XML{}", remoteDeviceName, deviceStatusXML);
            String deviceSubString = deviceStatusXML.substring(deviceStatusXML.indexOf("<available>"), deviceStatusXML.indexOf("</inUse>"));
            logger.info("Remote Device {} current status {}", remoteDeviceName, deviceSubString);
            return deviceStatusXML.contains("<available>true</available>") && deviceStatusXML.contains("<inUse>false</inUse>");
        } else
            return false;
    }

    public static String getLocalRemoteReleasedWebOSBrowser() {
        String availableBrowser = null;
        int rndNum = 0;
        int rndLoop = 0;

        Map<String, String> webDevices = getWebDeviceSpecs("$.web");
        int sizeWebDevices = webDevices == null ? 0 : webDevices.size();

        if (Utils.isWebTest(null) && targetedWebBrowserType != null) {
            while (rndLoop < (sizeWebDevices * 2)) {
                rndNum = Utils.getRandomNumberInRange(1, sizeWebDevices);
                Map<String, String> brwSpecs = getWebDeviceSpecs(WEB_DEVICE + rndNum);
                assert brwSpecs != null;
                if (targetedWebBrowserType.equalsIgnoreCase(brwSpecs.get(BROWSER_TYPE))) {
                    logger.debug("Found targeted {} Browser as {}", appType, targetedWebBrowserType);
                    availableBrowser = WEB_DEVICE + rndNum;
                    break;
                }
                rndLoop++;
            }
        } else {
            rndNum = Utils.getRandomNumberInRange(1, sizeWebDevices);
            availableBrowser = WEB_DEVICE + rndNum;
            logger.debug("Found available {} Browser as {}", appType, availableBrowser);
        }
        return availableBrowser;
    }

    public static String getLocalReleasedMobileDevice() {
        String availableBrowser = null;
        Map<String, String> webDevices = getWebDeviceSpecs("$.mobile");
        int sizeWebDevices = webDevices == null ? 0 : webDevices.size();
        if (targetedMobileDeviceName != null) {
            for (int indx = 1; indx <= sizeWebDevices; indx++) {
                Map<String, String> brwSpecs = getWebDeviceSpecs("$.mobile.device" + indx);
                assert brwSpecs != null;
                if (targetedMobileDeviceName.equalsIgnoreCase(brwSpecs.get(PLATFORM_NAME))) {
                    logger.debug("Found targeted Mobile Device  as {}", targetedMobileDeviceName);

                    availableBrowser = "$.mobile.device" + indx;
                    break;
                }
            }
        } else {
            int rndNum = Utils.getRandomNumberInRange(1, sizeWebDevices);
            availableBrowser = "$.mobile.device" + rndNum;
            logger.debug("Found available Mobile Device  as {}", availableBrowser);
        }
        return availableBrowser;
    }

    public static void sanitizeConfiguration() throws IOException {
        if (Utils.isDriverType("local")) {
            if (Utils.isWebTest(null) || Utils.isOtherValidTests(null)) {
                if (forkCount >= 1) {
                    logger.info("WEB ENV: {}, driverType: {}, appType: {}, forkCount: {}", targetEnvName, driverType, appType, forkCount);
                } else {
                    logger.error(getFailedstep("Incorrect configuration for {}" + driverType.toUpperCase() + " - " + appType.toUpperCase() + FORK_COUNT + forkCount));
                }
            } else if (Utils.isMobileTest(null) && forkCount == 1) {
                logger.info("MOBILE ENV: {}, driverType: {}, appType: {}, forkCount: {}", targetEnvName, driverType, appType, forkCount);
            } else {
                logger.error(getFailedstep(INCORRECT_CONFIGURATION_FOR + driverType.toUpperCase() + " - " + appType.toUpperCase() + FORK_COUNT + forkCount));
            }
        } else if (Utils.isDriverType("remote") || Utils.isDriverType("remloc")) {
            sanitizeConfigurationForRemoteDriverType();
        } else {
            logger.error(getFailedstep("Incorrect configuration - refer the README file"));
        }
        validateDevicesAgainstLoadedConfig();

        if (forkCount > 2 && targetedWebBrowserType.equalsIgnoreCase("safari")) {
            logger.info(" >>>>>> PLEASE NOTE THAT WE HAVE ONLY TWO LICENCES FOR MAC MACHINE. \n IF YOU WERE EXECUTING SAFARI TESTS THEN ADDITIONAL REQUESTS WILL BE REDIRECTED TO WINDOWS BROWSERS <<<<<");
        }
    }

    private static void sanitizeConfigurationForRemoteDriverType() {
        if (Utils.isWebTest(null) || Utils.isMobileTest(null) || Utils.isOtherValidTests(null)) {
            if (Utils.isMobileTest(null) && (cloudLabName == null || cloudSecurityToken == null)) {
                logger.error(getFailedstep("Incorrect configuration : cloudLabName and/or cloudSecurityToken cannot be null"));
            }
            if (forkCount >= 1) {
                logger.info("ENV: {}, driverType: {}, appType: {}, forkCount: {}", targetEnvName, driverType, appType, forkCount);
            } else {
                logger.error(getFailedstep(INCORRECT_CONFIGURATION_FOR + driverType.toUpperCase() + " - " + appType.toUpperCase() + FORK_COUNT + forkCount));
            }
        } else {
            logger.error(getFailedstep(INCORRECT_CONFIGURATION_FOR + driverType.toUpperCase() + " - " + appType.toUpperCase() + FORK_COUNT + forkCount));
        }
    }

    private static void validateDevicesAgainstLoadedConfig() throws IOException {
        if (Utils.isWebTest(null) || Utils.isMobileTest(null)) {
            loadWebDeviceCombinations();

            Map<String, String> webDevices = null;
            if (Utils.isWebTest(null)) {
                webDevices = getWebDeviceSpecs("$.web");
            } else {
                webDevices = getWebDeviceSpecs("$.mobile");
            }
            int sizeWebDevices = webDevices == null ? 0 : webDevices.size();
            if (sizeWebDevices < 1) {
                logger.error(getFailedstep("Incorrect configuration. " + "DEVICE_" + driverType.toUpperCase() + TO_BE_SETUP_CORRECTLY));
            }

            if (Utils.isWebTest(null) && targetedWebBrowserType != null) {
                validateDevicesAgainstLoadedConfigForWeb(sizeWebDevices);
            } else if (Utils.isMobileTest(null) && targetedMobileDeviceName != null) {
                validateDevicesAgainstLoadedConfigForMobile(sizeWebDevices);
            }
        }
    }

    private static void validateDevicesAgainstLoadedConfigForMobile(int sizeWebDevices) {
        int totalBrowsers = 0;
        for (int indx = 1; indx <= sizeWebDevices; indx++) {
            Map<String, String> brwSpecs = getWebDeviceSpecs("$.mobile.device" + indx);
            assert brwSpecs != null;
            if (targetedMobileDeviceName.equalsIgnoreCase(brwSpecs.get(PLATFORM_NAME))) {
                totalBrowsers++;
            }
        }
        if (totalBrowsers < 1) {
            logger.error(getFailedstep(INCORRECT_CONFIGURATION_FOR + targetedMobileDeviceName.toUpperCase() + ". DEVICE_" + driverType.toUpperCase() + TO_BE_SETUP_CORRECTLY));
        }
    }

    private static void validateDevicesAgainstLoadedConfigForWeb(int sizeWebDevices) {
        int totalBrowsers = 0;
        for (int indx = 1; indx <= sizeWebDevices; indx++) {
            Map<String, String> brwSpecs = getWebDeviceSpecs(WEB_DEVICE + indx);
            assert brwSpecs != null;
            if (targetedWebBrowserType.equalsIgnoreCase(brwSpecs.get(BROWSER_TYPE))) {
                totalBrowsers++;
            }
        }
        if (totalBrowsers < 1) {
            logger.error(getFailedstep(INCORRECT_CONFIGURATION_FOR + targetedWebBrowserType.toUpperCase() + ". DEVICE_" + driverType.toUpperCase() + TO_BE_SETUP_CORRECTLY));
        }
    }

    String storeInStringJson(Map<String, String> template) {
        count = count + 1;
        devicesRemote = devicesRemote.concat("device" + count + ":" + "{" + "\"browserType\"" + ":" + "\"" + template.get(BROWSER_TYPE) + "\"" + "," + "\"browserVersion\"" + ":" + "\"" + template.get("browserVersion") + "\"" + "," + "\"platformName\"" + ":" + "\"" + template.get(PLATFORM_NAME) + "\"" + "," + "\"platformVersion\"" + ":" + "\"" + template.get("platformVersion") + "\"" + "," + "\"resolution\"" + ":" + "\"" + template.get(RESOLUTION) + "\"" + "}" + ",");
        return devicesRemote;
    }

    ArrayList<String> valuesfromPropertyFile(String deviceMatrix, String propertyKey) {
        String[] str = deviceMatrix.split(":");
        int i;
        for (i = 0; i < str.length; i++) {
            int index = str[i].indexOf("=");
            String key = str[i].substring(0, index);
            if (key.equalsIgnoreCase(propertyKey)) {
                str[i] = str[i].replace(key, "").replace("=", "");
                String[] result = str[i].split(";");
                return new ArrayList<>(Arrays.asList(result));
            }
        }
        return new ArrayList<>();
    }

    boolean validateString(String s, ArrayList<String> list) {
        for (String str : list) {
            if (str.equalsIgnoreCase(s))
                return true;
        }
        return false;
    }
}