package com.qe.framework.common;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class FeedFileParser {
    private FeedFileParser() {
    }

    private static final Logger logger = LoggerFactory.getLogger(FeedFileParser.class);
    
    private static final String ATTRIBUTE_ID ="AttributeID";
    private static final String ATTRIBUTE_HYPHEN_ID ="attribute-id";
    private static final String DISPLAY_HYPHEN_NAME = "display-name";
    private static final String TAG_VALUE ="Value";

    public static void parseTaxonomyFileToCSV(String path, Document doc) throws IOException {

        try (BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(path))) {
            StringBuilder headers = new StringBuilder("Parent" + "," + "Name");

            NodeList nodeList = doc.getElementsByTagName("Classification");
            for (int itr = 2; itr < nodeList.getLength(); itr++) {
                Node node = nodeList.item(itr);
                Element eElement = (Element) node;
                String name = eElement.getElementsByTagName("Name").item(0).getTextContent();
                String parent = eElement.getElementsByTagName("Name").item(0).getParentNode().getParentNode().getAttributes().getNamedItem("ID").getTextContent();
                StringBuilder data = new StringBuilder(parent + "," + name + ",");
                NodeList nodeList1 = eElement.getElementsByTagName(TAG_VALUE);
                String attribute;
                for (int i = 0; i < 3; i++) {
                    attribute = nodeList1.item(i).getAttributes().getNamedItem(ATTRIBUTE_ID).getTextContent();
                    headers = new StringBuilder(headers + "," + attribute);
                    if (attribute.equalsIgnoreCase("Category_ID")) {
                        data = new StringBuilder(data + "," + "," + nodeList1.item(1).getTextContent() + ",");
                        break;
                    }
                    data = new StringBuilder(data + nodeList1.item(i).getTextContent() + ",");
                }
                if (itr == 2) {
                    headers = new StringBuilder(headers + "," + "Category_ID");
                    bufferedWriter.write(String.valueOf(headers));
                }
                bufferedWriter.newLine();
                bufferedWriter.write(String.valueOf(data));
            }
            bufferedWriter.flush();
        }
    }

    public static void parseProductFileToCSV(String path, Document doc) throws IOException {
        String productId = ""; //sku
        String displayName = ""; // name
        String pageUrl = ""; // url
        String primaryImage = ""; // image_url
        String character = ""; // character
        String licence = ""; // licence
        String colour = ""; // colour
        String size = ""; // size
        String trend = ""; // trend
        String allowedCountries = ""; // allowed_countries
        String categoryId = ""; // category_id
        String brand = ""; // brand
        String searchableFlag = ""; // searchable
        String onlineFrom = ""; // online_from
        String onlineFlag = ""; // online

        try (BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(path))) {
            StringBuilder header = new StringBuilder("sku,name,url,image_url,character,licence,colour,size,trend,"
                    + "allowed_countries,category_id,brand,searchable,online_from,online");
            bufferedWriter.write(header.toString());
            NodeList nodeList = doc.getElementsByTagName("product");
            for (int itr = 0; itr < nodeList.getLength(); itr++) {
                Node node = nodeList.item(itr);
                StringBuilder data = new StringBuilder();
                if (node.getNodeType() == Node.ELEMENT_NODE) {
                    productId = ((Element) node).getAttribute("product-id");
                    data.append(productId);

                    Element fstElement = (Element) node;
                    if (fstElement.getElementsByTagName(DISPLAY_HYPHEN_NAME).getLength() > 0) {
                        displayName = fstElement.getElementsByTagName(DISPLAY_HYPHEN_NAME).item(0).getChildNodes().item(0).getNodeValue();
                    }
                    data.append(",").append(displayName);

                    NodeList productElements = node.getChildNodes();
                    for (int i = 0; i < productElements.getLength(); i++) {
                        Node productNode = productElements.item(i);

                        if (productNode.getNodeType() == Node.ELEMENT_NODE && productNode.getNodeName().equals("page-attributes")) {
                            Element pageAttrElmnt = (Element) productNode;
                            NodeList pageUrlNodeList = pageAttrElmnt.getElementsByTagName("page-url");
                            if (pageUrlNodeList.getLength() > 0) {
                                pageUrl = pageUrlNodeList.item(0).getTextContent();
                            }
                        }

                        if (productNode.getNodeType() == Node.ELEMENT_NODE && productNode.getNodeName().equals("custom-attributes")) {
                            Element customAttrElmnt = (Element) productNode;
                            NodeList custAttrList = customAttrElmnt.getElementsByTagName("custom-attribute");
                            for (int j = 0; j < custAttrList.getLength(); j++) {
                                if (custAttrList.item(j).getAttributes().getNamedItem(ATTRIBUTE_HYPHEN_ID).getNodeValue().equals("primaryImage")) {
                                    primaryImage = custAttrList.item(j).getTextContent();
                                } else if (custAttrList.item(j).getAttributes().getNamedItem(ATTRIBUTE_HYPHEN_ID).getNodeValue().equals("character")) {
                                    character = custAttrList.item(j).getTextContent();
                                } else if (custAttrList.item(j).getAttributes().getNamedItem(ATTRIBUTE_HYPHEN_ID).getNodeValue().equals("licence")) {
                                    licence = custAttrList.item(j).getTextContent();
                                } else if (custAttrList.item(j).getAttributes().getNamedItem(ATTRIBUTE_HYPHEN_ID).getNodeValue().equals("colour")) {
                                    colour = custAttrList.item(j).getTextContent();
                                } else if (custAttrList.item(j).getAttributes().getNamedItem(ATTRIBUTE_HYPHEN_ID).getNodeValue().equals("size")) {
                                    size = custAttrList.item(j).getTextContent();
                                } else if (custAttrList.item(j).getAttributes().getNamedItem(ATTRIBUTE_HYPHEN_ID).getNodeValue().equals("trend")) {
                                    trend = custAttrList.item(j).getTextContent();
                                } else if (custAttrList.item(j).getAttributes().getNamedItem(ATTRIBUTE_HYPHEN_ID).getNodeValue().equals("allowedCountries")
                                        && custAttrList.item(j).getNodeType() == Node.ELEMENT_NODE) {
                                    Element custAttrElmnt = (Element) custAttrList.item(j);
                                    NodeList allowedCountriesEle = custAttrElmnt.getElementsByTagName(TAG_VALUE);
                                    if (allowedCountriesEle.getLength() > 0) {
                                        allowedCountries = allowedCountriesEle.item(0).getTextContent();
                                    }
                                }
                            }
                        }
                        if (productNode.getNodeType() == Node.ELEMENT_NODE && productNode.getNodeName().equals("classification-category")
                                && productNode.getAttributes().getNamedItem("catalog-id").getNodeValue().equals("ASDACatalog")) {
                            categoryId = productNode.getTextContent();
                        }
                    }
                    data.append(",").append(pageUrl).append(",").append(primaryImage).append(",").append(character).append(",").append(licence).append(",").append(colour).append(",").append(size).append(",").append(trend).append(",").append(allowedCountries).append(",").append(categoryId);

                    if (fstElement.getElementsByTagName("brand").getLength() > 0) {
                        brand = fstElement.getElementsByTagName("brand").item(0).getChildNodes().item(0).getNodeValue();
                    }
                    if (fstElement.getElementsByTagName("searchable-flag").getLength() > 0) {
                        searchableFlag = fstElement.getElementsByTagName("searchable-flag").item(0).getChildNodes().item(0).getNodeValue();
                    }
                    if (fstElement.getElementsByTagName("online-from").getLength() > 0) {
                        onlineFrom = fstElement.getElementsByTagName("online-from").item(0).getChildNodes().item(0).getNodeValue();
                    }
                    if (fstElement.getElementsByTagName("online-flag").getLength() > 0) {
                        onlineFlag = fstElement.getElementsByTagName("online-flag").item(0).getChildNodes().item(0).getNodeValue();
                    }
                    data.append(",").append(brand).append(",").append(searchableFlag).append(",").append(onlineFrom).append(",").append(onlineFlag);

                }
                bufferedWriter.newLine();
                bufferedWriter.write(String.valueOf(data));
                logger.info("parseProductFileToCSV - Adding this data --> {}", data);
            }
            bufferedWriter.flush();
        }
    }

    public static void parsePriceFileToCSV(String path, Document doc) throws IOException {
        String productId = "";
        String amount = "";

        try (BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(path))) {
            StringBuilder header = new StringBuilder("product_id,amount");
            bufferedWriter.write(header.toString());
            NodeList nodeList = doc.getElementsByTagName("price-table");
            for (int itr = 0; itr < nodeList.getLength(); itr++) {
                Node node = nodeList.item(itr);
                StringBuilder data = new StringBuilder();
                if (node.getNodeType() == Node.ELEMENT_NODE) {
                    productId = ((Element) node).getAttribute("product-id");
                    data.append(productId);

                    Element fstElement = (Element) node;
                    if (fstElement.getElementsByTagName("amount").getLength() > 0) {
                        amount = fstElement.getElementsByTagName("amount").item(0).getChildNodes().item(0).getNodeValue();
                    }
                    data.append(",").append(amount);
                    bufferedWriter.newLine();
                    bufferedWriter.write(String.valueOf(data));
                }
            }
            bufferedWriter.flush();
        }
    }

    public static void parseGeorgeTaxonomyFileToCSV(String path, Document doc) throws IOException {
        String categoryId = "";
        String displayName = "";
        String parent = "";

        try (BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(path))) {
            StringBuilder header = new StringBuilder("category_id,display_name,parent");
            bufferedWriter.write(header.toString());
            NodeList nodeList = doc.getElementsByTagName("category");
            for (int itr = 0; itr < nodeList.getLength(); itr++) {
                Node node = nodeList.item(itr);
                StringBuilder data = new StringBuilder();
                if (node.getNodeType() == Node.ELEMENT_NODE) {
                    categoryId = ((Element) node).getAttribute("category-id");
                    data.append(categoryId);

                    Element fstElement = (Element) node;
                    if (fstElement.getElementsByTagName(DISPLAY_HYPHEN_NAME).getLength() > 0) {
                        displayName = fstElement.getElementsByTagName(DISPLAY_HYPHEN_NAME).item(0).getChildNodes().item(0).getNodeValue();
                    }
                    if (fstElement.getElementsByTagName("parent").getLength() > 0) {
                        parent = fstElement.getElementsByTagName("parent").item(0).getChildNodes().item(0).getNodeValue();
                    }
                    data.append(",").append(displayName).append(",").append(parent);
                    bufferedWriter.newLine();
                    bufferedWriter.write(String.valueOf(data));
                }
            }
            bufferedWriter.flush();
        }
    }

    public static void parseGHSProductFileToCSV(String path, Document doc) throws IOException {
        String productId = "";
        String name = "";
        String composition = "";
        String shelfType = "";
        String gender = "";
        String skuEndDate = "";
        String itemNumber = "";
        String brandId = "";
        String skuStartDate = "";
        String isFresh = "";

        try (BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(path))) {
            StringBuilder header = new StringBuilder("product_id,name,composition,shelf_type,gender,sku_end_date," +
                    "item_number,brand_id,sku_start_date,is_fresh");
            bufferedWriter.write(header.toString());
            NodeList nodeList = doc.getElementsByTagName("Product");
            for (int itr = 0; itr < nodeList.getLength(); itr++) {
                Node node = nodeList.item(itr);
                StringBuilder data = new StringBuilder();
                if (node.getNodeType() == Node.ELEMENT_NODE) {
                    productId = ((Element) node).getAttribute("ID");
                    data.append(productId);

                    Element fstElement = (Element) node;
                    if (fstElement.getElementsByTagName("Name").getLength() > 0) {
                        name = fstElement.getElementsByTagName("Name").item(0).getChildNodes().item(0).getNodeValue();
                    }

                    NodeList productElements = node.getChildNodes();
                    for (int i = 0; i < productElements.getLength(); i++) {
                        if (productElements.item(i).getNodeType() == Node.ELEMENT_NODE && productElements.item(i).getNodeName().equals("Values")) {
                            NodeList valueList = ((Element) productElements.item(i)).getElementsByTagName(TAG_VALUE);
                            for (int j = 0; j < valueList.getLength(); j++) {
                                if (valueList.item(j).getAttributes().getLength() > 0) {
                                    if (valueList.item(j).getAttributes().getNamedItem(ATTRIBUTE_ID).getNodeValue().equals("Composition")) {
                                        composition = valueList.item(j).getTextContent();
                                    }
                                    if (valueList.item(j).getAttributes().getNamedItem(ATTRIBUTE_ID).getNodeValue().equals("Shelf_Type")) {
                                        shelfType = valueList.item(j).getTextContent();
                                    }
                                    if (valueList.item(j).getAttributes().getNamedItem(ATTRIBUTE_ID).getNodeValue().equals("Gender")) {
                                        gender = valueList.item(j).getTextContent();
                                    }
                                    if (valueList.item(j).getAttributes().getNamedItem(ATTRIBUTE_ID).getNodeValue().equals("SKU_End_Date")) {
                                        skuEndDate = valueList.item(j).getTextContent();
                                    }
                                    if (valueList.item(j).getAttributes().getNamedItem(ATTRIBUTE_ID).getNodeValue().equals("Item_Number")) {
                                        itemNumber = valueList.item(j).getTextContent();
                                    }
                                    if (valueList.item(j).getAttributes().getNamedItem(ATTRIBUTE_ID).getNodeValue().equals("Brand_ID")) {
                                        brandId = valueList.item(j).getTextContent();
                                    }
                                    if (valueList.item(j).getAttributes().getNamedItem(ATTRIBUTE_ID).getNodeValue().equals("SKU_Start_Date")) {
                                        skuStartDate = valueList.item(j).getTextContent();
                                    }
                                    if (valueList.item(j).getAttributes().getNamedItem(ATTRIBUTE_ID).getNodeValue().equals("Is_Fresh")) {
                                        isFresh = valueList.item(j).getTextContent();
                                    }
                                }
                            }
                        }
                    }
                    data.append("," + name + "," + composition + "," + shelfType + "," + gender + "," + skuEndDate + "," + itemNumber
                            + "," + brandId + "," + skuStartDate + "," + isFresh);
                    bufferedWriter.newLine();
                    bufferedWriter.write(String.valueOf(data));
                }
            }
            bufferedWriter.flush();
        }
    }

    public static void parseGHSBundleFileToCSV(String path, Document doc) throws IOException {
        String skuId = "";
        String bundleId = "";
        String consumerItemNumber = "";
        String bundleDisplayOnline = "";
        String bundleStatus = "";
        String bundleStartDate = "";
        String bundleEndDate = "";
        String bundleDisplayName = "";
        String maxOrderQuantity = "";
        String maxQuantityHSC = "";
        String bundleIsBWS = "";
        String imageId = "";
        String primaryShelf = "";
        String bundleAdditionalInfo = "";
        String bundleSkuCinId = "";

        try (BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(path))) {
            StringBuilder header = new StringBuilder("sku_id,bundle_id,consumer_item_number,bundle_display_online,bundle_status,bundle_start_date,"
                    + "bundle_end_date,bundle_display_name,maximum_order_quantity,maximum_quantity_hsc,bundle_is_bws,image_id,primary_shelf,"
                    + "bundle_additional_information,bundle_sku_cin_ids");
            bufferedWriter.write(header.toString());
            NodeList nodeList = doc.getElementsByTagName("Product");
            for (int itr = 0; itr < nodeList.getLength(); itr++) {
                Node node = nodeList.item(itr);
                StringBuilder data = new StringBuilder();
                if (node.getNodeType() == Node.ELEMENT_NODE) {
                    skuId = ((Element) node).getAttribute("ID");
                    data.append(skuId);

                    NodeList productElements = node.getChildNodes();
                    for (int i = 0; i < productElements.getLength(); i++) {
                        StringBuilder multiValueData = null;
                        if (productElements.item(i).getNodeType() == Node.ELEMENT_NODE && productElements.item(i).getNodeName().equals("Values")) {
                            NodeList valueList = ((Element) productElements.item(i)).getElementsByTagName(TAG_VALUE);
                            for (int j = 0; j < valueList.getLength(); j++) {
                                if (valueList.item(j).getAttributes().getLength() > 0) {
                                    if (valueList.item(j).getAttributes().getNamedItem(ATTRIBUTE_ID).getNodeValue().equals("Bundle_ID")) {
                                        bundleId = valueList.item(j).getTextContent();
                                    }
                                    if (valueList.item(j).getAttributes().getNamedItem(ATTRIBUTE_ID).getNodeValue().equals("Consumer_Item_Number")) {
                                        consumerItemNumber = valueList.item(j).getTextContent();
                                    }
                                    if (valueList.item(j).getAttributes().getNamedItem(ATTRIBUTE_ID).getNodeValue().equals("Bundle_Display_Online")) {
                                        bundleDisplayOnline = valueList.item(j).getTextContent();
                                    }
                                    if (valueList.item(j).getAttributes().getNamedItem(ATTRIBUTE_ID).getNodeValue().equals("Bundle_Status")) {
                                        bundleStatus = valueList.item(j).getTextContent();
                                    }
                                    if (valueList.item(j).getAttributes().getNamedItem(ATTRIBUTE_ID).getNodeValue().equals("Bundle_Start_Date")) {
                                        bundleStartDate = valueList.item(j).getTextContent();
                                    }
                                    if (valueList.item(j).getAttributes().getNamedItem(ATTRIBUTE_ID).getNodeValue().equals("Bundle_End_Date")) {
                                        bundleEndDate = valueList.item(j).getTextContent();
                                    }
                                    if (valueList.item(j).getAttributes().getNamedItem(ATTRIBUTE_ID).getNodeValue().equals("Bundle_Display_Name")) {
                                        bundleDisplayName = valueList.item(j).getTextContent();
                                    }
                                    if (valueList.item(j).getAttributes().getNamedItem(ATTRIBUTE_ID).getNodeValue().equals("Maximum_Order_Quantity")) {
                                        maxOrderQuantity = valueList.item(j).getTextContent();
                                    }
                                    if (valueList.item(j).getAttributes().getNamedItem(ATTRIBUTE_ID).getNodeValue().equals("Maximum_Quantity_HSC")) {
                                        maxQuantityHSC = valueList.item(j).getTextContent();
                                    }
                                    if (valueList.item(j).getAttributes().getNamedItem(ATTRIBUTE_ID).getNodeValue().equals("Bundle_Is_BWS")) {
                                        bundleIsBWS = valueList.item(j).getTextContent();
                                    }
                                    if (valueList.item(j).getAttributes().getNamedItem(ATTRIBUTE_ID).getNodeValue().equals("Scene7_Image_ID")) {
                                        imageId = valueList.item(j).getTextContent();
                                    }
                                    if (valueList.item(j).getAttributes().getNamedItem(ATTRIBUTE_ID).getNodeValue().equals("Primary_Shelf")) {
                                        primaryShelf = valueList.item(j).getTextContent();
                                    }
                                    if (valueList.item(j).getAttributes().getNamedItem(ATTRIBUTE_ID).getNodeValue().equals("Bundle_Additional_Information")) {
                                        bundleAdditionalInfo = valueList.item(j).getTextContent();
                                    }
                                }
                            }
                            NodeList multiValueList = ((Element) productElements.item(i)).getElementsByTagName("MultiValue");
                            multiValueData = new StringBuilder();
                            for (int j = 0; j < multiValueList.getLength(); j++) {
                                if ((multiValueList.item(j).getAttributes().getLength() > 0) && (multiValueList.item(j).getAttributes().getNamedItem(ATTRIBUTE_ID).getNodeValue().equals("Bundle_SKU_CIN_IDs"))) {
                                    multiValueData.append(multiValueList.item(j).getTextContent().trim().replace("\n", "|")
                                            .replace(" ", ""));
                                }
                            }
                            bundleSkuCinId = multiValueData.toString();
                        }
                    }
                    data.append(",").append(bundleId).append(",").append(consumerItemNumber).append(",").append(bundleDisplayOnline).append(",").append(bundleStatus).append(",").append(bundleStartDate).append(",").append(bundleEndDate).append(",").append(bundleDisplayName).append(",").append(maxOrderQuantity).append(",").append(maxQuantityHSC).append(",").append(bundleIsBWS).append(",").append(imageId).append(",").append(primaryShelf).append(",").append(bundleAdditionalInfo).append(",").append(bundleSkuCinId);
                    bufferedWriter.newLine();
                    bufferedWriter.write(String.valueOf(data));
                }
            }
            bufferedWriter.flush();
        }
    }
}
