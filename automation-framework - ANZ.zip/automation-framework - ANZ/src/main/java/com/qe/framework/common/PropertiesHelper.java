package com.qe.framework.common;

import com.qe.framework.azure.AzureVault;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Map;
import java.util.Properties;

import static com.qe.framework.common.Constants.*;
import static org.junit.Assert.assertTrue;

public class PropertiesHelper {
    public static final ContextMap contextMap = new ContextMap();
    public static final String USER_DIR = "user.dir";
    public static final String TARGETED_ENVIRONMENT = "targeted.environment";
    private static final Logger logger = LoggerFactory.getLogger(PropertiesHelper.class);
    private static final Properties configProp = new Properties();
    public static final String CAPTURE_ONLY_FAIL = configProp.getProperty("CaptureScreenShot");
    public static final String CAPTURE_SCREEN_SHOT = configProp.getProperty("CaptureOnlyFAIL");
    private final Properties apiEndPoints = new Properties();
    private final Properties azureProps = new Properties();
    private final Properties apiEndPointArgs = new Properties();
    private final Properties apiBodyValuesProp = new Properties();
    private final Properties jiraAtmProperty = new Properties();
    private final Properties testDataProperty = new Properties();
    private final Properties analyticsDataProperty = new Properties();
    private final Properties queriesProp = new Properties();
    private final Properties queriesFeedFileProp = new Properties();

    private PropertiesHelper() {
        logger.debug("Read all properties from file");
        OSInfo.getOs();

        try {
            FileInputStream configPropFis;
            configPropFis = getFileInputStrem(System.getProperty(USER_DIR) + "/src/test/resources/config/Config_Local.properties");
            if (configPropFis != null) {
                configProp.load(configPropFis);
            } else {
                configPropFis = getFileInputStrem(System.getProperty(USER_DIR) + "/src/test/resources/config/Config.properties");
                if (configPropFis != null) {
                    configProp.load(configPropFis);
                }
            }
            logger.debug("Config properties file load - Done.");

            readCommandLineParams();

            AzureVault.vaultConnectionBuilder();

            sanitizeConfigurationAndTotalForks();

//            Now we will start reading other relevant Property files
            FileInputStream apiEndPointFis = getFileInputStrem(System.getProperty(USER_DIR) + "/src/test/resources/object_repo/api/EndPoints.properties");
            if (apiEndPointFis != null) {
                apiEndPoints.load(apiEndPointFis);
            }

            FileInputStream apiEndPointArgsFis = getFileInputStrem(System.getProperty(USER_DIR) + "/src/test/resources/object_repo/api/EndPointArguement.properties");
            if (apiEndPointArgsFis != null) {
                apiEndPointArgs.load(apiEndPointArgsFis);
            }

//          :: FUTURE ::
//            FileInputStream mobileViewPropFis = getFileInputStrem(System.getProperty(USER_DIR) + "/src/test/resources/config/MobileViewportConfig.properties");
//            if (mobileViewPropFis != null) {
//                mobileDimension.load(mobileViewPropFis);
//            }

            FileInputStream jiraAtmFis = getFileInputStrem(System.getProperty(USER_DIR) + "/src/test/resources/config/JiraAtm.properties");
            if (jiraAtmFis != null) {
                jiraAtmProperty.load(jiraAtmFis);
            }

            String testdataPropFileName;
            testdataPropFileName = targetEnvName.toLowerCase() + "_" + appType + "_TestData.properties";
            logger.debug("testdatafilename::{}", testdataPropFileName);

//            if (testdataPropFileName != null && testdataPropFileName.length() > 1) {
//                if (!testdataPropFileName.contains(".properties")) {
//                    testdataPropFileName = testdataPropFileName + ".properties";
//                }
//                logger.debug("Final testdatafilename::" + testdataPropFileName);
            FileInputStream testDataPropFis = getFileInputStrem(System.getProperty(USER_DIR) + "/src/test/resources/TestData/" + testdataPropFileName);
            if (testDataPropFis != null) {
                testDataProperty.load(testDataPropFis);
            }

            FileInputStream queriesPropertyFile = getFileInputStrem(System.getProperty(USER_DIR) + "/src/test/resources/sqlQueries/SqlQueries.properties");
            if (queriesPropertyFile != null) {
                queriesProp.load(queriesPropertyFile);
            }


            FileInputStream queriesFeedFile = getFileInputStrem(System.getProperty(USER_DIR) + "/src/test/resources/TestData/FeedFiles/inputs/SqlQueries/SqlQueries.properties");
            if (queriesPropertyFile != null) {
                queriesFeedFileProp.load(queriesFeedFile);
            }

            Constants.threadHighest = getWaitTimeProperty("THREAD_HIGHEST");
            Constants.threadHigh = getWaitTimeProperty("THREAD_HIGH");
            Constants.threadMedium = getWaitTimeProperty("THREAD_MEDIUM");
            Constants.threadLow = getWaitTimeProperty("THREAD_LOW");
            Constants.explicitWaitTime = getWaitTimeProperty("WEBDRIVER_EXPLICIT_WAITTIME_SECONDS");
            Constants.implicitWaitTime = getWaitTimeProperty("WEBDRIVER_IMPLICIT_WAITTIME_SECONDS");
            Constants.pageLoadWaitTime = getWaitTimeProperty("PAGELOAD_WAITTIME_SECONDS");
            Constants.fluentWaitTime = getWaitTimeProperty("WEBDRIVER_FLUENT_WAITTIME_SECONDS");
            Constants.fluentPollingWaitTime = getWaitTimeProperty("WEBDRIVER_FLUENTPOLLING_WAITTIME_SECONDS");


        } catch (IOException e) {
            logger.error("PropertiesHelper IOException:: {}", e.getMessage());
        }

    }

    private static void readCommandLineParams() {
        driverType = System.getProperty("driverType");
        if (driverType == null) {
            driverType = getConfigPropProperty("driverType");
        }

        appType = System.getProperty("AppType");
        if (appType == null) {
            appType = getConfigPropProperty("AppType");
        }

        targetedWebBrowserType = System.getProperty("targeted.web.browserType");
        if (targetedWebBrowserType == null) {
            targetedWebBrowserType = getConfigPropProperty("targeted.web.browserType");
        }

        targetedMobileDeviceName = System.getProperty("targeted.mobile.deviceName");
        if (targetedMobileDeviceName == null) {
            targetedMobileDeviceName = getConfigPropProperty("targeted.mobile.deviceName");
        }

        userDeviceMatrix = System.getProperty("targeted.web.deviceMatrix");
        baseDeviceMatrix = getConfigPropProperty("targeted.web.deviceMatrix");

        try {
            forkCount = Integer.parseInt(System.getProperty("forkCount"));
            modeOfExecParallel = forkCount > 1;
        } catch (Exception e) {
            forkCount = 1;
            modeOfExecParallel = false;
        }

        readCommandLineParamsForTokens();

        targetEnvName = System.getProperty(TARGETED_ENVIRONMENT);
        if (targetEnvName == null) {
            if (configProp.getProperty(TARGETED_ENVIRONMENT) != null) {
                targetEnvName = configProp.getProperty(TARGETED_ENVIRONMENT);
            } else {
                targetEnvName = "QA";
            }
        }
    }

    private static void readCommandLineParamsForTokens() {
        if (Utils.isWebTest(null) || Utils.isMobileTest(null)) {
            cloudLabName = System.getProperty("cloudLabName");
            cloudSecurityToken = System.getProperty("cloudSecurityToken");
            if (cloudLabName == null || cloudSecurityToken == null) {
                cloudLabName = configProp.getProperty("cloudLabName");
                cloudSecurityToken = configProp.getProperty("cloudSecurityToken");
            }
        }

        if (Utils.isWebTest("web")) {
            gitHubPAT = System.getProperty("gitHubPAT");
            if (gitHubPAT == null) {
                gitHubPAT = configProp.getProperty("gitHubPAT");
            }
        }
    }

    public static int getWaitTimeProperty(String key) {
        int wait = 10;
        try {
            String waitTimeStr = getConfigPropProperty(key);
            if (waitTimeStr != null && waitTimeStr.matches("-?\\d+")) {
                wait = Integer.parseInt(waitTimeStr);
            }
        } catch (Exception e) {
            logger.error("getImplicitWaitTime error msg:: {}", e.getMessage());

        }
        return wait;
    }

    public static PropertiesHelper getInstance() {
        return LazyHolder.INSTANCE;
    }

    public static String getConfigPropProperty(String key) {
        return configProp.getProperty(key);
    }

    private void sanitizeConfigurationAndTotalForks() throws IOException {
        CloudConfig.sanitizeConfiguration();
        if (Utils.isWebTest(null) || Utils.isMobileTest(null)) {
            if (Utils.isWebTest(null)) {
                Map<String, String> totalWebDevices = CloudConfig.getWebDeviceSpecs("$.web");
                logger.info("first {}  {}", (totalWebDevices.size() >= 1), (forkCount >= 1));
                assertTrue(ERRFORKGRTDEVICES, (totalWebDevices.size() >= 1 && forkCount >= 1));
            } else if (Utils.isMobileTest(null)) {
                if (targetedMobileDeviceName == null || targetedMobileDeviceName.equalsIgnoreCase("any")) {
                    Map<String, String> totalDevices = CloudConfig.getWebDeviceSpecs("$.mobile");
                    assertTrue(ERRFORKGRTDEVICES, totalDevices.size() >= forkCount);
                } else {
                    int totalMobileDevices = CloudConfig.getCountByTargetedDeviceType();
                    logger.info("totalMobileDevices: {}", totalMobileDevices);
                    logger.info("forkCount: {}", forkCount);
                    assertTrue(ERRFORKGRTDEVICES, totalMobileDevices >= forkCount);
                }
            }
        }
    }

    public Properties loadPropertyFile(String absolutepath) throws IOException {
        Properties propFile = new Properties();
        try (FileInputStream propFileFis = new FileInputStream(absolutepath)) {
            propFile.load(propFileFis);
        } catch (IOException e) {
            logger.error("PropertiesHelper.loadPropertyFile Exception:: {}", e.getMessage());
        }
        return propFile;
    }

    public boolean containsKeyFromConfigProp(String key) {
        return configProp.containsKey(key);
    }

    public String getAnayticsDataProperty(String key) {
        return analyticsDataProperty.getProperty(key);
    }

    public String getTestDataProperty(String key) {
        return testDataProperty.getProperty(key);
    }

    public String getEndpointProProperty(String key) {
        return apiEndPoints.getProperty(key);
    }

    public String getAzureProperties(String key) {
        return azureProps.getProperty(key);
    }

    public String getEndpointArgsProperty(String key) {
        return apiEndPointArgs.getProperty(key);
    }

    public String getApiBodyValuesProperty(String key) {
        return apiBodyValuesProp.getProperty(key);
    }

    public FileInputStream getFileInputStrem(String filePath) {
        FileInputStream fileInputStrem = null;
        try {
            fileInputStrem = new FileInputStream(filePath);
        } catch (Exception e) {
            logger.warn("FILE NOT FOUND:: {}", filePath);
        }
        return fileInputStrem;
    }

    public String getJiraAtmProperty(String key) {
        return jiraAtmProperty.getProperty(key);
    }

    public String getFeedFileQueriesProperty(String key) {
        if (queriesFeedFileProp.containsKey(key)) {
            return queriesFeedFileProp.getProperty(key);
        } else {
            return queriesProp.getProperty(key);
        }
    }

    // singleton pattern
    private static class LazyHolder {
        private static final PropertiesHelper INSTANCE = new PropertiesHelper();

    }
}
