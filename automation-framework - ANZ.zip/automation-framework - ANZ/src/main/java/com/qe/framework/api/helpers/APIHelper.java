package com.qe.framework.api.helpers;

import com.qe.framework.common.PropertiesHelper;
import com.qe.framework.common.Utils;
import com.qe.framework.customexception.ExceptionAndErrors;
import io.restassured.http.Cookies;
import io.restassured.http.Header;
import io.restassured.http.Headers;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.*;

import static com.qe.framework.common.PropertiesHelper.contextMap;
import static com.qe.framework.common.PropertiesHelper.getConfigPropProperty;
import static io.restassured.RestAssured.given;

public class APIHelper {
    private static final Logger logger = LoggerFactory.getLogger(APIHelper.class);
    private static final String PASSWORD = "password";
    private static final String USERNAME = "userName";
    private static final String SCOPE = "scope";
    public static Response response;
    public static Cookies reqCookies;
    public static String newRecord;
    public static Headers reqHeaders;
    private static final String VCLIENTID = "client_id";
    private static final String TCLIENTID = "clientId";

    private static final String VAUTHURL = "authUrl";
    private static final String VACCESSTOKEN = "access_token";

    private static final String VCUSTOMERID = "customer_id";
    public static final String PREPDATAPREFIX = "/APIConfig/";
    private static final String AUTHBASETEMPLATE = "AuthBaseTemplate";

    public static final PropertiesHelper loadProps = PropertiesHelper.getInstance();
    private String bodyPayload;
    private static String apiResponse;

    public static void setHeader(String key, String value) {
        Header header = null;
        List<Header> headerlist = new ArrayList<>();
        header = new Header(key, value);
        headerlist.add(header);
        reqHeaders = new Headers(headerlist);
    }

    public static void triggerAPICall(String url, String callType, RequestSpecification request) {
        try {
            switch (callType) {
                case "POST":
                    response = request.post(url);
                    break;
                case "PATCH":
                    response = request.patch(url);
                    break;
                case "PUT":
                    response = request.put(url);
                    break;
                case "GET":
                    response = request.get(url);
                    break;
                case "DELETE":
                    response = request.delete(url);
                    break;
                default:
                    ExceptionAndErrors.getAPIFailedstep("Incorrect API call value");
            }
            logger.info("{} API call triggered on url : {}", callType, url);
        } catch (Exception e) {
            logger.info("CallType:"+url);
            logger.error("InitiateRestAPICall exception msg:: {}", e.getMessage());
        } finally {
            reqCookies = null;
        }
    }

    public String getBodyPayload() {
        return bodyPayload;
    }

    public void setBodyPayload(String bodyPayload) {
        this.bodyPayload = bodyPayload;
    }

    public static String getApiResponse() {
        return apiResponse;
    }

    public static void setApiResponse(String apiResponse) {
        APIHelper.apiResponse = apiResponse;
    }

    public static Response getResponse() {
        return response;
    }

    public static void setResponse(Response response) {
        APIHelper.response = response;
    }

    public String toString() {
        return APIHelper.response.asString();
    }

    public int getStatusCode() {
        return APIHelper.response.statusCode();
    }

    public Headers getHeaders() {
        return APIHelper.response.headers();
    }

    public RequestSpecification buildAPICall(String payLoads) {
        RequestSpecification request = null;
        try {
            request = given().relaxedHTTPSValidation();
            if (reqHeaders != null) {
                request = request.headers(reqHeaders);
            }
            if (payLoads != null) {
                request = request.body(payLoads);
            }
            if (reqCookies != null) {
                request = request.cookies(reqCookies);
            }
            logger.debug("RequestSpecification created for API call");
        } catch (Exception e) {
            logger.error("buildAPICall exception msg:: {}", e.getMessage());
        }
        return request;
    }

    public String initiateAuthCallToToken(String path) {
        Map<String, Object> authFormParams = new HashMap<>();
        ArrayList<String> tmplAuthParams = new ArrayList<>();

        String authParamTemplate = getConfigPropProperty(AUTHBASETEMPLATE) + "," + getConfigPropProperty("AuthParamsTemplate");
        String[] authParamTemplSplit = authParamTemplate.split(",");
        Collections.addAll(tmplAuthParams, authParamTemplSplit);

        String tmpString;
        for (String itm : tmplAuthParams) {
            tmpString = Utils.prepareDataString(PREPDATAPREFIX + path + "." + itm);
            if (tmpString.contains(itm) || tmpString.contains(path)) {
                tmpString = null;
            }
            authFormParams.put(itm, tmpString);
        }

        // Here we are firing auth call using keys from map
        Response resp1;
        String accessToken = null;
        try {
            RequestSpecification given = given();
            if (authFormParams.get(USERNAME) != null && authFormParams.get(PASSWORD) != null) {
                given.formParam("username", authFormParams.get(USERNAME).toString()).formParam(PASSWORD, authFormParams.get(PASSWORD).toString());
            }
            if (authFormParams.get(SCOPE) != null) {
                given.formParam(SCOPE, authFormParams.get(SCOPE).toString());
            }

            if (authFormParams.get("account_id") != null) {
                given.formParam("account_id", authFormParams.get("accountId").toString());
            }

            resp1 = given.formParam(VCLIENTID, authFormParams.get(TCLIENTID).toString())
                    .formParam("client_secret", authFormParams.get("clientSecret").toString())
                    .formParam("grant_type", authFormParams.get("grantType").toString()).post(authFormParams.get(VAUTHURL).toString());
            accessToken = resp1.jsonPath().get(VACCESSTOKEN);
            logger.info("initiateAuthCallToToken JSON Response:: {}", resp1.asString());
        } catch (Exception e) {
            logger.error("initiateAuthCallToToken exception msg:: {}", e.getMessage());
        }
        return accessToken;
    }


    private Map<String, Object> createAuthFormParams(String formOrIDP, String path) {
        ArrayList<String> tmplAuthParams = new ArrayList<>();
        Map<String, Object> authFormParams = new HashMap<>();
        String authParamTemplate;
        if (formOrIDP.equalsIgnoreCase("form")) {
            authParamTemplate = getConfigPropProperty(AUTHBASETEMPLATE) + "," + getConfigPropProperty("AuthformTemplate");
        } else {
            authParamTemplate = getConfigPropProperty(AUTHBASETEMPLATE) + "," + getConfigPropProperty("AuthIdpTemplate");
        }
        String[] authParamTemplSplit = authParamTemplate.split(",");
        Collections.addAll(tmplAuthParams, authParamTemplSplit);
        String tmpString;
        for (String itm : tmplAuthParams) {
            tmpString = Utils.prepareDataString(PREPDATAPREFIX + path + "." + itm);
            authFormParams.put(itm, tmpString);
        }
        return authFormParams;
    }


    public void getCodeToken(String path) throws NoSuchAlgorithmException {

        String verifier = generateCodeVerifier();
        String challenge = generateCodeChallange(verifier);
        contextMap.put("codeVerifier", verifier);
        contextMap.put("codeChallenger", challenge);
        Map<String, Object> authFormParams;

        authFormParams = createAuthFormParams("form", path);
        Response resp1;
        try {
            RequestSpecification given = given();
            if (authFormParams.get(USERNAME) != null && authFormParams.get(PASSWORD) != null) {
                //pre-emptive will create the derived Authorization and auto-add the header
                given.auth().preemptive().basic(authFormParams.get(USERNAME).toString(), authFormParams.get(PASSWORD).toString());
            }

            resp1 = given.redirects().follow(false).header("Content-Type", "application/x-www-form-urlencoded")
//                    .header("Authorization", "Basic UHJhandhbDpUZXN0QDEyMzQ=")
                    .formParam(VCLIENTID, authFormParams.get(TCLIENTID).toString())
                    .formParam("response_type", authFormParams.get("responseType").toString())
                    .formParam("redirect_uri", authFormParams.get("redirectURI").toString())
                    .formParam("channel_id", authFormParams.get("channelId").toString())
                    .formParam("code_challenge", contextMap.get("codeChallenger"))
                    .post(authFormParams.get(VAUTHURL).toString());
            contextMap.getContext().put("AuthenticateResponse", String.valueOf(resp1.getHeaders()));
            logger.info("getCodeToken JSON Response:: {}", resp1.asString());
        } catch (Exception e) {
            logger.error("getCodeToken exception msg:: {}", e.getMessage());
        }
    }

    public void getAccessToken(String path, String code, String customerId) {

        Map<String, Object> authFormParams;

        authFormParams = createAuthFormParams("idp", path);

        Response resp1;
        try {
            RequestSpecification given = given();
            if (authFormParams.get(USERNAME) != null && authFormParams.get(PASSWORD) != null) {
                given.auth().preemptive().basic(authFormParams.get(USERNAME).toString(), authFormParams.get(PASSWORD).toString());
            }

            resp1 = given.redirects().follow(false).header("Content-Type", "application/x-www-form-urlencoded")
//                    .header("Authorization", authFormParams.get("authorization").toString())
                    .formParam(VCLIENTID, authFormParams.get(TCLIENTID).toString())
                    .formParam("code", contextMap.get(code))
                    .formParam("redirect_uri", authFormParams.get("redirectURI").toString())
                    .formParam("channel_id", authFormParams.get("channelId").toString())
                    .formParam("grant_type", authFormParams.get("grantType").toString())
                    .formParam("code_verifier", contextMap.get("codeVerifier")).
                    post(authFormParams.get(VAUTHURL).toString());
            String str = resp1.getBody().asString();
            JSONObject jsonObject = new JSONObject(str);
            if(customerId!=null) {
                String fetchCustomerId = (String) jsonObject.get(VCUSTOMERID);
                contextMap.getContext().put(customerId, fetchCustomerId);
                logger.info("get CustomerID :: {}", fetchCustomerId);
                logger.info("CustID :: {}", customerId);
            }
            String accessToken = (String) jsonObject.get(VACCESSTOKEN);
            contextMap.getContext().put(VACCESSTOKEN, accessToken);
            logger.info("getAccessToken JSON Response:: {}", resp1.asString());
        } catch (Exception e) {
            logger.error("getAccessToken exception msg:: {}", e.getMessage());
        }
    }

    public void getKeyValueFromResponse(String response, String key, String subKey) {
        String res = contextMap.get(response);
        String[] stringArray = res.split("\n");
        String splitParameter = "&";
        for (String s : stringArray) {
            if (s.contains(key)) {
                String value = findSubKey(s, subKey, splitParameter);
                contextMap.getContext().put(subKey, value);

            }
        }
    }

    public String findSubKey(String str, String subKey, String splitParameter) {
        String value = null;
        if (str.contains(subKey)) {
            String[] array = str.split(splitParameter);
            for (String s : array) {
                if (s.contains(subKey))
                    value = s.split(subKey + "=")[1];
            }
        }
        return value;
    }

    String generateCodeVerifier() {
        SecureRandom secureRandom = new SecureRandom();
        byte[] codeVerifier = new byte[32];
        secureRandom.nextBytes(codeVerifier);
        return Base64.getUrlEncoder().withoutPadding().encodeToString(codeVerifier);
    }

    String generateCodeChallange(String codeVerifier) throws NoSuchAlgorithmException {
        byte[] bytes = codeVerifier.getBytes(StandardCharsets.US_ASCII);
        MessageDigest messageDigest = MessageDigest.getInstance("SHA-256");
        messageDigest.update(bytes, 0, bytes.length);
        byte[] digest = messageDigest.digest();
        return Base64.getUrlEncoder().withoutPadding().encodeToString(digest);
    }


    private void checkTempString(String tmpString, String itm, String path) {
        if (tmpString.contains(itm) || tmpString.contains(path)) {
            logger.debug("/AuthConfig/{}.{} not setup - ignoring", path, itm);
        }
    }
}



