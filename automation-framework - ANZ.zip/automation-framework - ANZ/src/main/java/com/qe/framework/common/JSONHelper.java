package com.qe.framework.common;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.jayway.jsonpath.DocumentContext;
import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;

public class JSONHelper {
    private static final Logger logger = LoggerFactory.getLogger(JSONHelper.class);
    LinkedHashMap<String, Object> jsonKeyValue = new LinkedHashMap<>();

    private void listJson(JSONObject json) {
        listJSONObject("", json);
    }

    private void listObject(String parent, Object data) {
        if (data instanceof JSONObject) {
            listJSONObject(parent, (JSONObject) data);
        } else if (data instanceof JSONArray) {
            listJSONArray(parent, (JSONArray) data);
        } else {
            listPrimitive(parent, data);
        }
    }

    private void listJSONObject(String parent, JSONObject json) {
        Iterator<String> it = json.keys();
        while (it.hasNext()) {
            String key =it.next();
            Object child = json.get(key);
            String childKey = parent.isEmpty() ? key : parent + "." + key;
            listObject(childKey, child);
        }
    }

    private void listJSONArray(String parent, JSONArray json) {
        for (int i = 0; i < json.length(); i++) {
            Object data = json.get(i);
            listObject(parent + "[" + i + "]", data);
        }
    }

    private void listPrimitive(String parent, Object obj) {
        jsonKeyValue.put(parent, obj);
    }

    public Map<String, Object> listJsonKeyValues(String jsonSting) {
        JSONObject json = new JSONObject(jsonSting);
        listJson(json);
        return jsonKeyValue;
    }

    public String beautify(String json) throws IOException {
        ObjectMapper mapper = new ObjectMapper();
        Object obj = mapper.readValue(json, Object.class);
        return mapper.writerWithDefaultPrettyPrinter().writeValueAsString(obj);
    }

    public void savesResponseInFile(String fileName, String file) throws IOException {
        String path = Constants.RULESFILEPATH;
        File directory = new File(path);
        if (!directory.exists()) {
            directory.mkdir();
            logger.info("Directory created : {}", directory.getName());
        }
        FileWriter responseWriter = new FileWriter(path + fileName + ".json");
        try {
            responseWriter.write(file);
            logger.info("{}.json created.", fileName);
        } catch (Exception e) {
            logger.error(e.getMessage());
        } finally {
            try {
                responseWriter.flush();
                responseWriter.close();
            } catch (Exception e) {
                logger.error(e.getMessage());
            }

        }
    }

    public String updateJSONValue(String payload, String key, Object value) {
        try {
            DocumentContext jsonPayload = com.jayway.jsonpath.JsonPath.parse(payload);
            payload = jsonPayload.set(key, value).jsonString();
            logger.debug("{} updated to {}", key, value);
        } catch (Exception e) {
            logger.error("Exception Msg:: {}", e.getMessage());
        }
        return payload;
    }

    public String deleteJSONValue(String payload, String key) {
        try {
            DocumentContext jsonPayload = com.jayway.jsonpath.JsonPath.parse(payload);
            payload = jsonPayload.delete(key).jsonString();
            logger.debug("{} deleted", key);
        } catch (Exception e) {
            logger.error("Exception Msg:: {}", e.getMessage());
        }
        return payload;
    }
}
