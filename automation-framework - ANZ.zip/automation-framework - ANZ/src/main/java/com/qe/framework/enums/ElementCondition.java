package com.qe.framework.enums;

public enum ElementCondition {
    IS_VISIBLE,
    IS_CLICKABLE,
    IS_PRESENT
}
