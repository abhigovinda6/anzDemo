package com.qe.framework.enums;

public enum VerificationType {
    DATA_QUALITY,
    BLOB_DOWNLOADED,
    FILE_STRUCTURE,
    FILE_NAME_EXT,
    FILE_COUNT;
}
