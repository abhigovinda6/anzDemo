package com.qe.framework.enums;

public enum IFrame {

    NAME,
    ID,
    WEB_ELEMENT,
    INDEX;
}
