package com.qe.framework.common;

import java.util.HashMap;
import java.util.Map;

public class ObjectContextMap {
    private final Map<Object, Object> objectContext;

    public ObjectContextMap() {
        objectContext = new HashMap<>();
    }

    public Map<Object, Object> getObjectContext() {
        return objectContext;
    }

    public void put(Object key, Object value) {
        objectContext.put(key, value);
    }

    public void putAll(Map<Object, Object> anotherMap) {
        objectContext.putAll(anotherMap);
    }

    public Object get(Object key) {
        return objectContext.get(key);
    }

    public void remove(Object key) {
        objectContext.remove(key);
    }

    public boolean contains(Object key) {
        return objectContext.containsKey(key);
    }

    public void clear() {
        objectContext.clear();
    }

    public boolean isEmpty() {
        return objectContext.isEmpty();
    }
}
