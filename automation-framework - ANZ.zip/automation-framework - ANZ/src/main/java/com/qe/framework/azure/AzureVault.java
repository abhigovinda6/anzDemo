package com.qe.framework.azure;

import com.azure.core.http.rest.PagedIterable;
import com.azure.data.appconfiguration.ConfigurationClient;
import com.azure.data.appconfiguration.ConfigurationClientBuilder;
import com.azure.data.appconfiguration.models.ConfigurationSetting;
import com.azure.data.appconfiguration.models.SettingSelector;
import com.azure.identity.DefaultAzureCredential;
import com.azure.identity.DefaultAzureCredentialBuilder;
import com.azure.security.keyvault.secrets.SecretClient;
import com.azure.security.keyvault.secrets.SecretClientBuilder;
import com.azure.security.keyvault.secrets.models.KeyVaultSecret;
import com.azure.security.keyvault.secrets.models.SecretProperties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import static com.qe.framework.common.Constants.driverType;

public class AzureVault {
    private static final Logger logger = LoggerFactory.getLogger(AzureVault.class);

    private static final String APP_CONFIG_ENDPOINT = "https://psecom-qe-devv-appconfig-01.azconfig.io";

    private static String vaultUrl;

    private static ConfigurationClient configurationClient;
    private static SecretClient secretClient;

    private AzureVault() {
        throw new IllegalStateException("Utility class");
    }

    public static void vaultConnectionBuilder() {
        if (driverType.equalsIgnoreCase("remote") || driverType.equalsIgnoreCase("remloc")) {
            logger.info("Creating Vault credential object.....");
            DefaultAzureCredential credential = new DefaultAzureCredentialBuilder().build();

            configurationClient = new ConfigurationClientBuilder()
                    .credential(credential)
                    .endpoint(APP_CONFIG_ENDPOINT)
                    .buildClient();
            logger.info("Vault Client create successfully.");
        }
    }

    public static String getConfig(String key) {
        String value = "";
        try {
            value = configurationClient.getConfigurationSetting(key, null).getValue();
//        ::FUTURE::
//            configurationClient.deleteConfigurationSetting("/common/general", null);
//            configurationClient.setConfigurationSetting("/common/general", null, "NewValueToday");
            //AppConfig might return references to keyvault
            //we need to resolve them to deliver the valie
            if (value.startsWith("{\"uri")) {
                value = getSecret(value);
            }
        } catch (Exception e) {
            value = null;
        }
        return value;
    }


    public static String deleteConfig(String key) {
        try {
            configurationClient.deleteConfigurationSetting(key, null);
        } catch (Exception e) {
            key = null;
        }
        return key;
    }


    public static boolean updateConfig(String key, String keyVal) {
        try {
            configurationClient.setConfigurationSetting(key, null, keyVal);
        } catch (Exception e) {
            return false;
        }
        return true;
    }

    private static void updateVaultUrl(String value) {
        String url = value.substring(9, value.indexOf(".net/") + 5);

        if (vaultUrl == null || !vaultUrl.equals(url)) {
            vaultUrl = url;
        }
    }

    private static String getSecret(String key) {
        // The Vault url is needed to create the client
        // as it is unlikely to change and we do not want to create a new
        // client if not needed we try this approach
        updateVaultUrl(key);

        if (secretClient == null && vaultUrl != null) {
            secretClient = new SecretClientBuilder()
                    .vaultUrl(vaultUrl)
                    .credential(new DefaultAzureCredentialBuilder().build())
                    .buildClient();
        }

//        ::FUTURE::
//        SyncPoller<DeletedSecret, Void> deletedSecretPoller = secretClient.beginDeleteSecret("/common/general");
//// Deleted secret is accessible as soon as polling begins.
//        PollResponse<DeletedSecret> deletedSecretPollResponse = deletedSecretPoller.poll();
//// Deletion date only works for a SoftDelete-enabled Key Vault.
//        System.out.printf("Deletion date: %s%n", deletedSecretPollResponse.getValue().getDeletedOn());
//// Secret is being deleted on server.
//        deletedSecretPoller.waitForCompletion();
//        secretClient.setSecret(new KeyVaultSecret("/common/general", "NewValueToday"));
        assert secretClient != null;
        return secretClient.getSecret(key.substring(key.lastIndexOf("/"), key.length() - 2)).getValue();
    }

}
