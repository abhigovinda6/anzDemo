package com.qe.framework.appium.helpers.utils;

import com.perfecto.utilities.others.OtherUtilities;
import com.qe.framework.appium.helpers.AppiumDriverHelper;
import com.qe.framework.common.Constants;
import com.qe.framework.enums.GestureDirection;
import com.qe.framework.enums.SetswipeDirection;
import com.qe.framework.enums.SwipeDirection;
import io.appium.java_client.*;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.touch.WaitOptions;
import io.appium.java_client.touch.offset.PointOption;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.time.Duration;
import java.util.Set;

public class AppiumCommonMethods extends AppiumDriverHelper {
    private static final Logger logger = LoggerFactory.getLogger(AppiumCommonMethods.class);
    private static final String NOT_SUPPORTED = "' NOT supported";
    private static final String FIFTEEN_PERCENT = "15%,60%";

    private static final String TWENTY_PERCENT = "20%,40%";
    private static WebDriver remdriver;
    private static AppiumDriver<MobileElement> mobileDriver;


    public AppiumCommonMethods() {
        super();
    }

    public static void close() {
        remdriver = Constants.remdriver;
        captureScreenShot(remdriver, Constants.FAIL);
        remdriver.manage().deleteAllCookies();
        remdriver.quit();
    }

    public static void captureScreenShot(WebDriver ldriver, String status) {
        remdriver = Constants.remdriver;
        logger.debug("Status:: {}", status);
        takeScreenshot(ldriver);
    }


    public static void takeScreenshot(WebDriver webDriver) {

        try {
            remdriver = Constants.remdriver;
            File src = ((TakesScreenshot) webDriver).getScreenshotAs(OutputType.FILE);
            FileUtils.copyFile(src, new File(Constants.REPORTSCREENSHOTFOLDERPATH + System.currentTimeMillis() + ".png"));

        } catch (Exception e) {
            logger.error("takeScreenshot.Exception {}", e.getMessage());
        }
    }

    public static void swipeScreen(SwipeDirection dir) {
        remdriver = Constants.remdriver;
        logger.info("swipeScreen(): dir: '{}'", dir); // always log your actions
        mobileDriver = (AppiumDriver<MobileElement>) Constants.remdriver;
        // Animation default time:
        //  - Android: 300 ms
        //  - iOS: 200 ms
        // final value depends on your app and could be greater
        final int ANIMATION_TIME = 200; // ms

        final int PRESS_TIME = 200; // ms

        int edgeBorder = 10; // better avoid edges
        PointOption pointOptionStart;
        PointOption pointOptionEnd;

        // init screen variables
        mobileDriver.context("NATIVE_APP");
        Dimension dims = mobileDriver.manage().window().getSize();

        // init start point = center of screen
        pointOptionStart = PointOption.point(dims.width / 2, dims.height / 2);

        switch (dir) {
            case DOWN: // center of footer
                pointOptionEnd = PointOption.point(dims.width / 2, dims.height - edgeBorder);
                break;
            case UP: // center of header
                pointOptionEnd = PointOption.point(dims.width / 2, edgeBorder);
                break;
            case LEFT: // center of left side
                pointOptionEnd = PointOption.point(edgeBorder, dims.height / 2);
                break;
            case RIGHT: // center of right side
                pointOptionEnd = PointOption.point(dims.width - edgeBorder, dims.height / 2);
                break;
            default:
                throw new IllegalArgumentException("swipeScreen(): dir: '" + dir + NOT_SUPPORTED);
        }

        // execute swipe using TouchAction
        try {
            new TouchAction((PerformsTouchActions) Constants.remdriver)
                    .press(pointOptionStart)
                    // a bit more reliable when we add small wait
                    .waitAction(WaitOptions.waitOptions(Duration.ofMillis(PRESS_TIME)))
                    .moveTo(pointOptionEnd)
                    .release().perform();
        } catch (Exception e) {
            logger.error("swipeScreen(): TouchAction FAILED\n {}", e.getMessage());
            return;
        }

        // always allow swipe action to complete
        try {
            Thread.sleep(ANIMATION_TIME);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            // ignore
        }
    }


    protected static void hideKeyBoard() {
        try {
            remdriver = Constants.remdriver;
            mobileDriver = (AppiumDriver<MobileElement>) remdriver;
            mobileDriver.hideKeyboard();
        } catch (Exception e) {
            logger.error("Exception in  hideKeyboard msg:: {}", e.getMessage());
        }
    }

    public static void gestureInto(GestureDirection dir) {
        remdriver = Constants.remdriver;
        logger.info("GetsureScreen(): dir: {}", dir); // always log your actions
        mobileDriver = (AppiumDriver<MobileElement>) Constants.remdriver;

        switch (dir) {
            case IN: // Zooms into the page
                OtherUtilities.gesture((RemoteWebDriver) remdriver, TWENTY_PERCENT, FIFTEEN_PERCENT, "zoom", 3);
                break;
            case OUT: // Zooms out from the page
                OtherUtilities.gesture((RemoteWebDriver) remdriver, FIFTEEN_PERCENT, TWENTY_PERCENT, "pinch", 3);
                break;
            default:
                throw new IllegalArgumentException("GetsureScreen(): dir: '" + dir + NOT_SUPPORTED);
        }
    }

    public static void swipeMobile(SetswipeDirection dir) {
        remdriver = Constants.remdriver;
        logger.info("swipeScreen(): dir: {}", dir);
        mobileDriver = (AppiumDriver<MobileElement>) Constants.remdriver;

        switch (dir) {
            case UP: // center of footer
                OtherUtilities.swipe((RemoteWebDriver) remdriver, "40%,90%", "40%,20%", 3);
                break;
            case DOWN: // center of header
                OtherUtilities.swipe((RemoteWebDriver) remdriver, TWENTY_PERCENT, FIFTEEN_PERCENT, 3);
                break;
            case LEFT: // center of left side
                OtherUtilities.swipe((RemoteWebDriver) remdriver, "50%,10%", "50%,80%", 3);
                break;
            case RIGHT: // center of right side
                OtherUtilities.swipe((RemoteWebDriver) remdriver, "20%,20%", "80%,20%", 3);
                break;
            default:
                throw new IllegalArgumentException("swipeScreen(): dir: '" + dir + NOT_SUPPORTED);
        }
    }

    public void androidScrollToVisibleTextInListAndClick(String elementName) {
        AndroidDriver<MobileElement> ad = (AndroidDriver<MobileElement>) mobileDriver;
        MobileElement element = ad.findElementByAndroidUIAutomator("new UiScrollable(new UiSelector()"
                // +".resourceId(\"android:id/list\")).scrollIntoView("
                + ".className(\"android.widget.ListView\")).scrollIntoView(" + "new UiSelector().text(\"" + elementName
                + "\"));");
        element.click();
    }

    public MobileElement androidScrollToTextAndGetElement(String text) {
        return mobileDriver.findElement(MobileBy.AndroidUIAutomator(
                "new UiScrollable(new UiSelector()).scrollIntoView(" + "new UiSelector().text(\"" + text + "\"));"));
    }

    public boolean androidScrollToTextAndClick(String text) {
        try {
            androidScrollToTextAndGetElement(text).click();
        } catch (Exception e) {
            logger.error(e.toString());
            return false;
        }
        return true;
    }

    public void setContext(String context) throws InterruptedException {
        try {
            Thread.sleep(4000);
        } catch (InterruptedException e) {
            logger.error(e.toString());
            throw e;
        }
        Set<String> contextNames = mobileDriver.getContextHandles();
        logger.info("Context Names : {}", contextNames);
        if (context.contains("NATIVE")) {
            mobileDriver.context((String) contextNames.toArray()[0]);
        } else if (context.contains("WEBVIEW")) {
            mobileDriver.context((String) contextNames.toArray()[1]);
        }
        logger.info("Current context {}", mobileDriver.getContext());
    }

}
