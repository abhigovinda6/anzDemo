package com.qe.framework.enums;

public enum ElementStatus {
    IS_DISPLAYED,
    IS_ENABLED,
    IS_SELECTED,
    IS_DISABLED;
}
