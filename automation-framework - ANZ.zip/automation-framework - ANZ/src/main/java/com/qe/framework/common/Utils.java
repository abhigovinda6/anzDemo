package com.qe.framework.common;

import com.qe.framework.azure.AzureVault;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.commons.lang3.StringUtils;
import org.htmlcleaner.HtmlCleaner;
import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.json.JSONArray;
import org.junit.Assert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.text.SimpleDateFormat;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static com.qe.framework.common.Constants.*;
import static com.qe.framework.common.PropertiesHelper.contextMap;
import static com.qe.framework.common.PropertiesHelper.getConfigPropProperty;
import static com.qe.framework.customexception.ExceptionAndErrors.getFailedstep;
import static com.qe.framework.web.helpers.WebDriverHelper.webPropHelper;
import static org.junit.Assert.*;

// This Class can be used by BDD from Web and API
public class Utils {
    private static final Logger logger = LoggerFactory.getLogger(Utils.class);
    private static final String ALPHANUMERIC = "alphanumeric_";
    static Pattern pattern;
    static Matcher matcher;
    static SimpleDateFormat formatter;
    static Date date;

    public static void numericalComparisonByOperator(String operator, float numberLeft, float numberRight) {
        try {
            switch (operator) {
                case "greater-than":
                    assertTrue(numberLeft > numberRight);
                    break;
                case "greater-than-equal-to":
                    assertTrue(numberLeft >= numberRight);
                    break;
                case "less-than":
                    assertTrue(numberLeft < numberRight);
                    break;
                case "less-than-equal-to":
                    assertTrue(numberLeft <= numberRight);
                    break;
                case "equal-to":
                    assertEquals(numberLeft, numberRight, 0.0);
                    break;
                case "not-equal-to":
                    Assert.assertNotEquals(numberLeft, numberRight);
                    break;
                default:
                    assertEquals(numberLeft, numberRight, 0.0);
                    break;
            }
        } catch (AssertionError e) {
            logger.error(getFailedstep("Failing condition: " + numberLeft + "  " + operator + "  " + numberRight));
        }
    }

    public static void stringComparisonByOperator(String operator, String stringLeft, String stringRight) {
        switch (operator) {
            case "contains":
                assertTrue(stringLeft.contains(stringRight));
                break;
            case "case-match":
                assertEquals(stringLeft, stringRight);
                break;
            case "ignore-case":
                assertTrue(stringLeft.equalsIgnoreCase(stringRight));
                break;
            case "does-not-match":
                assertFalse(stringLeft.equalsIgnoreCase(stringRight));
                break;
            default:
                logger.error("Un-iimplemented switch-case in stringComparisonByOperator");
                fail();
        }
    }

    private static String whenReqIsYearOrDayOfWeek(String value, DateTime dateTime) {
        String result = "";
        if (value.contains("year")) {
            result = String.valueOf(Utils.getYear(dateTime));
        } else if (value.contains("dayOfWeek")) {
            int dayOfWeek = dateTime.getDayOfWeek() % 5;
            if (dayOfWeek == 0) result = Utils.dayofWeekStr(5);
            else result = Utils.dayofWeekStr(dayOfWeek);
        }
        return result;
    }

    public static String generateDateTimeZone(String value) {
        String result = "";
        DateTime dateTime = Utils.getDesiredDateTime(value);
        if (value.contains("dateTime_")) {
            result = getResultValue(dateTime, value);
        } else if (value.contains("year") || value.contains("dayOfWeek")) {
            result = whenReqIsYearOrDayOfWeek(value, dateTime);
        } else if (value.contains("date_")) {
            String[] splitFormat = value.split("_");
            if (splitFormat.length == 3 && Utils.verfiyTextUsingRegex(splitFormat[2], "[-/][dMy]")) {
                if (Utils.verfiyTextUsingRegex(splitFormat[2], "[-/][dMy]")) {
                    DateTimeFormatter reqDateFormatter = DateTimeFormatter.ofPattern(splitFormat[2]);
                    result = reqDateFormatter.format(LocalDate.of(dateTime.getYear(), dateTime.getMonthOfYear(), dateTime.getDayOfMonth()));
                }
            } else {
                result = Utils.getDateAsString(dateTime);
                if (value.contains("yyymmdd")) {
                    result = dateTime.toString().split("T")[0];
                }
            }
        } else if (value.contains("time_")) {
            result = String.valueOf(Utils.getTime(dateTime));
        }
        return result;
    }

    public static String generateRandomNumericAlphaString(String value) {
        String minInt;
        String maxInt;
        String minDecimal;
        String maxDecimal;
        String result = "";
        if (value.contains("$")) {
            value = value.replace("$", "").replace("random_", "");
            if (value.contains(".")) {
                value = value.replace("number_", "");
                if (value.contains("-")) {
                    minInt = value.split("\\.")[0].split("-")[0];
                    maxInt = value.split("\\.")[0].split("-")[1];
                    minDecimal = value.split("\\.")[1].split("-")[0];
                    maxDecimal = value.split("\\.")[1].split("-")[1];
                    result = String.valueOf(Utils.getRandomNumberinDecimal(Integer.parseInt(minInt), Integer.parseInt(maxInt), Integer.parseInt(minDecimal), Integer.parseInt(maxDecimal)));
                } else {
                    minInt = value.split("\\.")[0];
                    minDecimal = value.split("\\.")[1];
                    result = Utils.getRandomNumber(Integer.parseInt(minInt)) + "." + Utils.getRandomNumber(Integer.parseInt(minDecimal));
                }
            } else if (value.contains("email")) {
                result = "AutoGenEmail_" + Utils.getRandomAlphanumeric(20) + "@Test.com";
            } else {
                if (value.contains("-")) {
                    result = forRandStringWhenValueContainsHyphen(value);
                } else {
                    result = forRandStringWhenValueContainsElse(value);
                }
            }
        } else {
            result = value;
        }
        return result;
    }

    private static String getResultValue(DateTime dateTime, String value) {
        String result = "";
        String retMatcher = getMatcherGroup(value, "([\\dZ])");
        if (retMatcher != null) {
            int digits = Integer.parseInt(retMatcher);
            result = dateTime.toString();
            int indexOfColon = result.indexOf(".");
            int remainigData = result.substring(indexOfColon).length() - 2;
            assertTrue(remainigData >= digits);
            if (digits > 0) {
                digits = digits + 1;
            }
            result = result.substring(0, indexOfColon + digits) + "Z";
        } else {
            result = dateTime.toString();
        }
        return result;
    }

    private static String forRandStringWhenValueContainsElse(String value) {
        String result = "";
        if (value.contains("alphabet_")) {
            value = value.replace("alphabet_", "");
            result = Utils.getRandomAlphabetic(Integer.parseInt(value));
        } else if (value.contains(ALPHANUMERIC)) {
            value = value.replace(ALPHANUMERIC, "");
            result = Utils.getRandomAlphanumeric(Integer.parseInt(value));
        } else if (value.contains("number_")) {
            value = value.replace("number_", "");
            result = Utils.getRandomNumber(Integer.parseInt(value));
        }
        return result;
    }

    private static String forRandStringWhenValueContainsHyphen(String value) {
        String minInt;
        String maxInt;
        String result = "";
        if (value.contains("alphabet_")) {
            value = value.replace("alphabet_", "");
            minInt = value.split("-")[0];
            maxInt = value.split("-")[1];
            result = Utils.getRandomAlphabeticInRange(Integer.parseInt(minInt), Integer.parseInt(maxInt));
        } else if (value.contains(ALPHANUMERIC)) {
            value = value.replace(ALPHANUMERIC, "");
            minInt = value.split("-")[0];
            maxInt = value.split("-")[1];
            result = Utils.getRandomAlphanumericInRange(Integer.parseInt(minInt), Integer.parseInt(maxInt));
        } else if (value.contains("number_")) {
            value = value.replace("number_", "");
            minInt = value.split("-")[0];
            maxInt = value.split("-")[1];
            result = String.valueOf(Utils.getRandomNumberInRange(Integer.parseInt(minInt), Integer.parseInt(maxInt)));
        }
        return result;
    }

    public static String prepareDataString(String sampleData) {
        String retString = null;
        if (sampleData.equals("EMPTY")) {
            retString = "";
        } else if (sampleData.equals("SPACE")) {
            retString = " ";
        } else if (sampleData.contains("_PIPE_")) {
            retString = sampleData.replace("_PIPE_", "|");
        } else if (sampleData.equalsIgnoreCase("null")) {
            assertTrue(true);
        } else if (contextMap.contains(sampleData)) {
            retString = contextMap.get(sampleData);
        } else if (sampleData.contains("$")) {
            retString = whenSampleDataContainsDollarSymbol(sampleData);
        } else if (System.getProperty(sampleData) != null) {
            retString = System.getProperty(sampleData);
        } else if (webPropHelper.containsKeyFromConfigProp(sampleData)) {
            retString = getConfigPropProperty(sampleData);
        } else if (driverType.equalsIgnoreCase("local")) {
            retString = localDriverType(sampleData);
        } else if (driverType.equalsIgnoreCase("remote") || Utils.isDriverType("remloc")) {
            retString = remoteDriverType(sampleData);
        }
        if (retString == null && !sampleData.equalsIgnoreCase("null")) return sampleData;
        return retString;
    }

    public static String localDriverType(String sampleData) {
        String retString;
        retString = getConfigPropProperty(sampleData + "." + targetEnvName);
        if (retString != null) {
            logger.info("LOCAL DATA: Found at {}.{} as {}", sampleData, targetEnvName, retString);
        }
        return retString;
    }

    public static String remoteDriverType(String sampleData) {
        String retString = null;
        boolean flag = false;
        ArrayList<String> staticConfigList = new ArrayList<>(Arrays.asList("/WEBConfig", "/MOBILEConfig", "/APIConfig", "/Azure", "/Security", "/SQLConfig/"));
        for (String itm : staticConfigList) {
            if (sampleData.contains(itm)) {
                flag = true;
                break;
            }
        }
        if (flag && contextMap.getFromVault(sampleData) == null) {
            retString = AzureVault.getConfig(sampleData + "." + targetEnvName);
            if (retString != null) {
                logger.info("REMOTE DATA: Found at {}.{} as {}", sampleData, targetEnvName, retString);
            }
        } else {
            retString = contextMap.getFromVault(sampleData);
        }
        return retString;
    }

    private static String whenSampleDataContainsDollarSymbol(String sampleData) {
        String retString;
        retString = webPropHelper.getTestDataProperty(sampleData);
        if (retString == null) {
            if (sampleData.contains("$random_")) {
                String sample = sampleData.split("\\$")[0];
                String pattern = "$" + (sampleData.split("\\$")[1]);
                retString = sample.concat(generateRandomNumericAlphaString(pattern));

            } else if (sampleData.contains("$date") || sampleData.contains("$time")) {
                retString = generateDateTimeZone(sampleData);
            }
        }
        return retString;
    }

    public static float calculateValue(float value1, String operator, float value2) {
        float result;
        operator = operator.toLowerCase();
        switch (operator) {
            case "add":
                result = value1 + value2;
                break;
            case "subtract":
                result = value1 - value2;
                break;
            case "divide":
                result = value1 / value2;
                break;
            case "multiply":
                result = value1 * value2;
                break;
            default:
                result = 0;
                logger.info("The following operator is invalid: {}", operator);
                break;
        }
        return result;
    }

    //    examples like 02 hr 20 min
    public static String hourToMinute(String hour) {
        if (hour.isEmpty()) return "0";
        int hr = 0;
        int min = 0;
        if (hour.contains("hr")) {
            hr = Integer.parseInt(StringUtils.substringBefore(hour, " hr"));
            min = Integer.parseInt(StringUtils.substringBefore(StringUtils.substringAfter(hour, "hr "), " min"));
        } else min = Integer.parseInt(StringUtils.substringBefore(hour, " min"));
        return String.valueOf(hr * 60 + min);
    }

    public static String cleanHTMLtags(String actualText) {
        String result = new HtmlCleaner().clean(actualText).getText().toString();
        result = result.replace("\n", " ");
        result = result.replace("&nbsp;", " ");
        return result;
    }

    public static String getRandomAlphabetic(int randomStrLength) {
        logger.debug("");
        return RandomStringUtils.randomAlphabetic(randomStrLength);
    }

    public static String getRandomAlphanumeric(int randomStrLength) {
        return RandomStringUtils.randomAlphanumeric(randomStrLength);
    }

    public static String getRandomAlphabeticInRange(int min, int max) {
        int randomStrLength = getRandomNumberInRange(min, max);
        return RandomStringUtils.randomAlphabetic(randomStrLength);
    }

    public static String getRandomAlphanumericInRange(int min, int max) {
        int randomStrLength = getRandomNumberInRange(min, max);
        return RandomStringUtils.randomAlphanumeric(randomStrLength);
    }

    public static String getRandomNumber(int randomIntLength) {
        return RandomStringUtils.randomNumeric(randomIntLength);
    }

    public static int getRandomNumberInRange(int min, int max) {
        return new Random().nextInt(max - min + 1) + min;
    }

    public static double getRandomNumberinDecimal(int min, int max) {
        return (min + Math.random() * (max - min));
    }

    public static double getRandomNumberinDecimal(int minInt, int maxInt, int minDeci, int maxDeci) {
        int resultInt = getRandomNumberInRange(minInt, maxInt);
        int resultDecimal = getRandomNumberInRange(minDeci, maxDeci);
        int lengthDecimal = String.valueOf(resultDecimal).length();
        return resultInt + resultDecimal / Math.pow(10, lengthDecimal);
    }

    public static double getRandomNumber(int intLength, int decimalLength) {
        int resultInt = Integer.parseInt(getRandomNumber(intLength));
        int resultDecimal = Integer.parseInt(getRandomNumber(decimalLength));
        int lengthDecimal = String.valueOf(resultDecimal).length();
        return resultInt + resultDecimal / Math.pow(10, lengthDecimal);
    }

    public static String toCamelCase(final String init) {
        if (init == null) return null;

        final StringBuilder ret = new StringBuilder(init.length());

        for (final String word : init.split(" ")) {
            if (!word.isEmpty() && ret.length() != 0) {
                ret.append(Character.toUpperCase(word.charAt(0)));
                ret.append(word.substring(1).toLowerCase());
            }
            if (ret.length() == 0) ret.append(word);
        }

        return ret.toString();
    }

    public static String getTextUsingRegex(String originalText, String regxPattern, int textPosition) {
        String getCurrentMethodName;
        getCurrentMethodName = Thread.currentThread().getStackTrace()[1].getMethodName();
        String findValue = null;
        int num = 1;
        try {

            pattern = Pattern.compile(regxPattern);
            matcher = pattern.matcher(originalText);
            while (matcher.find()) {
                if (num > textPosition) {
                    break;

                }
                findValue = matcher.group();
                num++;

            }
        } catch (Exception e) {
            logger.error(getFailedstep("FAILED-" + "<->" + getCurrentMethodName + "<->" + originalText + "<->" + e));
        }
        return findValue;

    }

    public static String getUniqueValue() {
        String getCurrentMethodName;
        getCurrentMethodName = Thread.currentThread().getStackTrace()[1].getMethodName();
        String uniqueValue = null;
        try {
            formatter = new SimpleDateFormat("ddMMyyHHmm");
            date = new Date();
            uniqueValue = formatter.format(date);
        } catch (Exception e) {
            logger.error(getFailedstep("FAILED-" + "<->" + getCurrentMethodName + "<->" + "<->" + e));
        }
        return uniqueValue;

    }

    public static boolean verfiyTextUsingRegex(String textValue, String regxPattern) {
        Pattern pattern = Pattern.compile(regxPattern);
        Matcher matcher = pattern.matcher(textValue);
        return matcher.find();
    }

    //Regex related
    public static boolean validateURLRegex(String url) {
        String regex = "^(?:http(s)?:\\/\\/)?[\\w.-]+(?:\\.[\\w\\.-]+)+[\\w\\-\\._~:/?#\\[\\]@!\\$&'\\(\\)\\*\\+,;=.]+$";
        return Pattern.matches(regex, url);
    }

    public static String findValueRegex(String text, String valueToBeMatched) {
        return findValueRegexAtIndex(text, valueToBeMatched, 1);
    }

    public static String getMatcherGroup(String text, String regexPattern) {
        Pattern pattern = Pattern.compile(regexPattern);
        Matcher matcher = pattern.matcher(text);
        String result = null;
        if (matcher.find()) {
            result = matcher.group(1);
        }
        return result;
    }

    public static String findValueRegexAtIndex(String text, String valueToBeMatched, int sequence) {
        Pattern pattern = Pattern.compile("\\b\\w*" + valueToBeMatched + "\\w*\\b");
        Matcher matcher = pattern.matcher(text);
        String result = "";
        int count = 1;
        while (matcher.find() && count <= sequence) {
            result = matcher.group();
            count++;
        }
        if (count <= sequence)
            logger.info("The provided text does have {} occuernces. So returning the value at place: {}", sequence, count);
        return result;
    }

    public static String findValuewithPatternAtIndex(String text, String pattrn, int sequence) {
        Pattern pattern = Pattern.compile(pattrn);
        Matcher matcher = pattern.matcher(text);
        String result = "";
        int count = 1;
        while (matcher.find() && count <= sequence) {
            result = matcher.group();
            count++;
        }
        if (count <= sequence)
            logger.info("The provided text does have {} occuernces. So returning the value at place: {}", sequence, count);
        return result;
    }

    public static String findValueWithPattern(String text, String regex) {
        return findValuewithPatternAtIndex(text, regex, 1);
    }

    public static int valueOccurence(String text, String regex) {
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(text);
        int count = 0;
        while (matcher.find()) {
            count++;
        }
        return count;
    }

    public static void saveValueRegex(String text, String valueToBeMatched, String saveAs) {
        String result = findValueRegex(text, valueToBeMatched);
        if (saveAs.isEmpty()) contextMap.getContext().put(valueToBeMatched, result);
        else contextMap.getContext().put(saveAs, result);
    }

    public static void saveAllRegexValue(String text, String valueToBeMatched, String saveAs) {
        Pattern pattern = Pattern.compile("\\b\\w*" + valueToBeMatched + "\\w*\\b");
        Matcher matcher = pattern.matcher(text);
        int count = 1;
        if (saveAs.isEmpty()) {
            while (matcher.find()) {
                contextMap.getContext().put(valueToBeMatched + count, matcher.group());
                count++;
            }
        } else {
            while (matcher.find()) {
                contextMap.getContext().put(saveAs + count, matcher.group());
                count++;
            }
        }
    }

    public static void storeValuesWithMatchedPattern(String text, String regex, String saveAs) {
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(text);
        int count = 1;
        if (saveAs.isEmpty()) {
            while (matcher.find()) {
                contextMap.getContext().put(regex + count, matcher.group());
                count++;
            }
        } else {
            while (matcher.find()) {
                contextMap.getContext().put(saveAs + count, matcher.group());
                count++;
            }
        }
    }

    //Date and Time
    public static DateTime getDateTime() {
        return new DateTime();
    }

    public static Date getDate(DateTime dateTime) {
        if (dateTime == null) return new DateTime().toDate();
        return dateTime.toDate();
    }

    public static Date getCurrentdate() {
        return getDate(null);
    }

    public static String getTime(DateTime dateTime) {
        if (dateTime == null) return new DateTime().toLocalTime().toString();
        return dateTime.toLocalTime().toString().substring(0, 8);
    }

    public static String getTime() {
        return getTime(null);
    }

    public static String getDateTimeAsString() {
        return new DateTime().toString();
    }

    public static String getDateAsString(DateTime dateTime) {
        return dateTime.toDate().toString();
    }

    public static DateTime getDateTimeAsObject(String date) {
        return DateTime.parse(date);
    }

    public static String getCurrentdateAsString() {
        return new DateTime().toDate().toString();
    }

    public static String getTimeAsString(DateTime dateTime) {
        return getTime(dateTime);
    }

    public static String getTimeAsString() {
        return getTime();
    }

    public static DateTime convertTimeZoneToUTC(DateTime dateTime) {
        return dateTime.toDateTime(DateTimeZone.UTC);
    }

    public static DateTime convertTimeZone(DateTime dateTime, String timezone) {
        return dateTime.toDateTime(DateTimeZone.forID(timezone));
    }

    public static int getdayOfMonth(DateTime dateTime) {
        return dateTime.getDayOfMonth();
    }

    public static int getMonth(DateTime dateTime) {
        return dateTime.getMonthOfYear();
    }

    public static int getYear(DateTime dateTime) {
        return dateTime.getYear();
    }

    public static DateTimeZone getTimezone(DateTime dateTime) {
        return dateTime.getZone();
    }

    public static String getTimezoneAsString(DateTime dateTime) {
        return dateTime.getZone().toString();
    }

    public static int getHour(DateTime dateTime) {
        return dateTime.getHourOfDay();
    }

    public static int getMinute(DateTime dateTime) {
        return dateTime.getMinuteOfHour();
    }

    public static DateTime getDesiredDateTime(String property) {
        DateTime dateTime = new DateTime();
        if (property.contains("current")) dateTime = Utils.getDateTime();
        else {
            int value = Integer.parseInt(Utils.findValueWithPattern(property, "[+-]\\d*"));
            if (Utils.verfiyTextUsingRegex(property, "[+-]\\d*ms")) dateTime = dateTime.plusMillis(value);
            else if (Utils.verfiyTextUsingRegex(property, "[+-]\\d*mi")) dateTime = dateTime.plusMinutes(value);
            else if (Utils.verfiyTextUsingRegex(property, "[+-]\\d*mo")) dateTime = dateTime.plusMonths(value);
            else if (Utils.verfiyTextUsingRegex(property, "[+-]\\d*hr")) dateTime = dateTime.plusHours(value);
            else if (Utils.verfiyTextUsingRegex(property, "[+-]\\d*sc")) dateTime = dateTime.plusSeconds(value);
            else if (Utils.verfiyTextUsingRegex(property, "[+-]\\d*wk")) dateTime = dateTime.plusWeeks(value);
            else if (Utils.verfiyTextUsingRegex(property, "[+-]\\d*dt")) dateTime = dateTime.plusDays(value);
            else if (Utils.verfiyTextUsingRegex(property, "[+-]\\d*yr")) dateTime = dateTime.plusYears(value);
        }
        if (Utils.verfiyTextUsingRegex(property, "_[A-Z]{3}"))
            dateTime = Utils.convertTimeZone(dateTime, property.substring(property.length() - 3));
        return dateTime;
    }

    public static String dayofWeekStr(int day) {
        return DayOfWeek.of(day).toString();
    }

    public static List<String> jsonarraytostringlist(JSONArray jsonArr) {
        List<String> sampleList = new ArrayList<>();
        for (int i = 0; i < jsonArr.length(); i++) {
            sampleList.add(jsonArr.getString(i));
        }
        return sampleList;
    }

    public static String cleanupCommaSeparatedString(String sampleString) {
        sampleString = sampleString.replaceAll("[\\s]+", "");
        return sampleString.trim();
    }

    public static List<String> convertCommaSeparatedStringToList(String sampleString) {
        sampleString = cleanupCommaSeparatedString(sampleString);
        List<String> retString = new ArrayList<>();

        String[] tmpList = sampleString.split(",");
        for (String tmpStr : tmpList) {
            retString.add(tmpStr.trim());
        }
        return retString;
    }

    public static int countIfAnyItemsMatchInTwoLists(List<String> sourceList, List<String> targetList) {
        int localFoundTags = 0;
        for (String s : sourceList) {
            for (String value : targetList) {
                if (s.equalsIgnoreCase(value)) {
                    localFoundTags++;
                }
            }
        }
        return localFoundTags;
    }

    public static String getAllItemsMatchingInTwoLists(List<String> sourceList, List<String> targetList) {
        StringBuilder localFoundTags = new StringBuilder();
        for (String s : sourceList) {
            for (String value : targetList) {
                if (s.equalsIgnoreCase(value)) {
                    localFoundTags.append(value);
                }
            }
        }
        return localFoundTags.toString();
    }

    public static int ifAnyItemsMatchInTargetList(String item, List<String> targetList) {
        int localFoundTags = 0;
        for (String s : targetList) {
            if (s.equalsIgnoreCase(item)) {
                localFoundTags++;
            }
        }
        return localFoundTags;
    }

    public static String wrapEachValueWithDelimeter(List<String> sourceList, String wrapChar, String delimiter) {
        String resultString = "";
        StringBuilder bldString = new StringBuilder();
        for (String s : sourceList) {
            bldString.append(wrapChar).append(s).append(wrapChar).append(delimiter);
        }
        resultString = bldString.toString();

        int nVar = delimiter.length();
        resultString = resultString.substring(0, resultString.length() - nVar);

        return resultString;
    }

    public static String compressString(String inputString) {
        Base64.Encoder encoder = Base64.getEncoder();
        return encoder.encodeToString(inputString.getBytes());
    }

    public static String decompressString(String inputString) {
        Base64.Decoder decoder = Base64.getDecoder();
        return new String(decoder.decode(inputString));
    }

    public static boolean verifyIntegerDataType(String input) {
        try {
            logger.info("verifying integer datatype....");
            Integer.parseInt(input);
            logger.info("successfully verified that text: {} is integer", input);
            return true;
        } catch (Exception e) {
            logger.info("Failed to verify that text: {} is integer", input);
            return false;
        }
    }

    public static boolean verifyFloatDataType(String input) {
        try {
            logger.info("verifying float datatype....");
            Float.parseFloat(input);
            logger.info("successfully verified that text: {} is float", input);
            return true;
        } catch (Exception e) {
            logger.info("Failed to verify that text: {} is float", input);
            return false;
        }
    }

    public static boolean verifyDateDataType(String format, String input) {
        try {
            logger.info("Verifying the date datatype....");
            SimpleDateFormat formatter = new SimpleDateFormat(format);
            Date date = formatter.parse(input);
            logger.info("successfully verified the date datatype....{}", date);
            return true;
        } catch (Exception e) {
            logger.info("Failed to verified the date datatype....");
            return false;
        }
    }

    public static boolean verifyBooleanDataType(String input) {
        try {
            logger.info("verifying boolean datatype....");
            Boolean.parseBoolean(input);
            logger.info("successfully verified that text: {} is boolean", input);
            return true;
        } catch (Exception e) {
            logger.info("Failed to verify that text: {} is boolean", input);
            return false;
        }
    }

    public static int getLenqthOfText(String text) {
        return text.length();
    }

    public static void verifyLenqthOfText(String text, int expectedLength) {
        Utils.numericalComparisonByOperator("equal-to", getLenqthOfText(text), expectedLength);
    }

    public static void verifyLengthOfTextinRange(String text, int min, int max) {
        Assert.assertTrue(min <= getLenqthOfText(text) || getLenqthOfText(text) <= max);
    }

    public static Map<String, String> compareMap(Map<String, String> first, Map<String, String> second) {
        HashMap<String, String> result = new HashMap<>();
        String key;
        String value;
        boolean flag = first.size() == second.size();
        for (Map.Entry<String, String> node : first.entrySet()) {
            key = node.getKey();
            if (!flag) {
                result.put(key, "Size is not Equal");
                continue;
            }
            if (node.getValue().equals(second.get(node.getKey()))) {
                value = node.getValue();
            } else {
                value = node.getValue() + " != " + second.get(node.getKey());
            }
            result.put(key, value);
        }
        logger.info("Successfully compared Maps");
        return result;
    }

    public static boolean isDriverType(String whichDriverType) {
        return driverType.equalsIgnoreCase(whichDriverType);
    }

    public static boolean isWebTest(String whichAppType) {
        if (whichAppType == null) {
            return appType.equalsIgnoreCase("web") || (appType.equalsIgnoreCase("responsive"));
        } else return appType.equalsIgnoreCase(whichAppType);
    }

    public static boolean isMobileTest(String whichAppType) {
        if (whichAppType == null) {
            return appType.equalsIgnoreCase("mobile");
        } else return appType.equalsIgnoreCase(whichAppType);
    }

    public static boolean isOtherValidTests(String whichAppType) {
        if (whichAppType == null) {
            return appType.equalsIgnoreCase("api") || (appType.equalsIgnoreCase("feedfile")) || (appType.equalsIgnoreCase("security"));
        } else return appType.equalsIgnoreCase(whichAppType);
    }

    public static void createFolder(String path) {
        File directory = new File(path);
        if (!directory.exists()) {
            directory.mkdirs();
            logger.info("Directory created : {}", directory.getName());
        }
    }

    public static List<Double> convertListToDouble(List<String> actualList) {
        List<Double> listOfVals = new ArrayList<>();
        for (String s : actualList) {
            listOfVals.add(Double.parseDouble(s));
        }
        return listOfVals;
    }

    public static boolean validateFileDownload(String downFileName) {
        File folder = new File(System.getProperty("user.dir"));

        File[] listOfFiles = folder.listFiles();
        boolean found = false;
        File f = null;
        assert listOfFiles != null;
        for (File listOfFile : listOfFiles) {
            if (listOfFile.isFile()) {
                String fileName = listOfFile.getName();
                if (fileName.matches(downFileName)) {
                    f = new File(fileName);
                    logger.info("File found {}", fileName);
                    found = true;
                    break;
                }
            }
        }
        if (f != null) {
            f.deleteOnExit();
        }
        return found;
    }

    public static String concatString(String firstString, String secondString) {
        return firstString.concat(secondString);
    }

    public static String leftOf(String mainString, String searchString, int fetch) {
        String result = "";
        int index = mainString.indexOf(searchString);
        if (index >= 0) {
            String finalString = mainString.substring(0, index);
            if (finalString.length() > 0 && fetch < finalString.length()) {
                if (fetch > 0) {
                    result = finalString.substring(0, fetch);
                } else {
                    result = finalString;
                }
            } else
                result = mainString;
        }
        return result;
    }

    public static String rightOf(String mainString, String searchString, int fetch) {
        String result = "";

        int searchStringLen = searchString.length();
        int index = mainString.indexOf(searchString);
        if (index >= 0) {
            int from = index + searchStringLen;
            String finalString = mainString.substring(from, mainString.length());
            if (finalString.length() > 0 && fetch < finalString.length()) {
                if (fetch > 0) {
                    result = finalString.substring(0, fetch);
                } else {
                    result = finalString;
                }
            } else
                result = mainString;
        }
        return result;
    }

    public static String subStringMethod(String mainString, int startIndex, int endIndex) {
        String result = "";
        if (Objects.nonNull(mainString)) {
            int length = mainString.length();
            if (endIndex > 0) {
                result = mainString.substring(startIndex, endIndex);
            } else
                result = mainString.substring(startIndex, length);
        }
        return result;
    }

    public static String replaceString(String mainString, String toReplace, String withReplace) {
        String result = "";
        if (Objects.nonNull(mainString) && Objects.nonNull(toReplace) && Objects.nonNull(withReplace)) {
            result = mainString.replace(toReplace, withReplace);
        }
        return result;
    }

    public static String removeNewLine(String payload){
        String str="";
        str=payload.replace("\n","").replace("\r","");
        return str;
    }
}