package com.qe.framework.common;

import com.perfecto.reportium.client.ReportiumClient;
import org.openqa.selenium.WebDriver;

import java.io.File;

public class Constants {

    public static final String PASS = "PASS";
    public static final String FAIL = "FAIL";
    public static final String PARTIALLYPASS = "Partially PASS";
    public static final String ERRFORKGRTDEVICES = "Requested ForkCount is higher than the Total Devices available";
    public static final String USER_DIR = "user.dir";
    public static final String USERDIR = System.getProperty(USER_DIR) + File.separator;
    public static final String DEVICESLOCAL = USERDIR + "src/test/resources/config/Devices_Local.json";
    public static final String DEVICESREMOTE = USERDIR + "src/test/resources/config/Devices_Remote.json";
    public static final String DRIVERSROOTFOLDERPATH = USERDIR + "src/test/resources/drivers/";
    public static final String JSONCONFIGFOLDERPATH = USERDIR + "src/test/resources/apiJsonConfig/";
    public static final String JSONSCHEMAFOLDERPATH = USERDIR + "src/test/resources/apiJsonSchema/";
    public static final String JSONREQUESTFOLDERPATH = USERDIR + "src/test/resources/apiJsonRequest/";
    public static final String JSONRESPONSEFOLDERPATH = USERDIR + "src/test/resources/apiJsonResponse/";
    public static final String JSONEXTERNALFOLDERPATH = USERDIR + "src/test/resources/TestData/External/";
    public static final String SQLQUERYFOLDERPATH = USERDIR + "src/test/resources/SQLQueries/";
    public static final String AXERESOURCEPATH = USERDIR + "src/main/resources/axemain/axe.min.js";
    public static final String AXEFOLDERPATH = USERDIR + "target/Report/AXEViolations/";
    public static final String AXETEMPLATEPATH = USERDIR + "src/main/resources/axemain/";
    public static final String MOBILEAPPSFOLDER = USERDIR + "src/test/resources/mobileapps/";
    public static final String TESTDATAFOLDERPATH = USERDIR + "src/test/resources/TestData/";
    public static final String FEEDFILEREPORTS = USERDIR + "target/FeedFileReports/";
    public static final String FEEDFILEREPORTS_DATAQUALITY = FEEDFILEREPORTS + "Data Quality/";
    public static final String FEEDFILEREPORTS_FILESTRUCTURE = FEEDFILEREPORTS + "File Structure/";
    public static final String TEMPUNDERFOLDERPATH = "Temp/";
    public static final String RULESFILEPATH = USERDIR + "src/test/resources/TestData/FeedFiles/Policies/";
    public static final String FEEDFILEINPUTFOLDERPATH = USERDIR + "src/test/resources/TestData/FeedFiles/inputs/";
    public static final String DOWNLOADFEEDSFOLDERPATH = FEEDFILEINPUTFOLDERPATH + "Downloads/";
    public static final String FEEDFILESFOLDERPATH = USERDIR + "src/test/resources/TestData/FeedFiles/";
    public static final String FEEDFILEEXECUTIONFAILUREFOLDERPATH = USERDIR + "target/FeedFileReports/FeedFileIngestionResult/Stats/Failed/";
    public static final String FEEDFILEEXECUTIONSUCCESSFOLDERPATH = USERDIR + "target/FeedFileReports/FeedFileIngestionResult/Stats/Success/";
    public static final String FEEDFILEEXECUTIONNEUTRALFOLDERPATH = USERDIR + "target/FeedFileReports/FeedFileIngestionResult/Stats/Neutral/";
    public static final String REPORTSCREENSHOTFOLDERPATH = "target/Report/Screenshots/";
    public static final String FALSE = "cellFalse";
    // common to all types of test - web / mobile/ android/iOS
    public static String reservedDevices;
    public static String baseDeviceMatrix;
    public static String userDeviceMatrix;
    public static String appType;
    public static String driverType;
    public static String targetEnvName;
    public static boolean modeOfExecParallel;
    public static int forkCount = 1;
    public static String targetedResponsiveDeviceName;
    public static String targetedWebBrowserType;
    public static String targetedMobileDeviceName;
    public static String scenarioCloudDevice;
    public static String encodedScenarioName;
    public static String encodedFeatureName;
    public static String cloudLabName;
    public static String cloudSecurityToken;
    public static String gitHubPAT;
    public static int explicitWaitTime;
    public static int implicitWaitTime;
    public static int pageLoadWaitTime;
    public static int fluentWaitTime;
    public static int fluentPollingWaitTime;
    public static String screenShortTagNames;
    public static boolean isBrowserProxyEnabled = false;
    public static String enableBrowserProxy;
    public static int threadHighest;
    public static int threadHigh;
    public static int threadMedium;
    public static int threadLow;
    public static WebDriver remdriver;
    public static ReportiumClient reportiumClient;

}
