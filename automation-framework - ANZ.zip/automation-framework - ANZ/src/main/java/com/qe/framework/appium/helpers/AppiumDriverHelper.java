package com.qe.framework.appium.helpers;

import com.perfecto.reportium.client.ReportiumClientFactory;
import com.perfecto.reportium.exception.ReportiumException;
import com.perfecto.reportium.model.PerfectoExecutionContext;
import com.perfecto.reportium.model.Project;
import com.qe.framework.common.*;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.ios.IOSElement;
import io.appium.java_client.remote.MobileCapabilityType;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.safari.SafariOptions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.net.URL;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.Map;
import java.util.regex.Pattern;

import static com.qe.framework.common.Constants.*;
import static com.qe.framework.customexception.ExceptionAndErrors.getFailedstep;


public class AppiumDriverHelper {
    public static final PropertiesHelper propertiesHelperInstance = PropertiesHelper.getInstance();
    private static final Logger logger = LoggerFactory.getLogger(AppiumDriverHelper.class);
    private static final String LOCAL = "local";
    private static final String PLATFORM_NAME = "platformName";
    private static final String ANDROID = "android";
    private static WebDriver remdriver;

    private static void androidSession(Map<String, String> deviceSpecs, String browserOrApp, String appConfigKey) throws Exception {
        DesiredCapabilities capabilities = getCapabilities(deviceSpecs, browserOrApp);
        if (Utils.isDriverType(LOCAL)) {
            Constants.remdriver = new AndroidDriver<>(new URL("http://127.0.0.1:4723/wd/hub"), capabilities);
        } else {

            Constants.remdriver = new AndroidDriver<AndroidElement>(new URL("https://" + cloudLabName + ".perfectomobile.com/nexperience/perfectomobile/wd/hub"), capabilities);
        }
        remdriver = Constants.remdriver;
        if (!browserOrApp.equalsIgnoreCase("app")) {
            launchMobileBrowserURL(appConfigKey);
        }
    }

    private static void iOSSession(Map<String, String> deviceSpecs, String browserOrApp, String appConfigKey) throws Exception {
        DesiredCapabilities capabilities = getCapabilities(deviceSpecs, browserOrApp);
        if (Utils.isDriverType(LOCAL)) {
            Constants.remdriver = new IOSDriver<>(new URL("http://127.0.0.1:4723/wd/hub"), capabilities);
        } else {
            Constants.remdriver = new IOSDriver<IOSElement>(new URL("https://" + cloudLabName + ".perfectomobile.com/nexperience/perfectomobile/wd/hub"), capabilities);
        }
        remdriver = Constants.remdriver;
        if (!browserOrApp.equalsIgnoreCase("app")) {
            launchMobileBrowserURL(appConfigKey);
        }
    }

    //opening mobile browser
    public static void launchMobileBrowserURL(String appKeyName) throws Exception {
        remdriver = Constants.remdriver;
        String weburl = Utils.prepareDataString(appKeyName + "." + targetEnvName);
        String regex = "^(?:http(s)?:\\/\\/)?\\{username}:\\{password}@[\\w.-]+(?:\\.[\\w\\.-]+)+[\\w\\-\\._~:\\/?#\\[\\]@!\\$&'\\(\\)\\*\\+,;=.]+$";
        if (Pattern.matches(regex, weburl)) {
            String username = null;
            String password = null;
            username = Utils.prepareDataString("/MOBILEConfig/BasicAuth." + appKeyName + ".userName");
            password = Utils.prepareDataString("/MOBILEConfig/BasicAuth." + appKeyName + ".password");
            weburl = weburl.replace("{username}", username).replace("{password}", password);
        }
        if (weburl.contains("\"")) {
            weburl = weburl.replaceFirst("\"", "");
        }

        long starTtime = System.currentTimeMillis();

        remdriver.get(weburl);
        logger.info("open the URL: {}", weburl);
        CommonActionHelper.waitForPageLoad(remdriver);

        long endTime = System.currentTimeMillis();
        NumberFormat formatter = new DecimalFormat("#0.00000");
        logger.debug("URL page load time is: {} seconds", formatter.format((endTime - starTtime) / 1000d));
    }

    public static DesiredCapabilities getCapabilities(Map<String, String> deviceSpecs, String browserOrApp) {
        logger.debug("Preparing {} DesiredCapabilities.......", appType);
        String deviceName;
        String platformName;
        String browserType;
        String browserVersion;
//        Reading all the config details from JSON file
        deviceName = deviceSpecs.get("deviceName");
        platformName = deviceSpecs.get(PLATFORM_NAME);
        browserType = deviceSpecs.get("browserType");
        browserVersion = deviceSpecs.get("browserVersion");
//        Setting up the Desired Capabilities
        DesiredCapabilities capabilities = new DesiredCapabilities(browserType, "", Platform.ANY);
        DesiredCapabilities capabilitiesUpdated = new DesiredCapabilities(browserType, "", Platform.ANY);
        capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, deviceName);
        if (Utils.isDriverType("remote") || Utils.isDriverType("remloc")) {
            capabilities.setCapability("securityToken", cloudSecurityToken);
            capabilities.setCapability("useVirtualDevice", false);
        } else {
            capabilities.setCapability(CapabilityType.PLATFORM_NAME, platformName);
            capabilities.setCapability(MobileCapabilityType.PLATFORM_VERSION, deviceSpecs.get("platformVersion"));

            if (platformName.equalsIgnoreCase(ANDROID)) {
                capabilities.setCapability(MobileCapabilityType.AUTOMATION_NAME, "UiAutomator2");
            } else {
                capabilities.setCapability(MobileCapabilityType.AUTOMATION_NAME, "XCUITest");
            }
        }
        if (browserOrApp.equalsIgnoreCase("app")) {
            capabilities.setCapability(MobileCapabilityType.NO_RESET, "true");
            capabilities.setCapability(MobileCapabilityType.APP, MOBILEAPPSFOLDER + deviceSpecs.get("mobileAppFileName"));
        } else {
            capabilitiesUpdated = setAndroidiOSBrowserCaps(capabilities, platformName, browserVersion);
            capabilitiesUpdated.setCapability("useAppiumForWeb", true);
        }
        return capabilitiesUpdated;
    }

    private static DesiredCapabilities setAndroidiOSBrowserCaps(DesiredCapabilities capabilities, String platformName, String browserVersion) {
        if (platformName.equalsIgnoreCase(ANDROID)) {
            if (Utils.isDriverType(LOCAL)) {
                if (OSInfo.OS.WINDOWS.equals(OSInfo.getOs())) {
                    String driverPath = Constants.DRIVERSROOTFOLDERPATH + "appium/";
                    Utils.createFolder(driverPath);
                    WebDriverManager.chromedriver().cachePath(driverPath).driverVersion(browserVersion).setup();
                } else {    // for MAC
                    capabilities.setCapability("chromedriverExecutable", Constants.DRIVERSROOTFOLDERPATH + "appium/chromedriver");
                }
            }
            ChromeOptions chromeOptions = new ChromeOptions();
            chromeOptions.setExperimentalOption("w3c", false);
            capabilities.merge(chromeOptions);
        } else if (platformName.equalsIgnoreCase("ios")) {
            SafariOptions safariOptions = new SafariOptions();
            safariOptions.setCapability("browserConnectionEnabled", true);
            safariOptions.setCapability("locationContextEnabled", true);
            safariOptions.setCapability("javascriptEnabled", true);
            capabilities.merge(safariOptions);
        }
        return capabilities;
    }

    public static void createAndroidiOSSession(String browserOrApp, String appConfigKey) throws Exception {
        if (!Utils.isMobileTest(null)) {
            logger.error(getFailedstep("Config Error - Attempting to execute Mobile Tests with " + appType));
        }
        logger.info("Execution mode: {} and platformType:: {}", driverType, appType);
        if (Utils.isMobileTest(null)) {
            boolean successFlag = false;
            for (int indx = 0; indx < 5; indx++) {
                try {
                    Map<String, String> deviceSpecs = CloudConfig.getWebDeviceSpecs(scenarioCloudDevice);
                    if (deviceSpecs.get(PLATFORM_NAME).equalsIgnoreCase(ANDROID)) {
                        androidSession(deviceSpecs, browserOrApp, appConfigKey);
                    } else if (deviceSpecs.get(PLATFORM_NAME).equalsIgnoreCase("ios")) {
                        iOSSession(deviceSpecs, browserOrApp, appConfigKey);
                    }
                    setupReportiumClient();
                    successFlag = true;
                } catch (Exception e) {
                    scenarioCloudDevice = CloudConfig.getRemoteReleasedMobile();
                }
                if (successFlag) break;
            }
        } else {
            logger.warn(getFailedstep("You are trying to execute Mobile tests with " + appType + " mode. Update the configuration"));
        }
    }

    private static void setupReportiumClient() {
        PerfectoExecutionContext perfectoExecutionContext = new PerfectoExecutionContext.PerfectoExecutionContextBuilder()
                .withProject(new Project("AutomationFramework", "1.0"))
                .withContextTags("ps-auto-test")
                .withWebDriver(remdriver)
                .build();

        reportiumClient = new ReportiumClientFactory().createPerfectoReportiumClient(perfectoExecutionContext);
        if (reportiumClient == null) {
            throw new ReportiumException("Reportium client not created!");
        }
    }

}