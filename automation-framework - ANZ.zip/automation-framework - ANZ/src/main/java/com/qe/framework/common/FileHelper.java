package com.qe.framework.common;

import org.apache.commons.io.FilenameUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static com.qe.framework.common.Constants.RULESFILEPATH;
import static com.qe.framework.common.PropertiesHelper.contextMap;
import static com.qe.framework.customexception.ExceptionAndErrors.getFailedstep;
import static com.qe.framework.enums.VerificationType.*;

public class FileHelper extends CommonActionHelper {
    private static final Logger logger = LoggerFactory.getLogger(FileHelper.class);
    private static final String FILENAME_REGEX_PATTERN = ".filename_regex_pattern";
    public static ObjectContextMap fileMap = new ObjectContextMap();

    public List<File> readFiles(String directory) {
        List<File> files;
        try {
            File dir = new File(directory);
            if (dir.exists() && dir.isDirectory()) {
                files = Arrays.asList(Objects.requireNonNull(dir.listFiles()));
                logger.debug("Reading all files from : {}", directory);
                return files;
            }
            logger.debug("No files found in : {}", directory);
        } catch (Exception e) {
            logger.error(e.getMessage());
        }
        return Collections.emptyList();
    }

    public Map<String, Integer> filesCount(List<File> files) {
        Map<String, Integer> filesCount = new HashMap<>();
        try {
            String extension;
            for (File file : files) {
                extension = getFileExtension(file).toLowerCase();
                if (filesCount.containsKey(extension)) {
                    filesCount.put(extension, filesCount.get(extension) + 1);
                } else {
                    filesCount.put(extension, 1);
                }
            }
        } catch (Exception e) {
            logger.error(e.getMessage());
        }
        return filesCount;
    }

    public List<File> readFiles(String directory, String fileType) {
        List<File> filesList;
        List<File> files = new ArrayList<>();
        String extension;
        try {
            File dir = new File(directory);
            if (dir.exists() && dir.isDirectory()) {
                filesList = Arrays.asList(Objects.requireNonNull(dir.listFiles()));
                List<File> fileLst = new ArrayList<>(filesList);
                for (File file : fileLst) {
                    extension = getFileExtension(file);
                    if (extension.equalsIgnoreCase(fileType)) {
                        files.add(file);
                    }
                }
                logger.debug("Reading {} files from : {}", fileType, directory);
                return files;
            }
            logger.debug("No files found in : {}", directory);
        } catch (Exception e) {
            logger.error(e.getMessage());
        }
        return Collections.emptyList();
    }

    public String readFileAsString(String file) {
        try {
            return new String(Files.readAllBytes(Paths.get(file)));
        } catch (Exception e) {
            logger.error(e.getMessage());
        }
        return null;
    }

    public Object readPolicy(String policyName, String policyFile) {
        Object policy = null;
        try {
            File file = new File(RULESFILEPATH + policyFile);
            policy = io.restassured.path.json.JsonPath.from(file).getString(policyName);
            logger.debug("Policy :: {} : {}", policyName, policy);
        } catch (Exception e) {
            logger.error(e.getMessage());
        }
        return policy;
    }

    public Map<String, Object> readPolicyObject(String policyName, String policyFile) {
        Map<String, Object> policy = new HashMap<>();
        try {
            File file = new File(RULESFILEPATH + policyFile);
            policy = io.restassured.path.json.JsonPath.from(file).getMap(policyName);
            logger.debug("Policy :: {} : {}", policyName, policy);
        } catch (Exception e) {
            logger.error(e.toString());
        }
        return policy;
    }

    public boolean checkFileNameExtensionPattern(File file, String rule, String regex) {
        try {
            String fileName = file.getName();
            Pattern pattern = Pattern.compile(regex);
            Matcher matcher = pattern.matcher(fileName);
            if (matcher.matches()) {
                logger.info("File name policy : {} matches for file {}", rule, file.getName());
                return true;
            } else {
                logger.info("File name policy : {} does not matches for file {}", rule, file.getName());
                return false;
            }
        } catch (Exception e) {
            logger.error(e.getMessage());
            return false;
        }
    }

    private StringBuilder addToLocalSummary(int filesSize, int passCount, int failCount) {
        StringBuilder localSummary = new StringBuilder();

        localSummary.append(HTML.TR + HTML.TD + "Total files: " + HTML.TD_CLOSE + HTML.TD).append(filesSize).append(HTML.TD_CLOSE);
        localSummary.append(HTML.TR + HTML.TD + "Passed : " + HTML.TD_CLOSE + HTML.TD).append(passCount).append(HTML.TD_CLOSE);
        localSummary.append(HTML.TR + HTML.TD + "Failed : " + HTML.TD_CLOSE + HTML.TD).append(failCount).append(HTML.TD_CLOSE);
        localSummary.append(HTML.TABLE_CLOSE);
        return localSummary;
    }

    private boolean verifyRulesTryCatchBlock(List<File> files, String xmlregex, String csvregex, Map<File, String> fileNamePattern) {
        boolean extensionValid;
        String regex = null;
        int passCount = 0;
        int failCount = 0;
        boolean flag = true;
        StringBuilder localSummary;

        try {
            for (File file : files) {
                String extension = getFileExtension(file);
                if (extension.equalsIgnoreCase("xml")) {
                    regex = xmlregex;
                    extensionValid = true;
                } else if (extension.equalsIgnoreCase("csv")) {
                    regex = csvregex;
                    extensionValid = true;
                } else {
                    extensionValid = false;
                    logger.error("Extension Invalid for :: {}", file.getName());
                }
                if (extensionValid && checkFileNameExtensionPattern(file, extension + FILENAME_REGEX_PATTERN, regex)) {
                    fileNamePattern.put(file, "pass");
                    passCount++;
                } else {
                    fileNamePattern.put(file, "fail");
                    flag = false;
                    failCount++;
                }
            }
            localSummary = addToLocalSummary(files.size(), passCount, failCount);
            if (flag) {
                logger.info("Rules passed for all files");
            }
            fileMap.put(FILE_NAME_EXT, fileNamePattern);
            appendTextInGlobalSummary(localSummary.toString());
        } catch (Exception e) {
            logger.error(e.getMessage());
        }
        return flag;
    }

    public boolean verifyFileRules(List<File> files, String policyFile) {
        Map<File, String> fileNamePattern = new HashMap<>();
        boolean flag;
        String csvregex = (String) readPolicy("csv.filename_regex_pattern", policyFile);
        String xmlregex = (String) readPolicy("xml.filename_regex_pattern", policyFile);
        if (csvregex == null || xmlregex == null) {
            Map<String, Integer> fileTypes = filesCount(files);
            if (csvregex == null && fileTypes.containsKey("csv")) {
                appendTextInGlobalSummary(HTML.TR + HTML.TD + "The rule for CSV files are not defined." + HTML.TD_CLOSE + HTML.TR_CLOSE + HTML.TABLE_CLOSE);
                logger.error(getFailedstep("The rule for CSV files is not defined."));
            } else if (xmlregex == null && fileTypes.containsKey("xml")) {
                appendTextInGlobalSummary(HTML.TR + HTML.TD + "The rule for XML files are not defined." + HTML.TD_CLOSE + HTML.TR_CLOSE + HTML.TABLE_CLOSE);
                logger.error(getFailedstep("The rule for XML files is not defined."));
            }
        }
        flag = verifyRulesTryCatchBlock(files, xmlregex, csvregex, fileNamePattern);
        return flag;
    }

    public boolean verifyFileRules(List<File> files, String policyFile, String extension) {
        StringBuilder localSummary;

        int passCount = 0;
        int failCount = 0;
        Map<File, String> fileNamePattern = new HashMap<>();
        boolean flag = true;
        String regex = (String) readPolicy(extension + FILENAME_REGEX_PATTERN, policyFile);
        try {
            for (File file : files) {
                if (checkFileNameExtensionPattern(file, extension + FILENAME_REGEX_PATTERN, regex)) {
                    fileNamePattern.put(file, "pass");
                    passCount++;
                } else {
                    fileNamePattern.put(file, "fail");
                    flag = false;
                    failCount++;
                }
            }
            localSummary = addToLocalSummary(files.size(), passCount, failCount);
            if (flag) {
                logger.info("Rules passed for all files");
            }
            appendTextInGlobalSummary(localSummary.toString());
        } catch (Exception e) {
            logger.error(e.getMessage());
        }
        fileMap.put(FILE_NAME_EXT, fileNamePattern);
        return flag;
    }

    public String getFileExtension(File file) {
        String extension = null;
        try {
            String fileName = file.getName();
            extension = FilenameUtils.getExtension(fileName);
        } catch (Exception e) {
            logger.error(e.getMessage());
        }
        return extension;
    }

    public void writeFileSummary(String fileName) throws IOException {
        if (!fileMap.isEmpty()) {
            File directory = new File(Constants.FEEDFILEREPORTS);
            if (!directory.exists()) {
                directory.mkdirs();
                logger.info("Directory created : {}", directory.getName());
            }
            File fileObject = new File(Constants.FEEDFILEREPORTS + fileName);
            FileWriter writer = null;
            try {
                if (fileObject.exists()) {
                    fileObject.delete();
                }
                fileObject.createNewFile();
                writer = new FileWriter(fileObject);
                writer.write(HTML.HTML_START);
                if (fileMap.contains(FILE_NAME_EXT)) {
                    HashMap<File, String> records = (HashMap<File, String>) fileMap.get(FILE_NAME_EXT);
                    File file;
                    writer.write(HTML.TABLE + HTML.TR + HTML.TH + "Status of files for File Name Extension Rules :" + HTML.TH_CLOSE + HTML.TR_CLOSE);
                    if (records.isEmpty()) {
                        writer.write(HTML.TR + HTML.TD + "No Files are available to validate File Name Extension" + HTML.TD_CLOSE + HTML.TR_CLOSE);
                    } else {
                        for (Map.Entry<File, String> recordEntry : records.entrySet()) {
                            file =recordEntry.getKey();
                            writer.write(HTML.TR + HTML.TD + file.getName() + HTML.TD_CLOSE + HTML.TD + recordEntry.getValue() + HTML.TD_CLOSE + HTML.TR_CLOSE);
                        }
                    }
                    writer.write(HTML.TABLE_CLOSE);
                }
                if (fileMap.contains(FILE_STRUCTURE)) {
                    HashMap<File, String> records = (HashMap<File, String>) fileMap.get(FILE_STRUCTURE);
                    File file;
                    writer.write(HTML.TABLE + HTML.TR + HTML.TH + "Status of files for File Structure Rules :" + HTML.TH_CLOSE + HTML.TR_CLOSE);
                    if (records.isEmpty()) {
                        writer.write(HTML.TR + HTML.TD + "No Files are available to validate File Structure" + HTML.TD_CLOSE + HTML.TR_CLOSE);
                    } else {
                        for (Map.Entry<File, String> recordEntry : records.entrySet()) {
                            file =recordEntry.getKey();
                            writer.write(HTML.TR + HTML.TD + file.getName() + HTML.TD_CLOSE + HTML.TD + recordEntry.getValue() + HTML.TD_CLOSE + HTML.TR_CLOSE);
                        }
                    }
                    writer.write(HTML.TABLE_CLOSE);
                }
                if (fileMap.contains(BLOB_DOWNLOADED)) {
                    List<String> records = (List<String>) fileMap.get(BLOB_DOWNLOADED);
                    writer.write(HTML.TABLE + HTML.TR + HTML.TH + "Blobs downloaded :" + HTML.TH_CLOSE + HTML.TR_CLOSE);
                    if (records.isEmpty()) {
                        writer.write(HTML.TR + HTML.TD + "No Files are available to download from BLOB" + HTML.TD_CLOSE + HTML.TR_CLOSE);
                    } else {
                        for (String recordEntry : records) {
                            writer.write(HTML.TR + HTML.TD + recordEntry + HTML.TD_CLOSE + HTML.TR_CLOSE);
                        }
                    }
                    writer.write(HTML.TABLE_CLOSE);
                }
                if (fileMap.contains(DATA_QUALITY)) {
                    HashMap<File, String> records = (HashMap<File, String>) fileMap.get(DATA_QUALITY);
                    File file;
                    writer.write(HTML.TABLE + HTML.TR + HTML.TH + "Status of files for File Data Quality :" + HTML.TH_CLOSE + HTML.TR_CLOSE);
                    if (records.isEmpty()) {
                        writer.write(HTML.TR + HTML.TD + "No Files are available to validate File Data Quality" + HTML.TD_CLOSE + HTML.TR_CLOSE);
                    } else {
                        for (Map.Entry<File, String> recordEntry : records.entrySet()) {
                            file =recordEntry.getKey();
                            writer.write(HTML.TR + HTML.TD + file.getName() + HTML.TD_CLOSE + HTML.TD + recordEntry.getValue() + HTML.TD_CLOSE + HTML.TR_CLOSE);
                        }
                    }
                    writer.write(HTML.TABLE_CLOSE);
                }
                writer.write(HTML.HTML_CLOSE);
                contextMap.put("fileMap", "true");
            } catch (Exception e) {
                logger.error(e.getMessage());
            } finally {
                fileMap.clear();
                if (writer != null) {
                    writer.flush();
                    writer.close();
                }
            }
        }
    }
}
