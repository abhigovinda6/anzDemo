package com.qe.framework.common;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.jayway.jsonpath.DocumentContext;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.Iterator;
import java.util.List;
import java.util.Objects;

public class JsonValidation {

    private JsonValidation() {
        throw new IllegalStateException("Utility class");
    }

    // ::FUTURE::
    private static String returnValueFromJSonaArray(final JSONArray currentJson, final String inputKey) throws JSONException {
        String valueOfInputKey = null;
        for (int i = 0; i < currentJson.length(); i++) {
            JSONObject explrObject = currentJson.getJSONObject(i);
            try {
                valueOfInputKey = (String) explrObject.get(inputKey);
            } catch (ClassCastException e) {
                int valOfKey = explrObject.getInt(inputKey);
                valueOfInputKey = Integer.toString(valOfKey);
            }
        }
        return valueOfInputKey;
    }

    @SuppressWarnings("null")
    public static List<String> attributeMatchingRecursive(JsonNode root, String field, String value, List<String> aryLst) {
        JsonNode fieldValue = null;

        if (root.isObject()) {
            Iterator<String> fieldNames = root.fieldNames();

            while (fieldNames.hasNext()) {
                String fieldName = fieldNames.next();
                fieldValue = root.get(fieldName);
                if (fieldName.equalsIgnoreCase(field)) {
                    validationOfValue(fieldValue, value, aryLst);
                }

                attributeMatchingRecursive(fieldValue, field, value, aryLst);
            }
        } else if (root.isArray()) {
            ArrayNode arrayNode = (ArrayNode) root;
            for (int i = 0; i < arrayNode.size(); i++) {
                JsonNode arrayElement = arrayNode.get(i);
                if (Objects.equals(arrayElement.asText(), field)) {
                    aryLst.add(fieldValue.textValue());
                }
                attributeMatchingRecursive(arrayElement, field, value, aryLst);
            }
        }
        return aryLst;
    }

    public static void validationOfValue(JsonNode fieldValue, String value, List<String> aryLst) {
        if ((Objects.nonNull(value) && fieldValue.asText().contains(value)) || Objects.isNull(value)) {
            aryLst.add(fieldValue.asText());
        }
    }

    public static int getNodeSize(JsonNode root, String field) {
        JsonNode fieldValue = null;

        if (root.isObject()) {
            Iterator<String> fieldNames = root.fieldNames();

            while (fieldNames.hasNext()) {
                String fieldName = fieldNames.next();
                fieldValue = root.get(fieldName);
                if (fieldName.equalsIgnoreCase(field)) {
                    return fieldValue.size();
                }
                getNodeSize(fieldValue, field);
            }
        } else if (root.isArray()) {
            ArrayNode arrayNode = (ArrayNode) root;
            for (int i = 0; i < arrayNode.size(); i++) {
                JsonNode arrayElement = arrayNode.get(i);
                if (Objects.equals(arrayElement.asText(), field)) {
                    return fieldValue.size();
                }
                getNodeSize(arrayElement, field);
            }
        }
        return 0;
    }

    public static String getValueFromJSon(final String response, final String node) {
        String value = null;
        try {
            DocumentContext jsonPayload = com.jayway.jsonpath.JsonPath.parse(response);
            value = jsonPayload.read(node).toString();
        } catch (NullPointerException e) {
            throw new NullPointerException("The argument cannot be null");
        }
        return value;

    }

}
