package com.qe.framework.enums;

public enum GestureDirection {
    IN,
    OUT;
}
