package com.qe.framework.enums;

public enum SelectBy {

    TEXT,
    INDEX,
    VALUE;
}
