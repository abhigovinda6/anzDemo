package com.qe.framework.common;

import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

public class XLSHelper {
    private static final Logger logger = LoggerFactory.getLogger(XLSHelper.class);

    public void writeXLSFile(Workbook workbook, String fileName, String path) {
        OutputStream fileOut
                = null;
        try {
            fileOut = new FileOutputStream(path + fileName + ".xlsx");
        } catch (FileNotFoundException e) {
            logger.error(e.getMessage());
        }
        try {
            workbook.write(fileOut);
        } catch (IOException e) {
            logger.error(e.getMessage());
        }
    }

    public XSSFWorkbook createWorkBook() {
        return new XSSFWorkbook();
    }

    public XSSFSheet createSheet(XSSFWorkbook workbook, String sheetName) {
        return workbook.createSheet(sheetName);
    }

    public XSSFRow createRow(XSSFSheet sheet, int index) {
        return sheet.createRow(index);
    }

    public XSSFCell createCell(XSSFRow row, int index) {
        return row.createCell(index);
    }

    public void putValueInCell(XSSFCell cell, String value) {
        cell.setCellValue(value);
    }

    public void setCellStyle(XSSFCell cell, XSSFCellStyle xssfCellStyle) {
        cell.setCellStyle(xssfCellStyle);
    }

    public XSSFCell createCell(XSSFRow row, int index, XSSFCellStyle xssfCellStyle) {
        XSSFCell cell = row.createCell(index);
        cell.setCellStyle(xssfCellStyle);
        return cell;
    }

    public XSSFCellStyle styleForFailure(XSSFWorkbook workbook) {
        XSSFCellStyle cellStyle = workbook.createCellStyle();
        cellStyle.setFillPattern(FillPatternType.FINE_DOTS);
        cellStyle.setFillBackgroundColor(IndexedColors.RED.index);
        return cellStyle;
    }


}
