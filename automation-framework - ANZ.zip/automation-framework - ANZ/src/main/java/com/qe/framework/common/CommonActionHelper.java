package com.qe.framework.common;

import com.qe.framework.customexception.ExceptionAndErrors;
import com.qe.framework.enums.*;
import com.qe.framework.web.helpers.WebDriverHelper;
import cucumber.api.Scenario;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.Date;
import java.util.List;
import java.util.Set;

import static com.qe.framework.common.Constants.*;
import static com.qe.framework.common.PropertiesHelper.contextMap;

public class CommonActionHelper extends WebDriverHelper {

    public static final String GLOBAL_SUMMARY = "globalSummary";
    public static final String FAILED = "FAILED-";
    private static final Logger logger = LoggerFactory.getLogger(CommonActionHelper.class);
    public static String getCurrnetMethodName;
    public static WebElement webElement;
    static String parentWinHandle;
    static Set<String> winHandles;
    static String parentTitle;
    static String currentTitle;
    private static CommonActionHelper objcom = null;
    public static AppiumDriver<MobileElement> mobileDriver;
    private static boolean isStepPass = false;
    private static WebElement objElement;
    public String currentElement = null;
    public List<List<String>> elements = null;
    public String elementValue = null;
    public List<WebElement> webElementLS = null;
    long startTime = 0;

    public CommonActionHelper() {

    }

    public CommonActionHelper(AppiumDriver<MobileElement> driver) {
        mobileDriver = driver;
    }

    public static CommonActionHelper getInstance() {
        if (objcom == null)
            objcom = new CommonActionHelper();

        return objcom;
    }

    public static boolean fluentwaitForElement(By element) {
        return fluentwaitForElement(element, fluentWaitTime, fluentPollingWaitTime);
    }

    public static boolean fluentwaitForElement(By element, int maxWait, int polling) {
        boolean flag = false;
        if (element != null) {
            logger.info("Waiting for element fluentwaitForElement: {}", element);
            remdriver = Constants.remdriver;
            try {
                FluentWait<WebDriver> drvWait = new FluentWait<WebDriver>(remdriver).ignoring(NoSuchElementException.class);
                drvWait.pollingEvery(Duration.ofSeconds(polling))
                        .withTimeout(Duration.ofSeconds(maxWait));
                drvWait.until(ExpectedConditions.visibilityOfElementLocated(element));
                flag = true;
            } catch (Exception e) {
                String tmpMessage = "After waiting for " + maxWait + " seconds : Element not found";
                logger.debug(tmpMessage);
            }
            logger.info("Element is visible -: {}", element);
        }
        return flag;
    }

    public static void waitForPageLoad(WebDriver driver) throws InterruptedException {
        boolean pageLoadwaitFlag = false;
        remdriver = Constants.remdriver;
        // @Override
        ExpectedCondition<Boolean> pageLoadCondition = driver1 -> ((JavascriptExecutor) driver1).executeScript("return document.readyState").equals("complete");

        WebDriverWait drvWait = new WebDriverWait(driver, pageLoadWaitTime);
        drvWait.until(pageLoadCondition);
        pageLoadwaitFlag = true;
        Thread.sleep(2000);
        logger.debug("Page load wait time seconds: {} :: isPageLoaded: {}", pageLoadWaitTime, pageLoadwaitFlag);
    }

    public static void takeScreenshot() {
        try {
            remdriver = Constants.remdriver;
            File src = ((TakesScreenshot) remdriver).getScreenshotAs(OutputType.FILE);
            FileUtils.copyFile(src, new File(Constants.REPORTSCREENSHOTFOLDERPATH + Constants.screenShortTagNames + "_"
                    + new SimpleDateFormat("ddMMyyyyHHmmss").format(new Date()) + ".png"));

        } catch (IOException e) {
            logger.error(e.getMessage());
        }
    }

    public static void executeJS(String script, WebElement webElement) {
        JavascriptExecutor jsExecutor = (JavascriptExecutor) remdriver;
        jsExecutor.executeScript(script, webElement);
    }

    // Wait for element visible using By Locator
    public static void waitForElementVisible(By element) {
        logger.info("Waiting for element : {}", element);
        remdriver = Constants.remdriver;
        int waitingtime = Constants.explicitWaitTime;
        boolean exitWhile = false;
        Exception exp = null;
        if (element != null) {
            int indx = 0;
            while (indx < 2 && !exitWhile) {
                try {
                    WebDriverWait drvWait = new WebDriverWait(remdriver, waitingtime);
                    drvWait.until(ExpectedConditions.visibilityOfElementLocated(element));
                    exitWhile = true;

                } catch (Exception e) {
                    logger.info("attempting again to search for the element");
                    exp = e;
                    exitWhile = false;
                }
                indx++;
            }
            if (indx == 2 && !exitWhile) {
                logger.error(ExceptionAndErrors.getFailedstep("FAILED- waitForElementVisible By-Element <-> " + exp));
            }
        }
    }

    public static By getObjectLocator(WebElement imgLogo) {
        String type = "";
        String value = "";

        By locator = null;
        String elementStr = imgLogo.toString();
        logger.debug("getObjectLocator_ WebElement locator is : {}", elementStr);
        if (elementStr != null && elementStr.contains("->")) {
            String[] sraary = elementStr.split("->");
            elementStr = sraary[1];
            int index = elementStr.indexOf(":");
            type = elementStr.substring(0, index).trim();
            value = elementStr.substring(index + 1, elementStr.length() - 1).trim();
        } else if (elementStr != null && elementStr.contains("Proxy element for: DefaultElementLocator '")) {
            int index = elementStr.indexOf("Locator '");
            elementStr = elementStr.substring(index + 9);
            int ss1 = elementStr.indexOf(":", 1);
            value = elementStr.substring(ss1 + 2, elementStr.length() - 1);
            elementStr = elementStr.substring(0, ss1);
            type = elementStr.substring(elementStr.indexOf(".", 1) + 1);
        }
        type = Utils.toCamelCase(type);
        logger.debug("Locator Type::{}", type);
//		if (type != null && !type.equalsIgnoreCase("xpath")) {
//			value = "'" + value + "'";
//		}
        logger.debug("Locator Value:: {}", value);
        LocatorTypeEnum ltEnum = LocatorTypeEnum.valueOf(type);
        switch (ltEnum) {
            case id:
                locator = By.id(value);
                break;
            case name:
                locator = By.name(value);
                break;
            case css:
                locator = By.cssSelector(value);
                break;
            case linkText:
                locator = By.linkText(value);
                break;
            case partialLinkText:
                locator = By.partialLinkText(value);
                break;
            case tagName:
                locator = By.tagName(value);
                break;
            case xpath:
                locator = By.xpath(value);
                break;
            default:
                locator = By.xpath(value);
                break;
        }
        return locator;
    }

    public static boolean waitForElement(By element) {
        boolean flag = false;
        remdriver = Constants.remdriver;
        logger.info("Waiting for element : {}", element);
        if (remdriver != null) {
            drvWait = new WebDriverWait(remdriver, Constants.explicitWaitTime);
        }
        if (element != null) {
            try {
                assert remdriver != null;
                drvWait = new WebDriverWait(remdriver, implicitWaitTime);
                drvWait.until(ExpectedConditions.presenceOfElementLocated(element));
                flag = true;
            } catch (NoSuchElementException | TimeoutException e) {
                logger.error(ExceptionAndErrors.getFailedstep(element + "<->" + e));
            }
        }
        return flag;
    }

    //    Get the title of a page
    public static String getTitle() {
        remdriver = Constants.remdriver;
        String screenTitle = remdriver.getTitle();
        logger.info("The title is {}", screenTitle);

        return screenTitle;
    }

    //    Get the current URL of the application
    public static String getCurrentPageURL() {
        if (Utils.isMobileTest(null)) {
            mobileDriver = (AppiumDriver<MobileElement>) Constants.remdriver;
            return mobileDriver.getCurrentUrl();
        } else
            remdriver = Constants.remdriver;
        return remdriver.getCurrentUrl();
    }

    public static boolean scrollPageToWebElement(WebElement element) {
        boolean flag = false;
        getCurrnetMethodName = Thread.currentThread().getStackTrace()[1].getMethodName();
        try {
            remdriver = Constants.remdriver;
            ((JavascriptExecutor) remdriver).executeScript("arguments[0].scrollIntoView(true);", element);
            captureScreenShot(Constants.PASS);
            logger.info("PASSED  scrollPageToWebElement -:  {}", element);

            flag = true;
            Thread.sleep(2000);
            // to scroll down a bit, so that element is visible on page
            ((JavascriptExecutor) remdriver).executeScript("window.scrollBy(0,-200)", "");
        } catch (InterruptedException e) {
            captureScreenShot(Constants.FAIL);
            logger.error(ExceptionAndErrors.getFailedstep("FAILED- " + getCurrnetMethodName + "<->" + element + "<->" + e));
            Thread.currentThread().interrupt();
        }
        return flag;
    }

    public static WebElement runTimeXpath(String xvalue) {
        WebElement elem = null;
        By locator = null;
        remdriver = Constants.remdriver;
        assert remdriver != null;
        try {
            logger.info("runTimeXpath for element :  {}", xvalue);
            drvWait = new WebDriverWait(remdriver, Constants.explicitWaitTime);
            if (xvalue != null) {
                String value = "//*[contains(text(), " + xvalue + ")]";
                locator = By.xpath(value);
                WebDriverWait drvWait = new WebDriverWait(remdriver, Constants.explicitWaitTime);
                drvWait.until(ExpectedConditions.presenceOfElementLocated(locator));
                elem = remdriver.findElement(By.xpath(value));
            }
            captureScreenShot(Constants.PASS);

        } catch (Exception e) {
            logger.error("clickOnButton exception msg:: {}", e.getMessage());
            captureScreenShot(Constants.FAIL);
        }
        return elem;
    }

    public static By runTimeTextXpath(String xpath, String value) {
        getCurrnetMethodName = Thread.currentThread().getStackTrace()[1].getMethodName();
        By locator = null;
        try {
            if (xpath != null) {
                xpath = xpath.replace("RTXV", value);
                locator = By.xpath(xpath);
            }
            logger.info("PASSED runTimeTextXpath-:  {}", xpath);
            captureScreenShot(Constants.PASS);
        } catch (Exception e) {
            captureScreenShot(Constants.FAIL);
            logger.error(ExceptionAndErrors.getFailedstep("FAILED- <->" + getCurrnetMethodName + "<->" + xpath + "<->" + e));

        }
        return locator;
    }

    protected static boolean verifyTextPresent(String expectedText) {
        logger.info("Check if the Text is persent on the page");
        getCurrnetMethodName = Thread.currentThread().getStackTrace()[1].getMethodName();

        try {
            waitForPageLoad(getDriver());
            String pageText = remdriver.getPageSource();
            boolean result = pageText.contains(expectedText);
            captureScreenShot(Constants.PASS);
            return result;
        } catch (Exception e) {
            captureScreenShot(Constants.FAIL);
            logger.error("FAILED- {} -- {} -- {}", getCurrnetMethodName, expectedText, e);
            Thread.currentThread().interrupt();
        }
        return false;
    }

    public static boolean embedScreenshot(Scenario scenario) {
        boolean flag = false;
        try {
            remdriver = Constants.remdriver;
            takeScreenshot();
            scenario.embed(((TakesScreenshot) remdriver).getScreenshotAs(OutputType.BYTES), "image/png");
            flag = true;
        } catch (WebDriverException wde) {
            logger.error("embedScreenshot() inside WebDriverException while execution:: {}", wde.getMessage());
        } catch (ClassCastException cce) {
            logger.error("embedScreenshot() inside ClassCastException while execution:: {}", cce.getMessage());
        }
        logger.debug("EmbedScreenshot flag:: {}", flag);
        return flag;
    }

    public static void captureScreenShot(String status) {
        logger.debug("Status:: {}", status);

        isStepPass = Constants.PASS.equalsIgnoreCase(status);

        if ("no".equalsIgnoreCase(PropertiesHelper.CAPTURE_ONLY_FAIL) && !isStepPass) {
            takeScreenshot();
        }
    }

    public static void close() {
        try {
            remdriver = Constants.remdriver;
            captureScreenShot(Constants.PASS);
            if (remdriver != null) {
                remdriver.quit();
            }
        } catch (Exception e) {
            logger.error("close driver() inside Exception while execution:: {}", e.getMessage());
            captureScreenShot(Constants.FAIL);
        }
    }

    protected static boolean moveHover(WebElement element) {
        getCurrnetMethodName = Thread.currentThread().getStackTrace()[1].getMethodName();
        boolean flag = false;
        remdriver = Constants.remdriver;
        try {
            logger.info("Hover on an element");
            objElement = element;
            Actions actions = new Actions(remdriver);
            actions.moveToElement(objElement).perform();
            flag = true;
            fluentwaitForElement(getObjectLocator(element));
            captureScreenShot(Constants.PASS);
        } catch (Exception e) {
            logger.error(ExceptionAndErrors.getFailedstep(element + "<->" + e));
        }
        return flag;
    }

    //    Get the text of a label
    protected static String getText(WebElement element) {
        String actualText = null;
        try {
            objElement = element;
            if (objElement.isEnabled()) {
                actualText = objElement.getText();
                captureScreenShot(Constants.PASS);
            } else {
                captureScreenShot(Constants.FAIL);
            }
        } catch (Exception e) {
            logger.error("gettext exception msg");
        }

        actualText = Utils.cleanHTMLtags(actualText);
        logger.info("The actual text associated with the WebElement is -> {}", actualText);
        return actualText;
    }

    public static String getAttributeElement(WebElement element, String attributeType) {
        String attributeValue = null;
        try {
            objElement = element;
            if (objElement.isEnabled()) {
                attributeValue = objElement.getAttribute(attributeType);
                captureScreenShot(Constants.PASS);
            } else {
                captureScreenShot(Constants.FAIL);
            }
        } catch (Exception e) {
            logger.error("gettext exception msg");
        }
        logger.info("The actual attribute associated with the WebElement is -> {}", attributeValue);
        return attributeValue;
    }

    public static boolean verifyElementTextWithActualText(WebElement element, String actualText) {
        logger.info("Verify Expected and Actual Text Verification");
        boolean flag = false;
        String runTimeText="";
        try {
            objElement = element;
            actualText = Utils.prepareDataString(actualText);
            if(objElement.getTagName().equalsIgnoreCase("select")){
                Select sec= new Select(objElement);
               runTimeText= sec.getFirstSelectedOption().getText();
            }
            else
            {
               runTimeText= getText(element).trim();
            }
            if (runTimeText.equals(actualText.trim())) {
                flag = true;
                logger.info("Expected text is mathching with Actual ->  {}", actualText);

                captureScreenShot(Constants.PASS);
            } else {
                captureScreenShot(Constants.FAIL);
            }
        } catch (Exception e) {

            logger.error(ExceptionAndErrors.getFailedstep(e, element));
        }
        return flag;
    }

    public static boolean scrollToTopBottomPage(String position) {
        getCurrnetMethodName = Thread.currentThread().getStackTrace()[1].getMethodName();

        boolean flag = false;
        try {
            remdriver = Constants.remdriver;
            if (position.equalsIgnoreCase("bottom")) {
                ((JavascriptExecutor) remdriver).executeScript("window.scrollTo(0, document.body.scrollHeight)");
                flag = true;
                logger.info("PASSED  in method scrollToTopBottomPage-:  {}", position);

            } else if (position.equalsIgnoreCase("top")) {
                ((JavascriptExecutor) remdriver).executeScript("window.scrollTo(document.body.scrollHeight, 0)");
                flag = true;
                logger.info("PASSED -:  {}", position);
            }

        } catch (Exception e) {
            logger.error(ExceptionAndErrors.getFailedstep(FAILED + "<->" + getCurrnetMethodName + "<->" + position + "<->" + e));
        }
        return flag;
    }

    protected static boolean switchToChildWindow(String titleText) {
        getCurrnetMethodName = Thread.currentThread().getStackTrace()[1].getMethodName();

        boolean flag = false;
        try {
            remdriver = Constants.remdriver;
            parentTitle = remdriver.getTitle();
            parentWinHandle = remdriver.getWindowHandle();
            winHandles = remdriver.getWindowHandles();

            for (String handle : winHandles) {
                if (!handle.equals(parentWinHandle)) {
                    remdriver.switchTo().window(handle);
                    Thread.sleep(1000);
                    currentTitle = remdriver.getTitle();
                    logger.info("Title of the new window:  {}", remdriver.getTitle());
                }
            }

            if (currentTitle.contains(titleText)) {
                captureScreenShot(Constants.PASS);
                flag = true;
            }
        } catch (Exception e) {
            captureScreenShot(Constants.FAIL);
            logger.error(ExceptionAndErrors.getFailedstep(FAILED + "<->" + getCurrnetMethodName + e));
            Thread.currentThread().interrupt();
        }
        return flag;
    }

    protected static boolean switchBackToParentWindow() {
        getCurrnetMethodName = Thread.currentThread().getStackTrace()[1].getMethodName();

        boolean flag = false;
        try {
            remdriver = Constants.remdriver;
            remdriver.switchTo().window(parentWinHandle);
            logger.info("Title of the switch back window:  {}", remdriver.getTitle());
            currentTitle = remdriver.getTitle();

            if (currentTitle.equals(parentTitle)) {
                captureScreenShot(Constants.PASS);
                flag = true;
            }
        } catch (Exception e) {
            captureScreenShot(Constants.FAIL);

            logger.error(ExceptionAndErrors.getFailedstep(FAILED + "<->" + getCurrnetMethodName + e));
        }
        return flag;
    }

    protected static boolean switchBackToDefaultWindow() {
        getCurrnetMethodName = Thread.currentThread().getStackTrace()[1].getMethodName();

        boolean flag = false;
        try {
            remdriver = Constants.remdriver;
            remdriver.switchTo().defaultContent();
            logger.info("Title of the switch back window:  {}", remdriver.getTitle());
            currentTitle = remdriver.getTitle();

            if (currentTitle.equals(parentTitle)) {
                captureScreenShot(Constants.PASS);
                flag = true;
            }
        } catch (Exception e) {
            captureScreenShot(Constants.FAIL);
            logger.error(ExceptionAndErrors.getFailedstep(FAILED + "<->" + getCurrnetMethodName + e));
        }
        return flag;
    }

    public static boolean clickOnButtonList(List<WebElement> element, int index) throws InterruptedException {
        getCurrnetMethodName = Thread.currentThread().getStackTrace()[1].getMethodName();
        return click(element.get(index));
    }

    protected static boolean moveAndClick(WebElement element, int xOffset, int yOffset) {
        getCurrnetMethodName = Thread.currentThread().getStackTrace()[1].getMethodName();
        boolean flag = false;
        remdriver = Constants.remdriver;
        try {
            objElement = element;
            flag = true;
            if (waitForElement(element, ElementCondition.IS_CLICKABLE)) {
                Actions actions = new Actions(remdriver);
                actions.moveToElement(objElement, xOffset, yOffset).click().build().perform();
                Thread.sleep(1000);
                captureScreenShot(Constants.PASS);
            } else {
                flag = false;
                captureScreenShot(Constants.FAIL);
                logger.error(ExceptionAndErrors.getFailedstep(FAILED + "<->" + getCurrnetMethodName + "<->" + element));
            }
        } catch (Exception e) {
            captureScreenShot(Constants.FAIL);
            logger.error(ExceptionAndErrors.getFailedstep("FAILED-<->" + getCurrnetMethodName + "<->" + element + "<->" + e));
            Thread.currentThread().interrupt();
        }
        return flag;
    }

    public static boolean sendKeyboardAction(WebElement element, String keyAction) throws InterruptedException {
        getCurrnetMethodName = Thread.currentThread().getStackTrace()[1].getMethodName();
        boolean flag = false;
        objElement = element;
        try {
            switch (keyAction) {
                case "ENTER":
                    objElement.sendKeys(Keys.ENTER);
                    captureScreenShot(Constants.PASS);
                    flag = true;
                    break;
                case "TAB":
                    objElement.sendKeys(Keys.TAB);
                    captureScreenShot(Constants.PASS);
                    flag = true;
                    break;
                case "KEYDOWN":
                    objElement.sendKeys(Keys.DOWN);
                    captureScreenShot(Constants.PASS);
                    flag = true;
                    break;

                case "ESC":
                    objElement.sendKeys(Keys.ESCAPE);
                    captureScreenShot(Constants.PASS);
                    flag = true;
                    break;

                case "BACK":
                    objElement.sendKeys(Keys.BACK_SPACE);
                    captureScreenShot(Constants.PASS);
                    flag = true;
                    break;

                default:
                    captureScreenShot(Constants.FAIL);
                    logger.error(ExceptionAndErrors.getFailedstep("FAILED Invailed Key Action-" + keyAction + "<->" + getCurrnetMethodName + "<->" + element));
            }

        } catch (Exception e) {
            captureScreenShot(Constants.FAIL);
            logger.error(ExceptionAndErrors.getFailedstep(FAILED + keyAction + "<->" + getCurrnetMethodName + "<->" + element + "<->" + e));

        }
        Thread.sleep(1500);
        return flag;
    }

    public static boolean click(WebElement element) throws InterruptedException {
        getCurrnetMethodName = Thread.currentThread().getStackTrace()[1].getMethodName();
        boolean flag = false;

        try {
            objElement = element;
            if (objElement != null) {
                objElement.click();
                captureScreenShot(Constants.PASS);
                flag = true;
            } else {
                captureScreenShot(Constants.FAIL);
                logger.error(ExceptionAndErrors.getFailedstep(FAILED + "<->" + getCurrnetMethodName + "<->" + element));
            }
        } catch (Exception e) {
            try {
                executeJS("arguments[0].click();", element);
                captureScreenShot(Constants.PASS);
                flag = true;
            } catch (Exception e1) {
                try {
                    Actions actions = new Actions(remdriver);
                    actions.moveToElement(objElement).click().build().perform();
                    Thread.sleep(1000);
                    flag = true;
                    captureScreenShot(Constants.PASS);
                } catch (Exception e2) {
                    logger.error(ExceptionAndErrors.getFailedstep(FAILED + "<->" + getCurrnetMethodName + "<->" + element));
                    logger.error(ExceptionAndErrors.getFailedstep(e, element));
                    Thread.currentThread().interrupt();
                }
            }

        }
        Thread.sleep(3000);
        return flag;
    }

    public static void setInputTextWithOptions(WebElement element, String text, boolean toClear) throws InterruptedException {
        getCurrnetMethodName = Thread.currentThread().getStackTrace()[1].getMethodName();

        logger.info("Input the text box value :  {}", text);
        try {
            objElement = element;
            if (toClear)
                objElement.clear();
            if (!text.isEmpty())
                objElement.sendKeys(text);
            captureScreenShot(Constants.PASS);
        } catch (Exception e) {
            captureScreenShot(Constants.FAIL);
            logger.error(ExceptionAndErrors.getFailedstep("FAILED-+<->" + getCurrnetMethodName + "<->" + element + "<->" + e));
        }
        Thread.sleep(1500);
    }

    public static void selectBy(WebElement element, String text, SelectBy selectBy) {
        logger.info("The Checkbox value to be selected is :  {}", text);
        try {
            objElement = element;
            Select objSelectDropdown = new Select(objElement);
            switch (selectBy) {
                case TEXT:
                    objSelectDropdown.selectByVisibleText(text);
                    break;
                case VALUE:
                    objSelectDropdown.selectByValue(text);
                    break;
                case INDEX:
                    objSelectDropdown.selectByIndex(Integer.parseInt(text));
                    break;
            }
            captureScreenShot(Constants.PASS);
        } catch (Exception e) {
            captureScreenShot(Constants.FAIL);
            logger.error(ExceptionAndErrors.getFailedstep(e, element));
        }
    }

    public static boolean switchToIframe(Object value, IFrame iFrame) {
        getCurrnetMethodName = Thread.currentThread().getStackTrace()[1].getMethodName();
        boolean flag = false;
        try {
            remdriver = Constants.remdriver;
            switch (iFrame) {
                case ID:
                case NAME:
                    remdriver.switchTo().frame((String) value);
                    break;
                case INDEX:
                    remdriver.switchTo().frame((Integer) value);
                    break;
                case WEB_ELEMENT:
                    remdriver.switchTo().frame((WebElement) value);
                    break;
            }
            flag = true;
        } catch (Exception e) {
            captureScreenShot(Constants.FAIL);
            logger.error(ExceptionAndErrors.getFailedstep(FAILED + "<->" + getCurrnetMethodName + "<->" + webElement + "<->" + e));
        }
        return flag;
    }

    public static boolean checkElement(WebElement element, ElementStatus elementStatus) {
        String check = elementStatus.toString().substring(3).toLowerCase();
        logger.info("Check if the Webelement is  {}", check);
        boolean flag = false;
        try {
            objElement = element;
            switch (elementStatus) {
                case IS_ENABLED:
                    flag = objElement.isEnabled();
                    break;
                case IS_DISABLED:
                    flag = !objElement.isEnabled();
                    break;
                case IS_DISPLAYED:
                    flag = objElement.isDisplayed();
                    break;
                case IS_SELECTED:
                    flag = objElement.isSelected();
                    break;
            }
            if (flag) {
                logger.info("{} Element is  {}", element, check);
            } else {
                logger.info("{} Element is not {}", element, check);
            }
        } catch (Exception e) {
            logger.error(ExceptionAndErrors.getFailedstep(e, element));
        }
        return flag;

    }

    public static boolean waitForElement(WebElement element, ElementCondition condition) {
        logger.info("Waiting for element :  {}", element);
        boolean flag = false;
        remdriver = Constants.remdriver;
        if (remdriver != null) {
            drvWait = new WebDriverWait(remdriver, Constants.explicitWaitTime);
        }
        if (element != null) {
            try {
                switch (condition) {
                    case IS_VISIBLE:
                        drvWait.until(ExpectedConditions.visibilityOfAllElements(element));
                        break;
                    case IS_PRESENT:
                        drvWait.until(ExpectedConditions.presenceOfElementLocated(getObjectLocator(element)));
                        break;
                    case IS_CLICKABLE:
                        drvWait.until(ExpectedConditions.elementToBeClickable(element));
                        break;
                }
                flag = true;
            } catch (TimeoutException e) {
                flag = false;
                logger.error(ExceptionAndErrors.getFailedstep(element + "<->" + e));
            }
        }
        return flag;
    }

    public static boolean waitForElement(By element, ElementCondition condition) {
        boolean flag = false;
        remdriver = Constants.remdriver;
        logger.info("Waiting for element :  {}", element);
        if (remdriver != null) {
            drvWait = new WebDriverWait(remdriver, Constants.explicitWaitTime);
        }
        if (element != null) {
            try {
                assert remdriver != null;
                drvWait = new WebDriverWait(remdriver, implicitWaitTime);
                switch (condition) {
                    case IS_PRESENT:
                        drvWait.until(ExpectedConditions.presenceOfElementLocated(element));
                        break;
                    case IS_VISIBLE:
                        drvWait.until(ExpectedConditions.visibilityOfElementLocated(element));
                        break;
                    case IS_CLICKABLE:
                        drvWait.until(ExpectedConditions.elementToBeClickable(element));
                        break;
                }
                flag = true;
            } catch (NoSuchElementException | TimeoutException e) {
                flag = false;
                logger.error(ExceptionAndErrors.getFailedstep(element + "<->" + e));

            }
        }
        return flag;
    }

    public static boolean scrollPageToWebElement(String pageName, String element) {
        boolean flag = false;
        getCurrnetMethodName = Thread.currentThread().getStackTrace()[1].getMethodName();
        try {
            scrollPageToWebElement(GetPOWebElements.getBDDElement(pageName, element));
            flag = true;
            Thread.sleep(2000);
        } catch (Exception e) {
            captureScreenShot(Constants.FAIL);
            logger.error(ExceptionAndErrors.getFailedstep("FAILED- " + getCurrnetMethodName + "<->" + element + "<->" + e));
            Thread.currentThread().interrupt();
        }
        return flag;
    }

    public void getUnImplemented() {
        logger.warn("UnImplemented Feature Statment");
    }

    public void getUnImplemented(String s) {
        logger.warn("UnImplemented Feature Statment {}", s);
    }

    protected void setInputTextWithEnterKey(WebElement element, String text) throws InterruptedException {
        logger.info("Input the text box value :  {}", text);
        setInputTextWithOptions(element, text + "\n", false);
        sendKeyboardAction(element, "ENTER");
    }

    public WebElement getfindElementByXPath(String xpath) {
        WebElement element = null;
        try {

            if (xpath != null) {
                element = getDriver().findElement(By.xpath(xpath));
            }
        } catch (Exception e) {
            logger.error("getfindElementByXPath exception msg:: {}", e.getMessage());
        }
        return element;
    }

    public boolean isStepPass() {
        return isStepPass;
    }

    public static void setStepPass(boolean isStepPass) {
        CommonActionHelper.isStepPass = isStepPass;
    }

    public void clearInput(WebElement element) throws InterruptedException {
        setInputTextWithOptions(element, "", true);
    }

    public void clickUsingJs(WebElement webElement) {
        try {
            logger.info("clicking on element using javascript.......");
            executeJS("arguments[0].click();", webElement);
            logger.info("successfully clicked on element using javascript.......");
        } catch (Exception e) {
            logger.error("Failed to click on element using JS");
            logger.error(e.toString());
            ExceptionAndErrors.getFailedstep(e);
        }
    }

    public String appendTextInContextMap(String key, String value) {
        if (contextMap.contains(key)) {
            contextMap.put(key, contextMap.get(key).concat(value));
            return contextMap.get(key);
        } else {
            logger.info("Key: {} doesn't exists", key);
        }
        return null;
    }

    public String appendTextInGlobalSummary(String text) {
        return appendTextInContextMap(GLOBAL_SUMMARY, "\n" + text);
    }

    public void addInContextMap(String key, String value) {
        contextMap.put(key, value);
    }

    public void loginPage(String username, String password) throws Exception {
        String currnetURL = getCurrentPageURL();
        currnetURL = currnetURL.concat("login");
        remdriver.navigate().to(currnetURL);
        CommonActionHelper.waitForPageLoad(remdriver);
        setInputTextWithOptions(getfindElementByXPath("//*[@id='email']"), username, true);
        setInputTextWithOptions(getfindElementByXPath("//*[@id='password']"), password, true);
        remdriver.findElement(By.xpath("//button[text()='Sign In']")).click();
        CommonActionHelper.waitForPageLoad(remdriver);
        CommonActionHelper.fluentwaitForElement(By.xpath("//nav[@data-testid='account-detail-nav']"));
        remdriver.navigate().to("https://ghs-pwa-development.mobify-storefront.com/trolley");
        CommonActionHelper.waitForPageLoad(remdriver);
        if(CommonActionHelper.fluentwaitForElement(By.xpath("//button[@data-locator='btn-empty-trolley']"))){
            remdriver.findElement(By.xpath("//button[@data-locator='btn-empty-trolley']")).click();
            remdriver.findElement(By.xpath("//button[@data-locator='btn-yes-empty-your-cart']")).click();
            CommonActionHelper.waitForPageLoad(remdriver);
            remdriver.navigate().to("https://ghs-pwa-development.mobify-storefront.com/");

        }
        else{
            CommonActionHelper.fluentwaitForElement(By.xpath("//p[@data-locator='txt-add-your-items']"));
            remdriver.navigate().to("https://ghs-pwa-development.mobify-storefront.com/");

        }
        CommonActionHelper.waitForPageLoad(remdriver);
    }
}