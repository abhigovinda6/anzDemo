package com.qe.framework.web.helpers;

import com.perfecto.reportium.client.ReportiumClientFactory;
import com.perfecto.reportium.model.PerfectoExecutionContext;
import com.perfecto.reportium.model.Project;
import com.qe.framework.common.*;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.logging.LogType;
import org.openqa.selenium.logging.LoggingPreferences;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.safari.SafariDriver;
import org.openqa.selenium.safari.SafariOptions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.regex.Pattern;

import static com.qe.framework.common.Constants.*;
import static com.qe.framework.common.PropertiesHelper.getConfigPropProperty;
import static com.qe.framework.customexception.ExceptionAndErrors.getFailedstep;

public class WebDriverHelper {
    public static final PropertiesHelper webPropHelper = PropertiesHelper.getInstance();
    private static final Logger logger = LoggerFactory.getLogger(WebDriverHelper.class);
    private static final String BROWSER_TYPE = "browserType";
    private static final String CHROME = "chrome";
    private static final String RESPONSIVE = "responsive";
    private static final String PREFS = "prefs";
    private static final String RUN_BROWSER_HEADLESS = "runBrowserHeadLess:: ";
    private static final String USER_AGENT = "--user-agent=";
    private static final String DISABLE_NOTIFICATION = "--disable-notifications";
    private static final String PLATFORM_NAME = "platformName";
    private static final String PERFECTO_MOBILE_ENDPOINT = ".perfectomobile.com/nexperience/perfectomobile/wd/hub";
    private static final String HTTPS = "https://";
    private static final String MAX_LICENCE_REACHED = "Max licence reached for {} / {}. Attempting with default WIN/Chrome";
    private static final String WEB_DEVICE = "$.web.device1";
    private static final String FIREFOX = "firefox";
    public static WebDriver remdriver;
    public static WebDriverWait drvWait;
    static String customAgentName;
    private static String runBrowserHeadLess;


    public static void initializeDriver(boolean isZap) {
        try {

            if (Utils.isMobileTest(null)) {
                logger.error(getFailedstep("Config Error - Attempting to execute Web/Responsive with " + appType + "\n Set AppType as web or responsive/mobile"));
            }
            customAgentName = System.getProperty("customAgentName");
            runBrowserHeadLess = System.getProperty("runBrowserHeadLess");

            if (customAgentName == null) {
                customAgentName = getConfigPropProperty("customAgentName");
            }

            if (runBrowserHeadLess == null) {
                runBrowserHeadLess = getConfigPropProperty("runBrowserHeadLess");
            }

            if (Utils.isWebTest(null)) {
                initializeWebDriver(isZap);
            } else {
                logger.debug(getFailedstep("Platform Type Not correct - Not able to initialize Driver - platformType::" + appType));
            }

            if (remdriver != null) {
                Constants.explicitWaitTime = PropertiesHelper.getWaitTimeProperty("WEBDRIVER_EXPLICIT_WAITTIME_SECONDS");
                Constants.implicitWaitTime = PropertiesHelper.getWaitTimeProperty("WEBDRIVER_IMPLICIT_WAITTIME_SECONDS");
                Constants.pageLoadWaitTime = PropertiesHelper.getWaitTimeProperty("PAGELOAD_WAITTIME_SECONDS");
                Constants.fluentWaitTime = PropertiesHelper.getWaitTimeProperty("WEBDRIVER_FLUENT_WAITTIME_SECONDS");
                Constants.fluentPollingWaitTime = PropertiesHelper.getWaitTimeProperty("WEBDRIVER_FLUENTPOLLING_WAITTIME_SECONDS");
            }
        } catch (Exception e) {
            logger.error(getFailedstep("Exception inside initializeRemoteWebDriver() " + e.getMessage()));
        }
    }


    public static void initializeWebDriver(boolean isZap) throws Exception {
        if (scenarioCloudDevice == null || scenarioCloudDevice.length() == 0) {
            logger.info("scenarioCloudDevice - Found null");
            scenarioCloudDevice = WEB_DEVICE;
        }
        if (driverType.equals("local")) {
            Map<String, String> deviceSpecs = CloudConfig.getWebDeviceSpecs(scenarioCloudDevice);
            try {
                if (CHROME.equalsIgnoreCase(deviceSpecs.get(BROWSER_TYPE))) {
                    launchChromeBrowser(isZap);
                } else if (FIREFOX.equalsIgnoreCase(deviceSpecs.get(BROWSER_TYPE))) {
                    launchFirefoxBrowser();
                } else if ("edge".equalsIgnoreCase(deviceSpecs.get(BROWSER_TYPE))) {
                    launchEdgeBrowser();
                } else if ("safari".equalsIgnoreCase(deviceSpecs.get(BROWSER_TYPE))) {
                    launchSafariBrowser();
                } else {
                    launchChromeBrowser(isZap);
                }
            } catch (Exception e) {
                logger.error("Exception inside initializeWebDriver for Local {}", e.getMessage());
            }
        } else if (driverType.equals("remote") || driverType.equals("remloc")) {
            initializeRemoteWebDriver();
            PerfectoExecutionContext perfectoExecutionContext = new PerfectoExecutionContext.PerfectoExecutionContextBuilder()
                    .withProject(new Project("AutomationFramework", "1.0"))
                    .withContextTags("ps-auto-test")
                    .withWebDriver(remdriver)
                    .build();

            reportiumClient = new ReportiumClientFactory().createPerfectoReportiumClient(perfectoExecutionContext);
            if (reportiumClient == null) {
                throw new Exception("Reportium client not created!");
            }
            //        reportiumClient.testStart("JAVA WEB Testing", new TestContext("ps-auto-test2"));
        }

    }

    private static void initializeRemoteWebDriver() {
        Map<String, String> deviceSpecs = CloudConfig.getWebDeviceSpecs(scenarioCloudDevice);
        try {
            if (CHROME.equalsIgnoreCase(deviceSpecs.get(BROWSER_TYPE))) {
                launchRemoteChromeBrowser(deviceSpecs);
            } else if (FIREFOX.equalsIgnoreCase(deviceSpecs.get(BROWSER_TYPE))) {
                launchRemoteFirefoxBrowser(deviceSpecs);
            } else if ("edge".equalsIgnoreCase(deviceSpecs.get(BROWSER_TYPE))) {
                launchRemoteEdgeBrowser(deviceSpecs);
            } else if ("safari".equalsIgnoreCase(deviceSpecs.get(BROWSER_TYPE))) {
                launchRemoteSafariBrowser(deviceSpecs);
            } else {
                launchRemoteChromeBrowser(deviceSpecs);
            }
        } catch (Exception e) {
            logger.error("Exception inside initializeWebDriver for Remote {}", e.getMessage());
            Constants.remdriver.quit();
        }
    }

    public static void openBaseURL(String appKeyName, boolean isZap) throws InterruptedException {
        remdriver = Constants.remdriver;
        String webConfigPrefix = "/WEBConfig/BasicAuth.";
        String weburl = Utils.prepareDataString(appKeyName + "." + targetEnvName);
        String regex = "^(?:http(s)?:\\/\\/)?\\{username}:\\{password}@[\\w.-]+(?:\\.[\\w\\.-]+)+[\\w\\-\\._~:\\/?#\\[\\]@!\\$&'\\(\\)\\*\\+,;=.]+$";
        if (Pattern.matches(regex, weburl)) {
            String username = null;
            String password = null;
            if (isZap) {
                username = getConfigPropProperty(webConfigPrefix + appKeyName + ".userName");
                password = getConfigPropProperty(webConfigPrefix + appKeyName + ".password");
            } else {
                username = Utils.prepareDataString(webConfigPrefix + appKeyName + ".userName");
                password = Utils.prepareDataString(webConfigPrefix + appKeyName + ".password");
            }
            weburl = weburl.replace("{username}", username).replace("{password}", password);
        }
        if (Utils.isWebTest("web")) {
            remdriver.manage().window().maximize();
            if (!isZap) {
                logger.info("Maximizing the window");
            }
        }

        if (weburl.contains("\"")) {
            weburl = weburl.replaceFirst("\"", "");
        }

        long starTtime = System.currentTimeMillis();


//        reportiumClient.stepStart("Launching the URL");
        remdriver.get(weburl);
        logger.info("open the URL: {}", weburl);
//        reportiumClient.stepEnd();
        ignoreCertificate();
        CommonActionHelper.waitForPageLoad(remdriver);
        long endTime = System.currentTimeMillis();
        NumberFormat formatter = new DecimalFormat("#0.00000");
        logger.debug("URL page load time is: {} seconds", formatter.format((endTime - starTtime) / 1000d));
    }


    public static void ignoreCertificate() {
        try {
            if (getConfigPropProperty("targeted.web.browserType").contains("ie") && remdriver.getTitle().contains("Certificate")) {
                logger.debug("IE Browser Certificates issue found...");
                remdriver.get("javascript:document.getElementById('overridelink').click()");
                logger.debug("IE Browser Certificates are accepted..............");
                CommonActionHelper.waitForPageLoad(remdriver);
            }

            if (getConfigPropProperty("targeted.web.browserType").contains(CHROME) && remdriver.getTitle().contains("Privacy")) {
                logger.debug("IE Browser Certificates issue found...");
                remdriver.findElement(By.id("details-button")).click();
                remdriver.findElement(By.id("proceed-link")).click();
                logger.debug("IE Browser Certificates are accepted..............");
                CommonActionHelper.waitForPageLoad(remdriver);
            }

        } catch (Exception e) {
            logger.error("ignoreCertificate execption msg:: {}", e.getMessage());
            Thread.currentThread().interrupt();
        }
    }

    public static void launchChromeBrowser(boolean isZap) {
        if (!isZap) {
            logger.debug("Launching Chrome Browser on DevOps Agent machine....................");
        }
        WebDriverManager.chromedriver().gitHubToken(gitHubPAT).setup();

        ChromeOptions chromeOptions = new ChromeOptions();

        if (Utils.isWebTest("web")) {
            Map<String, Object> prefs = new HashMap<>();
            prefs.put("credentials_enable_service", false);
            prefs.put("profile.password_manager_enabled", false);
            LoggingPreferences logPrefs = new LoggingPreferences();
            logPrefs.enable(LogType.PERFORMANCE, Level.INFO);
            chromeOptions.setCapability("goog:loggingPrefs", logPrefs);
            chromeOptions.setExperimentalOption("excludeSwitches", new String[]{"enable-automation"});
            chromeOptions.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
            chromeOptions.setCapability(CapabilityType.SUPPORTS_JAVASCRIPT, true);
            chromeOptions.setCapability(CapabilityType.UNEXPECTED_ALERT_BEHAVIOUR, UnexpectedAlertBehaviour.IGNORE);
            chromeOptions.addArguments("--disable-infobars");
            chromeOptions.addArguments(DISABLE_NOTIFICATION);
            chromeOptions.addArguments("--disable-extensions");
            HashMap<String, Object> chromePrefs = new HashMap<>();
            chromePrefs.put("profile.default_content_settings.popups", 0);
            chromePrefs.put("download.default_directory", System.getProperty("user.dir"));
            chromeOptions.setExperimentalOption(PREFS, chromePrefs);
            chromeOptions.addArguments(USER_AGENT + customAgentName);
            chromeOptions.setExperimentalOption(PREFS, prefs);
        }

        if (Constants.isBrowserProxyEnabled) {
            logger.debug("&&&&&&&&&&&&&&&&&&& Browser Mob proxy added...............");
            chromeOptions.addArguments("-incognito");
            chromeOptions.setCapability(CapabilityType.PROXY, BrowserProxyHelper.getInstance().getSeleniumProxy());
        }

        if ("yes".equalsIgnoreCase(runBrowserHeadLess) && !Utils.isWebTest(RESPONSIVE)) {
            logger.info(RUN_BROWSER_HEADLESS + "Yes");
            chromeOptions.setHeadless(true);
//             chromeOptions.addArguments("--headless")
            chromeOptions.addArguments("--disable-gpu");// Temporarily needed if running on Windows.
            chromeOptions.addArguments("--disable-infobars");
            chromeOptions.addArguments(DISABLE_NOTIFICATION);
        }
        try {
            if (getConfigPropProperty("userData").equalsIgnoreCase("local")) {
                //to open chrome particular user dir instance
                chromeOptions.addArguments("--user-data-dir=C:\\chrome-dev-profile");
            }
        } catch (Exception e) {
            logger.warn("Profile ChromeBrowser - No such key in config");
        }

        remdriver = new ChromeDriver(chromeOptions);
        if (Utils.isWebTest(RESPONSIVE)) {
            remdriver.manage().window().setSize(new Dimension(393, 851));
        }

        Constants.remdriver = remdriver;
    }

    // Opening FF
    public static void launchFirefoxBrowser() {
        logger.debug("Launching Firefox Browser on DevOps Agent machine....................");
        WebDriverManager.firefoxdriver().gitHubToken(gitHubPAT).setup();

        FirefoxOptions ffOptions = new FirefoxOptions();
        ffOptions.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
        ffOptions.setCapability(CapabilityType.SUPPORTS_JAVASCRIPT, true);
        ffOptions.setCapability(CapabilityType.UNEXPECTED_ALERT_BEHAVIOUR, UnexpectedAlertBehaviour.DISMISS);
        ffOptions.setUnhandledPromptBehaviour(UnexpectedAlertBehaviour.DISMISS);
        ffOptions.setCapability(CapabilityType.UNHANDLED_PROMPT_BEHAVIOUR, "dismiss");
        ffOptions.setCapability("marionatte", false);
        ffOptions.addPreference("browser.helperApps.neverAsk.saveToDisk", "text/csv");
        ffOptions.addPreference("pdfjs.disabled", true);
//        ffOptions.addArguments("--disable-popup-blocking");
        ffOptions.addPreference("dom.disable_beforeunload", true);
        ffOptions.addArguments(USER_AGENT + customAgentName);
        if (Constants.isBrowserProxyEnabled) {
            logger.debug("&&&&&&&&&&&&&&&&&&& Browser Mob proxy added...............");
            ffOptions.setCapability(CapabilityType.PROXY, BrowserProxyHelper.getInstance().getSeleniumProxy());
        }
        if ("yes".equalsIgnoreCase(runBrowserHeadLess)) {

            logger.info(RUN_BROWSER_HEADLESS + "Yes");

            ffOptions.setHeadless(true);
            ffOptions.addArguments("--disable-gpu");
            ffOptions.addArguments("--disable-infobars");
            ffOptions.addArguments(DISABLE_NOTIFICATION);
            remdriver = new FirefoxDriver(ffOptions);
        } else {
            if (Utils.isWebTest(RESPONSIVE)) {
                ffOptions.addArguments("--width=393");
                ffOptions.addArguments("--height=851");
            }
            remdriver = new FirefoxDriver(ffOptions);
        }
        Constants.remdriver = remdriver;
    }

    // Opening Edge
    public static void launchEdgeBrowser() {
        logger.debug("Launching Edge Browser on DevOps Agent machine....................");
        WebDriverManager.edgedriver().gitHubToken(gitHubPAT).setup();
        remdriver = new EdgeDriver();
        if (Utils.isWebTest(RESPONSIVE)) {
            remdriver.manage().window().setSize(new Dimension(393, 851));
        }

        Constants.remdriver = remdriver;
    }

    public static void launchSafariBrowser() {
        logger.debug("Launching Safari Browser....................");
        WebDriverManager.safaridriver().gitHubToken(gitHubPAT).setup();

        SafariOptions options = new SafariOptions();
        options.setCapability("browserConnectionEnabled", true);
        options.setCapability("locationContextEnabled", true);
        options.setCapability("javascriptEnabled", true);
        remdriver = new SafariDriver();
        if (Utils.isWebTest(RESPONSIVE)) {
            remdriver.manage().window().setSize(new Dimension(393, 851));
        }

        Constants.remdriver = remdriver;
    }

    // Opening Google_Chrome
    public static void launchChromeBrowserGoogleAnalyticsTraffic(String driverfilePath) {
        logger.debug("Launching Chrome Browser....................");
        WebDriverManager.chromedriver().setup();
        LoggingPreferences logPrefs = new LoggingPreferences();
        logPrefs.enable(LogType.PERFORMANCE, Level.INFO);

        ChromeOptions chromeOptions = new ChromeOptions();
        chromeOptions.setCapability("goog:loggingPrefs", logPrefs);
        chromeOptions.addExtensions(new File(driverfilePath));

        chromeOptions.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
        chromeOptions.setCapability(CapabilityType.SUPPORTS_JAVASCRIPT, true);
        chromeOptions.setCapability(CapabilityType.UNEXPECTED_ALERT_BEHAVIOUR, UnexpectedAlertBehaviour.IGNORE);
        chromeOptions.addArguments("--disable-infobars");
        chromeOptions.addArguments(DISABLE_NOTIFICATION);
        chromeOptions.addArguments("--enable-automation");
        chromeOptions.addArguments(USER_AGENT + customAgentName);
//			chromeOptions.addArguments("--disable-extensions");
        HashMap<String, Object> chromePrefs = new HashMap<>();
        chromePrefs.put("profile.default_content_settings.popups", 0);
        chromePrefs.put("download.default_directory", System.getProperty("user.dir"));

        chromeOptions.setExperimentalOption(PREFS, chromePrefs);

//			if (Constants.isBrowserProxyEnabled)
//			{
//				logger.debug("&&&&&&&&&&&&&&&&&&& Browser Mob proxy added...............");
////				chromeOptions.addArguments("-incognito");
//				chromeOptions.setCapability(CapabilityType.PROXY, BrowserProxyHelper.getInstance().getSeleniumProxy());
//			}

        if ("yes".equalsIgnoreCase(runBrowserHeadLess)) {
            logger.info(RUN_BROWSER_HEADLESS + "Yes");
            chromeOptions.setHeadless(true);
            // chromeOptions.addArguments("--headless");
            chromeOptions.addArguments("--disable-gpu");// Temporarily needed if running on Windows.
            chromeOptions.addArguments("--disable-infobars");
            chromeOptions.addArguments(DISABLE_NOTIFICATION);
            // options.addArguments("--start-maximized");
            // options.addArguments("--start-fullscreen");
        }
        remdriver = new ChromeDriver(chromeOptions);
        Constants.remdriver = remdriver;
    }

    private static DesiredCapabilities setThisCapabilities(Map<String, String> deviceSpecs) {


        DesiredCapabilities capabilities = new DesiredCapabilities("", "", Platform.ANY);

        if (deviceSpecs.get(BROWSER_TYPE).equalsIgnoreCase(CHROME)) {
            ChromeOptions options = new ChromeOptions();
            options.addArguments("--incognito");
            capabilities.setCapability(ChromeOptions.CAPABILITY, options);
        } else if (deviceSpecs.get(BROWSER_TYPE).equalsIgnoreCase(FIREFOX)) {
            FirefoxProfile firefoxProfile = new FirefoxProfile();
            firefoxProfile.setPreference("browser.private.browsing.autostart", true);
            capabilities.setCapability(FirefoxDriver.PROFILE, firefoxProfile);
        }

        capabilities.setCapability(PLATFORM_NAME, deviceSpecs.get(PLATFORM_NAME));
        capabilities.setCapability("platformVersion", deviceSpecs.get("platformVersion"));
        capabilities.setCapability("browserName", deviceSpecs.get(BROWSER_TYPE));
        capabilities.setCapability("browserVersion", deviceSpecs.get("browserVersion"));
        capabilities.setCapability("resolution", deviceSpecs.get("resolution"));
        capabilities.setCapability("securityToken", cloudSecurityToken);
        capabilities.setCapability("waitForAvailableLicense", true);

        if (deviceSpecs.get(BROWSER_TYPE).equalsIgnoreCase("edge")) {
            EdgeOptions edgeOptions = new EdgeOptions();
            edgeOptions.merge(capabilities);
            edgeOptions.setCapability("ms:inPrivate", true);
        }

        return capabilities;
    }

    public static void launchRemoteChromeBrowser(Map<String, String> deviceSpecs) {
        logger.info("Launching Remote Chrome Browser on Perfecto....................");
        launchRemoteBrowserDriver(deviceSpecs);
    }

    public static void launchRemoteFirefoxBrowser(Map<String, String> deviceSpecs) {
        logger.info("Launching Remote Firefox Browser on Perfecto....................");
        launchRemoteBrowserDriver(deviceSpecs);
    }

    public static void launchRemoteEdgeBrowser(Map<String, String> deviceSpecs) {
        logger.info("Launching Remote Edge Browser on Perfecto....................");
        launchRemoteBrowserDriver(deviceSpecs);
    }

    public static void launchRemoteSafariBrowser(Map<String, String> deviceSpecs) {
        logger.info("Launching Remote Safari Browser on Perfecto....................");
        launchRemoteBrowserDriver(deviceSpecs);
    }

    private static void launchRemoteBrowserDriver(Map<String, String> deviceSpecs) {
        String perfectoUrl = HTTPS + cloudLabName + PERFECTO_MOBILE_ENDPOINT;
        DesiredCapabilities capabilities = setThisCapabilities(deviceSpecs);

        try {
            Constants.remdriver = new RemoteWebDriver(new URL(perfectoUrl), capabilities);
            remdriver = Constants.remdriver;
            logger.info("Successfully got Perfecto driver reference");
        } catch (SessionNotCreatedException | MalformedURLException e) {
            logger.error(MAX_LICENCE_REACHED, deviceSpecs.get(PLATFORM_NAME), deviceSpecs.get(BROWSER_TYPE));
            logger.info("Falling back to Browser on DevOps Agent machine");
            driverType = "remloc";
            switch (deviceSpecs.get(BROWSER_TYPE)) {
                case CHROME:
                    launchChromeBrowser(false);
                    break;
                case FIREFOX:
                    launchFirefoxBrowser();
                    break;
                case "edge":
                    launchEdgeBrowser();
                    break;
                default:
                    launchChromeBrowser(false);
            }
        }
        if (Utils.isWebTest(RESPONSIVE)) {
            remdriver.manage().window().setSize(new Dimension(393, 851));
        }
    }

    public static void quitDriver() {
        logger.debug("inside teardown()....");
        remdriver = Constants.remdriver;
        if (remdriver != null) {
            remdriver.quit();
            logger.debug("driver quit success.");
        }
    }

    public static WebDriver getDriver() {
        return remdriver;
    }

    public static String getPageSource() {
        return remdriver.getPageSource();
    }

    public static void switchToTab(String tabName) {
        int tabId = 9;

        remdriver = Constants.remdriver;
        if (tabName.equalsIgnoreCase("main")) {
            tabId = 0;
        } else if (tabName.equalsIgnoreCase("second")) {
            tabId = 1;
        }
        ArrayList<String> tabs2 = new ArrayList<>(remdriver.getWindowHandles());
        remdriver.switchTo().window(tabs2.get(tabId));
    }

    public static void closeTabBrowser() {
        remdriver = Constants.remdriver;
        remdriver.close();
    }


}