package com.qe.framework.web.helpers;

import com.qe.framework.common.CommonActionHelper;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.net.ssl.HttpsURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class QEBrokenURLsLinks extends CommonActionHelper {
    private static final Logger logger = LoggerFactory.getLogger(QEBrokenURLsLinks.class);

    Map<String, String> validLinkUrlMap = new HashMap<>();
    Map<String, String> brokenLinkUrlMap = new HashMap<>();
    private String errorText = "";

    public boolean getBrokenLinks() {
        boolean flag = false;
        try {
            errorText = "";
            waitForPageLoad(getDriver());
            flag = checkBrokenAllLinks();
        } catch (Exception e) {
            logger.error("getBrokenLinks exception msg:: {}", e.getMessage());
            Thread.currentThread().interrupt();
        } finally {
            quitDriver();
            addingFinalValidationLogs(flag);
        }
        return flag;
    }

    private void addingFinalValidationLogs(boolean flag) {
        logger.debug("FINAL VALIDATION LINK URL TEST STATUS:: {}", flag);
        logger.debug("Total Link Url Tested:: {} ", (validLinkUrlMap.size() + brokenLinkUrlMap.size()));
        logger.debug("===============VALID LINK URLs ========================== COUNT: {}", validLinkUrlMap.size());
        printResult((HashMap<String, String>) validLinkUrlMap);
        logger.debug("===============BROKEN LINK URLs ========================== COUNT:{}", brokenLinkUrlMap.size());
        addBrokenUrlsToErrorTxt((HashMap<String, String>) brokenLinkUrlMap);
        logger.debug(errorText);
    }

    public boolean checkBrokenAllLinks() {
        boolean flag;
        String urlXpath = "a";
        List<WebElement> linkList = getElementLinksList(urlXpath);

        flag = checkBrokenLinksTryCatch(linkList, "href");
        return flag;
    }

    public List<WebElement> getElementLinksList(String xpath) {
        List<WebElement> linkList = new ArrayList<>();
        try {
            linkList = getDriver().findElements(By.tagName(xpath));
        } catch (Exception e) {
            logger.error("getElementLinksList  Exception MSG::{}", e.getMessage());
        }
        return linkList;
    }

    public int testLinkUrl(String httpsUrl) {
        int statusCode = 404;
        URL url;
        try {

            url = new URL(httpsUrl);
            HttpsURLConnection con = (HttpsURLConnection) url.openConnection();
            con.setRequestProperty("Cookie", "debug=");
            con.setDoInput(true);
            con.setUseCaches(false);
            con.setInstanceFollowRedirects(true);
            int readTimeout = 30;
            con.setReadTimeout(readTimeout * 1000);
            con.setConnectTimeout(readTimeout * 1000);
            statusCode = con.getResponseCode();

        } catch (MalformedURLException e) {
            logger.error("testLinkUrl MalformedURL Exception MSG::{}", e.getMessage());
        } catch (Exception e) {
            logger.error("testLinkUrl Exception MSG::{}", e.getMessage());
        }
        return statusCode;
    }

    private void printResult(HashMap<String, String> map) {
        for (Map.Entry<String, String> entry : map.entrySet()) {
            logger.debug("URL = {} ,  :=: {}", entry.getKey(), entry.getValue());
        }

    }

    private void addBrokenUrlsToErrorTxt(HashMap<String, String> map) {
        StringBuilder brokenUrls = new StringBuilder();
        for (Map.Entry<String, String> entry : map.entrySet()) {
            brokenUrls.append("URL = ").append(entry.getKey()).append(" :=: ").append(entry.getValue()).append("\n");
        }
        brokenUrls.append("Summary:- Total URL Count:").append((brokenLinkUrlMap.size() + validLinkUrlMap.size()))
                .append(" Valid URL Count:").append(validLinkUrlMap.size()).append("  Broken URL Count:").append(brokenLinkUrlMap.size());
        errorText = brokenUrls.toString();
    }


    public boolean getBrokenImageLinks() {
        boolean flag = false;
        try {
            waitForPageLoad(getDriver());
            flag = checkBrokenAllImageLinks();
        } catch (Exception e) {
            logger.error("getBrokenLinks exception msg::{}", e.getMessage());
            Thread.currentThread().interrupt();
        } finally {
            quitDriver();
            addingFinalValidationLogs(flag);
        }
        return flag;
    }

    public boolean checkBrokenAllImageLinks() {
        boolean flag;
        String imageXpath = "img";
        List<WebElement> linkList = getElementLinksList(imageXpath);


        flag = checkBrokenLinksTryCatch(linkList, "src");

        return flag;
    }

    private boolean checkBrokenLinksTryCatch(List<WebElement> linkList, String attributeType) {
        String linkUrl;
        int respCode;
        boolean flag = true;
        try {
            for (WebElement element : linkList) {
                linkUrl = element.getAttribute(attributeType);
                if (linkUrl == null || linkUrl.isEmpty()) {
                    logger.info("URL is either not configured for anchor tag or it is empty");
                    continue;
                }
                respCode = testLinkUrl(linkUrl);
                if (respCode >= 400) {
                    flag = false;
                    errorText = "is a broken link";
                    brokenLinkUrlMap.put(linkUrl, errorText);

                } else {
                    errorText = "is a valid link";
                    validLinkUrlMap.put(linkUrl, errorText);
                }
                logger.info("{} :: RespCode:: {}   Status:: {}", linkUrl, respCode, errorText);
            }

        } catch (Exception e) {
            logger.error("checkAllLinks exception msg:: {}", e.getMessage());
        }
        return flag;
    }

    public String getErrorText() {
        return this.errorText;
    }
}
