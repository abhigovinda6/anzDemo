package com.qe.framework.common;

import java.util.HashMap;
import java.util.Map;

public class ContextMap {

    private final Map<String, String> context;

    public ContextMap() {
        context = new HashMap<>();
        azureVault=new HashMap<>();
    }
     private final Map<String, String> azureVault;

    public Map<String, String> getContext() {
        return context;
    }

    public void put(String key, String value) {
        context.put(key, value);
    }

    public void putAll(Map<String, String> anotherMap) {
        context.putAll(anotherMap);
    }

    public String get(String key) {
        return context.get(key);
    }

    public void remove(String key) {
        context.remove(key);
    }

    public boolean contains(String key) {
        return context.containsKey(key);
    }

    public void clear() {
        context.clear();
    }

    public String getFromVault(String key) {
        return azureVault.get(key);
    }

    public void putInVault(String key, String value) {
        azureVault.put(key, value);

    }

}
