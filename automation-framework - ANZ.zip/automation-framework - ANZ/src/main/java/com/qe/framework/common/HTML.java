package com.qe.framework.common;

public class HTML {

    public static final String HTML_START = "<html><head><style>\n" +
            "body            \n" +
            "{\n" +
            "    margin:auto;\n" +
            "    width:1024px;\n" +
            "    padding:10px;\n" +
            "    background-color:#ebebeb;\n" +
            "    font-size:14px;\n" +
            "    font-family:sans-serif;\n" +
            "}\n" +
            ".styled-table {\n" +
            "    border-collapse: collapse;\n" +
            "    margin: 25px 0;\n" +
            "    font-size: 0.9em;\n" +
            "    font-family: sans-serif;\n" +
            "    min-width: 400px;\n" +
            "    box-shadow: 0 0 20px rgba(0, 0, 0, 0.15);\n" +
            "}\n" +
            ".styled-table thead tr {\n" +
            "    background-color: #009879;\n" +
            "    color: #ffffff;\n" +
            "    text-align: left;\n" +
            "}\n" +
            ".styled-table th,\n" +
            ".styled-table td {\n" +
            "    padding: 12px 15px;\n" +
            "}\n" +
            ".styled-table tbody tr {\n" +
            "    border-bottom: 1px solid #dddddd;\n" +
            "}\n" +
            "\n" +
            ".styled-table tbody tr:nth-of-type(even) {\n" +
            "    background-color: #f3f3f3;\n" +
            "}\n" +
            "\n" +
            ".styled-table tbody tr:last-of-type {\n" +
            "    border-bottom: 2px solid #009879;\n" +
            "}\n" +
            ".styled-table tbody tr.active-row {\n" +
            "    font-weight: bold;\n" +
            "    color: #009879;\n" +
            "}\n" +
            "li {\n" +
            "  border-left: 5px solid red;\n" +
            "  background-color: #f1f1f1;\n" +
            "  list-style-type: none;\n" +
            "  padding: 10px 20px;\n" +
            "  font-weight: bold;" +
            "}" +
            ".error {\n" +
            "font-weight: bold;\n" +
            "    color: red;\n" +
            "}</style>\n" +
            "</head><body>";
    public static final String TABLE = "<table class=\"styled-table\">";
    public static final String TABLE_CLOSE = "</table><hr/>";
    public static final String TH = "<th>";
    public static final String TH_CLOSE = "</th>";
    public static final String TR = "<tr>";
    public static final String TR_CLOSE = "</tr>";
    public static final String TD = "<td>";
    public static final String TD_CLOSE = "</td>";
    public static final String UL = "<ul>";
    public static final String UL_CLOSE = "</ul>";
    public static final String LI = "<li>";
    public static final String LI_CLOSE = "</li>";
    public static final String HR = "<hr/>";
    public static final String BR = "<br/>";
    public static final String H3 = "<h3>";
    public static final String H3_CLOSE = "</h3>";
    public static final String ERROR = "<span class=\"error\">";
    public static final String DIV_CLOSE = "</div>";
    public static final String ERROR_CLOSE = "</span>";
    public static final String HTML_CLOSE = "</body><script>\n" +
            "function myFunction(whichBlock) {\n" +
            "  var x = document.getElementById(whichBlock);\n" +
            "  if (x.style.display === \"none\") {\n" +
            "    x.style.display = \"block\";\n" +
            "  } else {\n" +
            "    x.style.display = \"none\";\n" +
            "  }\n" +
            "}\n" +
            "</script></html>";

}
