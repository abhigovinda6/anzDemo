package com.qe.framework.db.helpers;

import com.jayway.jsonpath.JsonPath;
import com.qe.framework.common.*;
import cucumber.api.DataTable;
import org.apache.commons.lang3.StringUtils;
import org.junit.Assert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.*;
import java.util.*;

import static com.qe.framework.common.Constants.*;
import static com.qe.framework.common.PropertiesHelper.contextMap;
import static com.qe.framework.common.Utils.compareMap;

public class SqlDatabaseManager {
    private static final Logger logger = LoggerFactory.getLogger(SqlDatabaseManager.class);
    private static final String SEPARATELY = "separately";
    private static final String TABLE_NAME = "$tableName";
    private static final String ADD_SQL_QUERY = "add sql queries";
    private static final String DUPLICATE = "Duplicate";
    private static final String BATCH = "batch";
    private static final String STATS = "stats";
    private static final String SUCCESSFUL_INSERTION = "successful_insertions_";
    private static final String FAILED_INSERTION = "failed_insertions_";
    private static final String COLUMN_HEADERS = "\\$\\{keys\\}";
    private static final String COLUMN_VALUES = "\\$\\{values\\}";
    public static Connection connection;
    public static Statement statements;
    public static PropertiesHelper loadProps = PropertiesHelper.getInstance();
    CommonActionHelper commonActionHelper = new CommonActionHelper();
    String output = null;
    int fileRecordsCount;
    int dbRecordCount;
    int dbRecordCountAfterUpdate;
    int successRecords;
    int rejectedRecords;
    int queryIssueRecords;
    ResultSet rs;
    ResultSet primaryKeys;
    ResultSetMetaData rsmd;
    List<String> dbList = new ArrayList<>();
    List<List<String>> attributes;
    private BufferedWriter bufferedWriter;

    public SqlDatabaseManager(String dBurl) {
//        Class.forName("com.mysql.cj.jdbc.Driver");
        try {
            connection = DriverManager.getConnection(dBurl, Utils.prepareDataString("/SQLConfig/dbUserName"),
                    Utils.prepareDataString("/SQLConfig/dbPassword"));
            statements = connection.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            logger.info("Connection is established successfully with DB {}", dBurl);

        } catch (SQLException exception) {
            SQLException throwables = exception;
            logger.info("\n*** SQLException caught ***\n");
            while (throwables != null) { // tell us the problem
                logger.info("SQLState:    {}", throwables.getSQLState());
                logger.info("Message:     {}", throwables.getMessage());
                logger.info("Error code:  {}", throwables.getErrorCode());
                throwables = throwables.getNextException();
                logger.info("Connection Failed");
            }
        } catch (Exception e) {
            logger.error(e.getMessage());
        }

    }

    public static Statement getStatement() {
        return statements;
    }

    public static void setStatement(Statement statement) {
        SqlDatabaseManager.statements = statement;
    }

    public static String getBaseDbUrl(String dbUrl) {
        return PropertiesHelper.getConfigPropProperty(dbUrl);
    }

    public static Connection getConnection() {
        return connection;
    }

    public static void setConnection(Connection connection) {
        SqlDatabaseManager.connection = connection;
    }
    ///////////////-------------DB Actions----------------------///////////

    // SqlDatabaseManager databaseManager = new
    // SqlDatabaseManager(webPropHelper.getConfigPropProperty("SqlDbUrl"));

    public static String getDatabaseFailedStep(String e) {
        throw new AssertionError("Exception in Database query execution or getting result set. Failed " + "- " + e);
    }

    public String getDbOneRecords() {
        try {
            while (rs.next()) {
                output = rs.getString(1);
                logger.debug("getDBOnerecords_ resultSet is " + output);

                // assertEquals(actualvalue, rs.getString(1));
            }
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            logger.error(e.getMessage());
        }
        return output;

    }

    public List<String> getDbListRecordsOneColumn() {
        try {
            while (rs.next()) {
                output = rs.getString(1).trim();
                // String trim = output.trim();
                logger.debug("getDbListRecordOneColumn_ resultSet is : {}", output);
                dbList.add(output);
                // assertEquals(actualvalue, rs.getString(1));
            }

        } catch (SQLException e) {
            // TODO Auto-generated catch block
            logger.error(e.getMessage());
        }
        return dbList;
    }

    public void executeDatabaseQuery(String query) throws SQLException {
        logger.info("Executing the database query...");
        if (query.startsWith("drop table")) {
            SqlDatabaseManager.getStatement().executeQuery(query);
        } else {
            try {
                rs = SqlDatabaseManager.getStatement().executeQuery(query);
                logger.info("Executed the database query");
                dbRecordCount = getRowsCount();
            } catch (SQLException e) {
                commonActionHelper.appendTextInGlobalSummary(HTML.LI + HTML.ERROR + e.getMessage() + HTML.LI_CLOSE);
                getDatabaseFailedStep(e.getMessage());
            }
        }
    }

    public void closeDatabaseConnection() throws SQLException {
        logger.info("Closing the database connection...");
        connection.close();
        logger.info("Database connection closed...");
    }

    public int getColumnsCount() throws SQLException {
        rsmd = rs.getMetaData();
        int columnCount = rsmd.getColumnCount();
        logger.info("Column count is : {}", columnCount);
        return columnCount;
    }

    public int getRowsCount() throws SQLException {
        // moving cursor to the last row to get the row count.
        rs.last();
        int rowCount = rs.getRow();
        // moving cursor back to the first row to perform further operations.
        rs.first();
        logger.info("Row count is :{}", rowCount);
        return rowCount;
    }

    public void storeResultSet() throws SQLException {
        rsmd = rs.getMetaData();
        int rowCount = getRowsCount();
        if (rowCount > 5) {
            throw new AssertionError("Record set is more than 5. Please optimize your query to get maximum 5 records");
        }
        int columnCount = getColumnsCount();
        int row = 1;
        if (rowCount > 0) {
            do {
                for (int i = 1; i <= columnCount; i++) {
                    contextMap.getContext().put("rs_" + rsmd.getColumnName(i) + row + i, rs.getObject(i).toString());
                }
                row++;
            } while (rs.next());
        } else {
            logger.info("There is no record found for this DB query...");
        }
        contextMap.getContext().put("rs_totalRecords", String.valueOf(rowCount));
        contextMap.getContext().put("rs_totalColumns", String.valueOf(columnCount));
        logger.info("Context Map data : " + contextMap.getContext());
    }

    public String queryFilteredValue(String query, DataTable attributesTable) {
        attributes = attributesTable.raw();
        for (int j = 1; j < attributes.size(); j++) {
            if (attributes.get(j).get(0).contains("$")) {
                query = query.replaceAll("\\{", "")
                        .replaceAll("\\}", "")
                        .replace(attributes.get(j).get(0), attributes.get(j).get(1));
            } else {
                logger.info("No column update require");
            }
        }
        return query;
    }

    public void verifyRecordCount() throws SQLException {
        logger.info("Verifying records count...");
        int expectedRecordsCount = dbRecordCount + fileRecordsCount;
        dbRecordCountAfterUpdate = getRowsCount();
        Assert.assertEquals(dbRecordCountAfterUpdate, expectedRecordsCount);
        logger.info("Verified!!! DB record count is correct : {}", expectedRecordsCount);
    }

    public void loadCSVAndExecuteQuery(File csv, String action, String tableName, String ruleJson) throws SQLException {
        loadDataInDb(csv, action, tableName, ruleJson, null);
    }

    public void loadCSVAndExecuteQueryMultipleTable(File csv, String action, List<String> data, String ruleJson) throws SQLException {
        for (int list = 0; list < (data.size()); list += 2) {
            String tableName = data.get(list);
            String columnKey = data.get(list + 1);
            String[] columnsList = columnKey.split(",");
            loadDataInDb(csv, action, tableName, ruleJson, columnsList);
        }
    }

    public void loadDataInDb(File csv, String action, String tableName, String ruleJson, String[] columnsList) throws SQLException {
        commonActionHelper.appendTextInGlobalSummary(HTML.TABLE + HTML.TR + HTML.TH + "Adding csv file: " + csv.getName() + " into table: " + tableName + HTML.TH_CLOSE + HTML.TR_CLOSE);
        CSVHelper csvHelper = new CSVHelper();
        String sql = "INSERT  INTO " + tableName + " (${keys}) VALUES (${values})";
        List<String> columnName = new ArrayList<>();
        List<String> columnValue = new ArrayList<>();
        List<String> queries = new ArrayList<>();
        List<List<String>> batchColumnValue = new ArrayList<>();
        Map<String, Object> values = new HashMap<>();
        List<String> successfulQuery = new ArrayList<>();
        List<String> failureQuery = new ArrayList<>();
        int count = 0;
        int successQueryCounter = 0;
        int incorrectQueryCounter = 0;
        int duplicateRecordCounter = 0;

        try {
            if (action.contains(BATCH) || action.contains(SEPARATELY)) {
                values = csvHelper.filterBatchSQLMapping(ruleJson, csv);

                for (Map.Entry<String, Object> node : values.entrySet()) {
                    if (Objects.isNull(columnsList)) {
                        columnName.add(String.valueOf(node.getKey()));
                        batchColumnValue.add((List<String>) node.getValue());
                    } else {
                        int size = Utils.ifAnyItemsMatchInTargetList(String.valueOf(node.getKey()), Arrays.asList(columnsList));
                        if (size > 0) {
                            columnName.add(String.valueOf(node.getKey()));
                            batchColumnValue.add((List<String>) node.getValue());
                        }
                    }
                }
            }
        } catch (NullPointerException ex) {
            values = csvHelper.filterSQLMapping(ruleJson, csv);

            for (Map.Entry<String, Object> node : values.entrySet()) {
                columnName.add(String.valueOf(node.getKey()));
                columnValue.add(String.valueOf(node.getValue()));
            }
        }

        String questionmarks = StringUtils.repeat("?,", columnName.size());
        questionmarks = (String) questionmarks.subSequence(0, questionmarks
                .length() - 1);

        String query = sql.replaceFirst(COLUMN_HEADERS, StringUtils.join(columnName, ","));
        query = query.replaceFirst(COLUMN_VALUES, questionmarks);

        connection.setAutoCommit(false);
        PreparedStatement statement = connection.prepareStatement(query);
        try {
            if (action.contains(BATCH) || action.contains(SEPARATELY)) {
                for (int i = 0; i < batchColumnValue.get(0).size(); i++) {
                    for (List<String> s : batchColumnValue) {
                        columnValue.add(s.get(i));
                    }
                    int index = 1;
                    for (String string : columnValue) {
                        statement.setString(index++, string);
                    }
                    if (action.contains(SEPARATELY)) {
                        try {
                            statement.executeUpdate();
                            successfulQuery.add(statement.toString());
                            successQueryCounter++;
                        } catch (Exception e) {
                            duplicateRecordCounter++;
                            failureQuery.add(statement.toString());
                            logger.info("Issue in executing the sql statement for loadCSVAndExecuteQuery: {} . \nError : {}", statement, e.getMessage());
                        }
                    } else if (action.contains(BATCH)) {
                        count++;
                        logger.info(" Insert statement : {}", statement);
                        statement.addBatch();
                    }
                    queries.add(statement.toString());
                    columnValue.clear();
                }
                fileRecordsCount = count;
                if (action.contains(BATCH)) {
                    try {
                        statement.executeBatch();
                        successfulQuery = queries;
                        successQueryCounter = queries.size();
                        logger.info("Successfully executed all insert statements in the batch!!!");
                    } catch (Exception e) {
                        failureQuery = queries;
                        duplicateRecordCounter = queries.size();
                        logger.info("Issue in executing the sql statement loadCSVAndExecuteQuery method: {} . \nError : {}", statement, e.getMessage());
                    }
                }
                connection.commit();
            }
        } catch (NullPointerException ex) {

            int index = 1;
            for (String string : columnValue) {
                statement.setString(index++, string);
            }
            try {
                statement.executeUpdate();
                connection.commit();
                successfulQuery = queries;
                successQueryCounter++;
                logger.info("Successfully executed insert statement : {}", statement);
                queries.add(statement.toString());
            } catch (SQLException ey) {
                failureQuery = queries;
                if (ey.getMessage().contains(DUPLICATE)) {
                    duplicateRecordCounter++;
                } else {
                    incorrectQueryCounter++;
                }
                logger.info("Issue in executing the sql statement: {} . \nError : {}", statement, ex.getMessage());
                queries.add(statement.toString());
            }
        }
        successRecords = successQueryCounter;
        rejectedRecords = duplicateRecordCounter;
        queryIssueRecords = incorrectQueryCounter;
        fileRecordsCount = successQueryCounter + duplicateRecordCounter + incorrectQueryCounter;
        writeQueryInfo(csv.getName(), queries, ADD_SQL_QUERY);
        writeQueryInfo(csv.getName(), queries, STATS);
        writeQueryInfoPassFail(csv.getName(), columnName, successfulQuery, failureQuery);
    }

    private void writeQueryInfoPassFail(String name, List<String> columnName, List<String> successfulQuery, List<String> failureQuery) {
        if (!successfulQuery.isEmpty()) {
            writeQueryInfo(name, columnName, successfulQuery, SUCCESSFUL_INSERTION);
        }
        if (!failureQuery.isEmpty()) {
            writeQueryInfo(name, columnName, failureQuery, FAILED_INSERTION);
        }
    }

    public void loadXMLAndExecuteBatchQuery(File file, String action, String tableName, String ruleJson) throws IOException, SQLException {
        loadXMLDataInDb(file, action, tableName, ruleJson, null);
    }

    public void loadXMLDataInDb(File file, String action, String tableName, String ruleJson, String[] columnsList) throws IOException, SQLException {
        commonActionHelper.appendTextInGlobalSummary(HTML.TABLE + HTML.TR + HTML.TH + "Adding xml file: " + file.getName() + " into table: " + tableName + HTML.TH_CLOSE + HTML.TR_CLOSE);
        int count = 0;
        String sql = "INSERT INTO  " + tableName + " (${keys}) VALUES(${values})";
        List<String> columnName = new ArrayList<>();
        List<String> columnValue = new ArrayList<>();
        List<String> queries = new ArrayList<>();
        List<String> successfulQuery = new ArrayList<>();
        List<String> failureQuery = new ArrayList<>();
        int successQueryCounter = 0;
        int incorrectQueryCounter = 0;
        int duplicateRecordCounter = 0;
        String xmlJson = null;
        List<String[]> batchColumnValue = new ArrayList<>();
        String xmlFile = file.getName();
        XMLHelper xmlHelper = new XMLHelper();
        xmlJson = xmlHelper.parseXMLtoJSON(file);
        Map<String, Object> values;
        try {
            if (action.contains(BATCH) || action.contains(SEPARATELY)) {
                values = xmlHelper.filterBatchSQLMapping(ruleJson, xmlJson, action);
                for (Map.Entry<String, Object> node : values.entrySet()) {
                    if (Objects.isNull(columnsList)) {
                        columnName.add(String.valueOf(node.getKey()));
                        batchColumnValue.add((String[]) node.getValue());
                    } else {
                        int size = Utils.ifAnyItemsMatchInTargetList(String.valueOf(node.getKey()), Arrays.asList(columnsList));
                        if (size > 0) {
                            columnName.add(String.valueOf(node.getKey()));
                            batchColumnValue.add((String[]) node.getValue());
                        }
                    }
                }
            }
        } catch (NullPointerException ex) {
            values = xmlHelper.filterSQLMapping(ruleJson, xmlJson);
            values.forEach((key, value) -> {
                columnName.add(String.valueOf(key));
                columnValue.add(String.valueOf(value));
            });
        }

        String questionmarks = StringUtils.repeat("?,", columnName.size());
        questionmarks = (String) questionmarks.subSequence(0, questionmarks
                .length() - 1);

        String query = sql.replaceFirst(COLUMN_HEADERS, StringUtils.join(columnName, ","));
        query = query.replaceFirst(COLUMN_VALUES, questionmarks);

        connection.setAutoCommit(false);
        PreparedStatement statement = connection.prepareStatement(query);
        try {
            if (action.contains(BATCH) || action.contains(SEPARATELY)) {
                for (int i = 0; i < batchColumnValue.get(0).length; i++) {
                    for (String[] s : batchColumnValue) {
                        columnValue.add(s[i]);
                    }
                    int index = 1;
                    for (String string : columnValue) {
                        statement.setString(index++, string);
                    }
                    if (action.contains(SEPARATELY)) {
                        try {
                            statement.executeUpdate();
                            successfulQuery.add(statement.toString());
                            successQueryCounter++;
                        } catch (Exception e) {
                            failureQuery.add(statement.toString());
                            duplicateRecordCounter++;
                            logger.info(" Issue in executing the sql statement : {} . \nError : {}", statement, e.getMessage());
                        }
                    } else if (action.contains(BATCH)) {
                        count++;
                        logger.info("Insert statement: {}", statement);
                        statement.addBatch();
                    }
                    queries.add(statement.toString());
                    columnValue.clear();
                }
                fileRecordsCount = count;
                if (action.contains(BATCH)) {
                    try {
                        statement.executeBatch();
                        successfulQuery = queries;
                        successQueryCounter = queries.size();
                        logger.info("Successfully executed all the insert statements in the batch!!!");
                    } catch (Exception e) {
                        failureQuery = queries;
                        duplicateRecordCounter = queries.size();
                        logger.info("Issue in executing the sql statement loadXMLAndExecuteBatchQuery: {} . \nError : {}", statement, e.getMessage());
                    }
                }
                connection.commit();
            }
        } catch (NullPointerException ex) {
            int index = 1;
            for (String string : columnValue) {
                statement.setString(index++, string);
            }
            try {
                statement.executeUpdate();
                connection.commit();
                successQueryCounter++;
                logger.info("Successfully executed insert statement : {}", statement);
                queries.add(statement.toString());
                successfulQuery = queries;
            } catch (SQLException ey) {
                if (ey.getMessage().contains(DUPLICATE)) {
                    duplicateRecordCounter++;
                } else {
                    incorrectQueryCounter++;
                }
                logger.info("Issue in executing the sql statement: {} . \nError : {}", statement, ex.getMessage());
                queries.add(statement.toString());
                failureQuery = queries;
            }
        }
        successRecords = successQueryCounter;
        rejectedRecords = duplicateRecordCounter;
        queryIssueRecords = incorrectQueryCounter;
        fileRecordsCount = successQueryCounter + duplicateRecordCounter + incorrectQueryCounter;
        writeQueryInfo(xmlFile, queries, ADD_SQL_QUERY);
        writeQueryInfo(xmlFile, queries, STATS);
        if (!successfulQuery.isEmpty()) {
            writeQueryInfo(xmlFile, columnName, successfulQuery, SUCCESSFUL_INSERTION);
        }
        if (!failureQuery.isEmpty()) {
            writeQueryInfo(xmlFile, columnName, failureQuery, FAILED_INSERTION);
        }
    }

    public void loadXMLAndExecuteBatchQueryMultipleTable(File file, String action, List<String> data, String ruleJson) throws IOException, SQLException {
        for (int list = 0; list < (data.size()); list += 2) {
            String tableName = data.get(list);
            String columnKey = data.get(list + 1);
            String[] columnsList = columnKey.split(",");
            loadXMLDataInDb(file, action, tableName, ruleJson, columnsList);
        }
    }

    public void writeQueryInfo(String fileName, List<String> columnNames, List<String> query, String status) {
        String file = fileName.substring(0, fileName.indexOf("."));
        String path = null;
        if ((rejectedRecords + queryIssueRecords) > 0) {
            path = Constants.FEEDFILEEXECUTIONFAILUREFOLDERPATH + file + File.separator;
        } else {
            path = Constants.FEEDFILEEXECUTIONSUCCESSFOLDERPATH + file + File.separator;
        }
        createFeedFileExecutionResultDirectory(path);
        path = path + status + file + ".csv";

        StringBuilder line = new StringBuilder();
        File fileObject = new File(path);
        try {
            if (!fileObject.exists()) {
                fileObject.createNewFile();
            }
            FileWriter writer = new FileWriter(fileObject);
            StringBuilder stringBuilder = new StringBuilder();
            line = new StringBuilder();
            for (String s : columnNames) {
                line = new StringBuilder(line + s + ",");
            }
            line = new StringBuilder(line.substring(0, line.lastIndexOf(",")));
            stringBuilder.append(line).append("\n");
            line = new StringBuilder();
            for (String s : query) {
                stringBuilder.append(line).append(s.substring(s.indexOf("VALUES(") + 8, s.length() - 1).replace("'", "")).append("\n");
            }
            writer.write(stringBuilder.toString());
            writer.close();
        } catch (IOException e) {
            logger.error(e.getMessage());
        }
    }

    public void writeQueryInfo(String fileName, List<String> list, String action) {
        String path = null;
        String directoryPath = null;
        String file = fileName.substring(0, fileName.indexOf("."));
        if ((rejectedRecords + queryIssueRecords) > 0) {
            path = Constants.FEEDFILEEXECUTIONFAILUREFOLDERPATH + file + File.separator;
        } else {
            path = Constants.FEEDFILEEXECUTIONSUCCESSFOLDERPATH + file + File.separator;
        }
        directoryPath = path;
        createFeedFileExecutionResultDirectory(path);
        if (action.contains("sql queries")) {
            path = path + file + ".sql";
        } else if (fileRecordsCount == 0) {
            createFeedFileExecutionResultDirectory(Constants.FEEDFILEEXECUTIONNEUTRALFOLDERPATH + file + "/");
            path = Constants.FEEDFILEEXECUTIONNEUTRALFOLDERPATH + file + File.separator + file + ".htm";
        } else {
            path = path + file + ".htm";
        }

        File fileObject = new File(path);
        try {
            if (!fileObject.exists()) {
                fileObject.createNewFile();
            }
            FileWriter writer = new FileWriter(fileObject);
            StringBuilder stringBuffer = new StringBuilder();
            if (action.contains("sql queries")) {
                for (String s : list) {
                    String query = s.substring(s.indexOf(": ") + 2);
                    stringBuffer.append(query).append("\n");
                }
            } else {
                stringBuffer.append(HTML.H3).append(fileName).append(HTML.H3_CLOSE).append(HTML.BR);
                stringBuffer.append(HTML.TABLE + HTML.TR + HTML.TD + "Total Records" + HTML.TD_CLOSE + HTML.TD).append(fileRecordsCount).append(HTML.TD_CLOSE).append(HTML.TR);
                stringBuffer.append(HTML.TR + HTML.TD + "Passed" + HTML.TD_CLOSE + HTML.TD).append(successRecords).append(HTML.TD_CLOSE).append(HTML.TR);
                stringBuffer.append(HTML.TR + HTML.TD + "Rejected " + HTML.TD_CLOSE + HTML.TD).append(rejectedRecords).append(HTML.TD_CLOSE).append(HTML.TR);
                stringBuffer.append(HTML.TR + HTML.TD + "Query Formulated Issue " + HTML.TD_CLOSE + HTML.TD).append(queryIssueRecords).append(HTML.TD_CLOSE).append(HTML.TR).append(HTML.TABLE_CLOSE);
                if (rejectedRecords > 0 || queryIssueRecords > 0) {
                    stringBuffer.append(HTML.LI + "Failed Insertions in file :: ").append(directoryPath).append(FAILED_INSERTION).append(file).append(".csv").append(HTML.LI_CLOSE).append(HTML.BR);
                }
                if (successRecords > 0) {
                    stringBuffer.append(HTML.LI + "Successful Insertions in file :: ").append(directoryPath).append(SUCCESSFUL_INSERTION).append(file).append(".csv").append(HTML.LI_CLOSE).append(HTML.BR);
                }

            }
            writer.write(stringBuffer.toString());
            writer.close();
            if (action.equalsIgnoreCase(STATS)) {
                commonActionHelper.appendTextInGlobalSummary(stringBuffer.toString());
            }
        } catch (IOException e) {
            logger.error(e.getMessage());
        }
    }

    public void createFeedFileExecutionResultDirectory(String path) {
        File directory = new File(path);
        if (!directory.exists()) {
            directory.mkdirs();
            logger.info("Directory created : {}", directory.getName());
        }
//        File[] files = directory.listFiles();
//        if (files.length > 0) {
//            for (File subfile : files) {
//                subfile.delete();
//            }
//        }
    }

    public Map<String, Boolean> getColumnNames(ResultSet result) {
        LinkedHashMap<String, Boolean> columnNames = new LinkedHashMap<>();
        try {
            ResultSetMetaData metadata = result.getMetaData();
            int columnCount = metadata.getColumnCount();
            for (int i = 1; i <= columnCount; i++) {
                String columnName = metadata.getColumnName(i);
                columnNames.put(columnName, false);
            }
        } catch (Exception e) {
            logger.error(e.getMessage());
        }
        logger.info("Table Columns are : {}", columnNames);
        return columnNames;
    }

    public List<String> getPrimaryKeyColumn(String tableName) {
        List<String> primaryColumns = new ArrayList<>();
        try {
            DatabaseMetaData meta = connection.getMetaData();
            primaryKeys = meta.getPrimaryKeys(null, null, tableName);
            while (primaryKeys.next()) {
                String columnName = primaryKeys.getString("COLUMN_NAME");
                primaryColumns.add(columnName);
            }
        } catch (Exception e) {
            logger.error(e.getMessage());
        }
        logger.info("Primary Key Column(s) are : {}", primaryColumns);
        return primaryColumns;
    }

    public Map<String, String> getColumnType() {
        HashMap<String, String> columnType = new HashMap<>();
        String columnName;
        String type;
        try {
            ResultSetMetaData metadata = rs.getMetaData();
            int columnCount = metadata.getColumnCount();
            for (int i = 1; i <= columnCount; i++) {
                columnName = metadata.getColumnName(i);
                type = String.valueOf(metadata.getColumnTypeName(i));
                columnType.put(columnName, type);
            }
        } catch (Exception e) {
            logger.error(e.getMessage());
        }
        logger.info("Table Columns type is : {}", columnType);
        return columnType;
    }

    public Map<String, String> processColumnTypeToDataTypeMapping(Map<String, String> columnType) throws Exception {
        XMLHelper xmlHelper = new XMLHelper();
        String rule = null;
        try {
            if (PropertiesHelper.getConfigPropProperty("dbType").equalsIgnoreCase("mysql")) {
                rule = "mysql-mapping.json";
            }
            File ruleFile = new File(RULESFILEPATH + rule);
            String ruleJson = xmlHelper.readFileAsString(ruleFile.getPath());
            List<String> mapArray;
            Map<String, Object> jsonObject = JsonPath.read(ruleJson, "$");
            for (Map.Entry<String, String> node : columnType.entrySet()) {
                for (Map.Entry<String, Object> mapNode : jsonObject.entrySet()) {
                    mapArray = (List<String>) mapNode.getValue();
                    if (mapArray.contains(node.getValue())) {
                        columnType.put(node.getKey(), mapNode.getKey());
                        break;
                    }
                }
            }
            commonActionHelper.appendTextInGlobalSummary(HTML.LI + "Column Type verification passed. Processed Table Columns DataType is : " + columnType + HTML.LI_CLOSE);
        } catch (Exception e) {
            logger.error(e.getMessage());
        }
        logger.info("Processed Table Columns DataType is :{}", columnType);
        return columnType;
    }

    public Map<String, String> getRecordFromTableUsingPrimaryKey(String tableName, List<String> primaryRecord, List<String> primaryColumns) throws SQLException {
        HashMap<String, String> dbRecord = new HashMap<>();
        StringBuilder condition = new StringBuilder();
        String foundKey;
        String foundValue = null;
        int i = 0;
        int ncols = 0;
        PreparedStatement statement;
        ResultSet rowResult = null;
        String query = loadProps.getFeedFileQueriesProperty("tmpl_getRowData");
        for (String s : primaryColumns) {
            if (i > 0) {
                condition = new StringBuilder(condition + "and ");
            }
            condition = new StringBuilder(condition + s + "=? ");
            i++;
        }
        query = query.replace("{", "")
                .replace("}", "")
                .replace(TABLE_NAME, tableName).replace("$Condition", condition);

        for (String s : primaryRecord) {
            query = query.replaceFirst("\\?", s);
        }
        try {
            statement = connection.prepareStatement(query);
            rowResult = statement.executeQuery();
            ncols = rowResult.getMetaData().getColumnCount();
            if (rowResult.next()) {
                for (int k = 1; k < (ncols + 1); k++) {
                    foundKey = rowResult.getMetaData().getColumnName(k);
                    foundValue = rowResult.getString(k);
                    dbRecord.put(foundKey, foundValue);
                }
            }
        } catch (Exception e) {
            logger.debug("Cannot fetch record from database for keys :: {}", primaryRecord);
            logger.error(e.getMessage());
        }
        logger.error("Successfully fetched record from database :: {}", dbRecord);
        return dbRecord;
    }

    public void slowCompareDBRecord(String ruleFileName, String rawFileName, String tableName) throws Exception {
        /*
         * Needed : Row from Raw Table , Record From DataBase , Rule
         * Get Row from Raw Table
         * Apply Rule on Raw Row
         * Get Same record from DataBase
         * Compare Records
         * Publish Report
         * */
        try {
            CSVHelper csvHelper = new CSVHelper();
            XMLHelper xmlHelper = new XMLHelper();
            JSONHelper jsonHelper = new JSONHelper();
            List<String> rawHeaders;
            List<String> rawRecord;
            List<String> processedRecord;
            Map<String, String> databaseRecord;
            List<String> primaryRecord;
            HashMap<String, String> rawDataRecord = new HashMap<>();
            Map<String, String> comparisionResult;
            File file = null;

            List<String> primaryColumns = getPrimaryKeyColumn(tableName);
            File ruleFile = new File(RULESFILEPATH + ruleFileName);
            String ruleJson = xmlHelper.readFileAsString(ruleFile.getPath());
            Map<String, Object> rulesJsonPath = jsonHelper.listJsonKeyValues(ruleJson);
            File file1 = new File(Constants.FEEDFILEEXECUTIONSUCCESSFOLDERPATH + rawFileName + File.separator + SUCCESSFUL_INSERTION + rawFileName + ".csv");
            File file2 = new File(Constants.FEEDFILEEXECUTIONFAILUREFOLDERPATH + rawFileName + File.separator + FAILED_INSERTION + rawFileName + ".csv");
            if (file1.exists() || file2.exists()) {
                if (file1.exists()) {
                    file = file1;
                } else {
                    file = file2;
                }
                logger.info("Starting record comparison for file :: {} and table :: {}", rawFileName, tableName);
                rawHeaders = csvHelper.getHeaders(csvHelper.loadFile(file));
                long recordCount = csvHelper.getRows(csvHelper.loadFile(file)).size();
                logger.info("Number of records to be compared :: {}", recordCount);
                for (int i = 0; i < recordCount; i++) {
                    rawRecord = csvHelper.getRow(csvHelper.loadFile(file), i);
                    processedRecord = xmlHelper.applyRuleOnRow(rawHeaders, rawRecord, rulesJsonPath, ruleJson);

                    primaryRecord = getPrimaryRecord(rawHeaders, primaryColumns, processedRecord);
                    databaseRecord = getRecordFromTableUsingPrimaryKey(tableName, primaryRecord, primaryColumns);
                    primaryRecord.clear();
                    for (int j = 0; j < rawHeaders.size(); j++) {
                        rawDataRecord.put(rawHeaders.get(j), processedRecord.get(j));
                    }

                    comparisionResult = compareMap(rawDataRecord, databaseRecord);
                    writeDbRawInfo(rawFileName, comparisionResult, "Comparision_");
                }
            }
        } catch (Exception e) {
            logger.error("Failed raw and Database records comparison for file :: {} with error {}", rawFileName, e.getMessage());
        }
    }

    public List<String> getPrimaryRecord(List<String> rawHeaders, List<String> primaryColumns, List<String> processedRecord) {
        List<String> primaryRecord = new ArrayList<>();
        for (int j = 0; j < rawHeaders.size(); j++) {
            if (primaryColumns.contains(rawHeaders.get(j))) {
                primaryRecord.add(processedRecord.get(j));
            }
        }
        return primaryRecord;
    }

    public void fastCompareDBRecord(String ruleFileName, String rawFileName, String tableName) {
        /*
         * Needed : Row from Raw Table , Record From DataBase , Rule
         * Get Row from Raw Table
         * Apply Rule on Raw Ro
         * Save row on Raw file
         * Get Same record from DataBase and save to a file
         * Compare Files
         * Publish Report
         * */
        try {
            CSVHelper csvHelper = new CSVHelper();
            XMLHelper xmlHelper = new XMLHelper();
            JSONHelper jsonHelper = new JSONHelper();
            List<String> rawHeaders;
            List<String> rawRecord;
            List<String> processedRecord;
            Map<String, String> databaseRecord;
            List<String> primaryRecord = new ArrayList<>();
            HashMap<String, String> rawDataRecord = new HashMap<>();
            File file = null;

            List<String> primaryColumns = getPrimaryKeyColumn(tableName);
            File ruleFile = new File(RULESFILEPATH + ruleFileName);
            String ruleJson = xmlHelper.readFileAsString(ruleFile.getPath());
            Map<String, Object> rulesJsonPath = jsonHelper.listJsonKeyValues(ruleJson);
            File file1 = new File(Constants.FEEDFILEEXECUTIONSUCCESSFOLDERPATH + rawFileName + File.separator + SUCCESSFUL_INSERTION + rawFileName + ".csv");
            File file2 = new File(Constants.FEEDFILEEXECUTIONFAILUREFOLDERPATH + rawFileName + File.separator + FAILED_INSERTION + rawFileName + ".csv");
            if (file1.exists() || file2.exists()) {
                file = checkFile(file1, file2);
                logger.info("Starting record comparison for file :: {} and table :: {}", rawFileName, tableName);
                rawHeaders = csvHelper.getHeaders(csvHelper.loadFile(file));
                long recordCount = csvHelper.getRows(csvHelper.loadFile(file)).size();
                logger.info("Number of records to be compared :: {}", recordCount);
                for (int i = 0; i < recordCount; i++) {
                    rawRecord = csvHelper.getRow(csvHelper.loadFile(file), i);
                    processedRecord = xmlHelper.applyRuleOnRow(rawHeaders, rawRecord, rulesJsonPath, ruleJson);

                    for (int j = 0; j < rawHeaders.size(); j++) {
                        if (primaryColumns.contains(rawHeaders.get(j))) {
                            primaryRecord.add(processedRecord.get(j));
                        }
                    }
                    databaseRecord = getRecordFromTableUsingPrimaryKey(tableName, primaryRecord, primaryColumns);
                    primaryRecord.clear();
                    for (int j = 0; j < rawHeaders.size(); j++) {
                        rawDataRecord.put(rawHeaders.get(j), processedRecord.get(j));
                    }

                    writeDbRawInfo(rawFileName, rawDataRecord, "raw_");
                    writeDbRawInfo(rawFileName, databaseRecord, "db_");
                }
                File rawfile = new File(file.getParent() + File.separator + "raw_" + rawFileName + ".csv");
                File dbfile = new File(file.getParent() + File.separator + "db_" + rawFileName + ".csv");
                csvHelper.compareCSVs(rawfile, dbfile, file.getParent() + File.separator);
//                :: FUTURE ::
//                rawfile.delete();
//                dbfile.delete();
            }
        } catch (Exception e) {
            logger.error(e.getMessage());
        }
    }

    public File checkFile(File file1, File file2) {
        File file = null;
        if (file1.exists()) {
            file = file1;
        } else {
            file = file2;
        }
        return file;
    }

    public void writeDbRawInfo(String fileName, Map<String, String> content, String status) {
        String path = null;
        String line = null;
        if (fileName.contains(".")) {
            fileName = fileName.substring(0, fileName.indexOf("."));
        }
        File directory = new File(Constants.FEEDFILEEXECUTIONFAILUREFOLDERPATH + fileName + File.separator);
        if (directory.exists()) {
            path = Constants.FEEDFILEEXECUTIONFAILUREFOLDERPATH + fileName + File.separator;
        } else {
            createFeedFileExecutionResultDirectory(Constants.FEEDFILEEXECUTIONSUCCESSFOLDERPATH + fileName + "/");
            path = Constants.FEEDFILEEXECUTIONSUCCESSFOLDERPATH + fileName + File.separator;
        }
        StringBuilder stringBuffer = new StringBuilder();
        for (String key : content.keySet())
            stringBuffer.append(key).append(", ");
        stringBuffer.setLength(stringBuffer.length() - 2);
        stringBuffer.append("\n");
        line = "";
        for (Map.Entry<String, String> node : content.entrySet()) {
            line = line + node.getValue() + ",";
        }
        line = line.substring(0, line.lastIndexOf(","));
        stringBuffer.append(line).append("\n");

        CSVHelper csvHelper = new CSVHelper();
        fileName = status + fileName;
        if (status.equalsIgnoreCase("Comparision_")) {
            csvHelper.fileWriterXLS(fileName, path, stringBuffer.toString());
            commonActionHelper.appendTextInGlobalSummary(HTML.LI + "The comparision report is stored at: " + FEEDFILEREPORTS + fileName);
        } else {
            try {
                File file = new File(path + fileName + ".csv");
                FileWriter writer = new FileWriter(file, true);
                writer.write(stringBuffer.toString());
                writer.close();
            } catch (Exception e) {
                logger.error(e.toString());
            }

        }

        logger.info("Created report file :: {}", path);

    }

    public void compareFiles(File file1, File file2) {
        commonActionHelper.appendTextInGlobalSummary(HTML.TABLE + HTML.TR + HTML.TD + "File 1" + HTML.TD_CLOSE + HTML.TD + "File 2" + HTML.TD_CLOSE + HTML.TD + "Status" + HTML.TD_CLOSE + HTML.TD + "Report Link" + HTML.TD_CLOSE + HTML.TR_CLOSE);
        CSVHelper csvHelper = new CSVHelper();
        csvHelper.compareCSVs(file1, file2);
        commonActionHelper.appendTextInGlobalSummary(HTML.TABLE_CLOSE);
    }


    public void fetchRecordFromDB(String table, String ruleFileName) {
        XMLHelper xmlHelper = new XMLHelper();
        CSVHelper csvHelper = new CSVHelper();
        String csvFileName = table.concat("_Data").concat(".csv");
        //Step-1 Fetch Record from DB and store in CSV File at given location
        ruleFileName = ruleFileName + ".JSON";
        String ruleJson = xmlHelper.readFileAsString(Constants.RULESFILEPATH + ruleFileName);
        String query = loadProps.getFeedFileQueriesProperty("tmpl_selectQuery");
        query = query.replace("{", "");
        query = query.replace("}", "");
        query = query.replace(TABLE_NAME, table);
        try (Statement statement = connection.createStatement()) {
            ResultSet result = statement.executeQuery(query);
            String path = null;
            File file1 = new File(Constants.FEEDFILEREPORTS_DATAQUALITY + csvFileName);
            path = checkFile(file1, csvFileName);
            FileWriter file = new FileWriter(path);
            bufferedWriter = new BufferedWriter(file);
            int columnCount = writeHeaderLine(result);
            while (result.next()) {
                String line = "";
                for (int i = 1; i <= columnCount; i++) {
                    Object valueObject = result.getObject(i);
                    String valueString = "";
                    if (valueObject != null) valueString = valueObject.toString();
                    if (valueObject instanceof String) {
                        valueString = "\"" + escapeDoubleQuotes(valueString) + "\"";
                    }
                    line = line.concat(valueString);
                    if (i != columnCount) {
                        line = line.concat(",");
                    }
                }
                bufferedWriter.newLine();
                bufferedWriter.write(line);
            }
            bufferedWriter.close();
            //Step-2 Read data from CSV file and check against the ruleJson file
            File fileRead = new File(Constants.FEEDFILEREPORTS_DATAQUALITY + csvFileName);
            Boolean finalStatus = csvHelper.checkCSVDataQuality(fileRead, ruleJson);
            if (Boolean.TRUE.equals(finalStatus))
                logger.info("file validation successful against the rule file");
            else
                logger.info("file validation failed against the rule file");

        } catch (SQLException | IOException e) {
            commonActionHelper.appendTextInGlobalSummary(HTML.LI + HTML.ERROR + e.getMessage() + HTML.LI_CLOSE);
        }
    }

    private String checkFile(File file1, String csvFileName) {
        String path = null;
        if (file1.exists()) {
            path = Constants.FEEDFILEREPORTS_DATAQUALITY + csvFileName;
        } else {
            createFeedFileExecutionResultDirectory(Constants.FEEDFILEREPORTS_DATAQUALITY);
            path = Constants.FEEDFILEREPORTS_DATAQUALITY + csvFileName;
        }
        return path;
    }

    private int writeHeaderLine(ResultSet result) throws SQLException, IOException {
        ResultSetMetaData metaData = result.getMetaData();
        int numberOfColumns = metaData.getColumnCount();
        String headerLine = "";
        for (int i = 1; i <= numberOfColumns; i++) {
            String columnName = metaData.getColumnName(i);
            headerLine = headerLine.concat(columnName).concat(",");
        }
        bufferedWriter.write(headerLine.substring(0, headerLine.length() - 1));
        return numberOfColumns;
    }

    private String escapeDoubleQuotes(String value) {
        return value.replace("\"", "\"\"");
    }

    public void readsDataFromTableAndViewCompare(String table, String view, String ruleFileName, String transformFlag) {
        commonActionHelper.appendTextInGlobalSummary(HTML.TABLE + HTML.TR + HTML.TD + "File 1" + HTML.TD_CLOSE + HTML.TD + "File 2" + HTML.TD_CLOSE + HTML.TD + "Status" + HTML.TD_CLOSE + HTML.TD + "Report Link" + HTML.TD_CLOSE + HTML.TR_CLOSE);
        commonActionHelper.addInContextMap("isTableReq", "true");
        // fetch data from table and view store it, compare and make the output report for comparision
        Map<String, Boolean> tableColumnNames;
        CSVHelper csvHelper = new CSVHelper();
        JSONHelper jsonHelper = new JSONHelper();
        Map<String, Boolean> viewColumnNames;
        StringBuilder columns = new StringBuilder();
        XMLHelper xmlHelper = new XMLHelper();
        ruleFileName = ruleFileName + ".json";
        String ruleJson = xmlHelper.readFileAsString(Constants.RULESFILEPATH + ruleFileName);
        Map<String, Object> rulesJsonPath = jsonHelper.listJsonKeyValues(ruleJson);
        List<String> list = xmlHelper.getPrimaryKeyColumnsFromRules(ruleJson);
        String primaryKey = list.get(0);
        String query = loadProps.getFeedFileQueriesProperty("tmpl_selectQuery");
        query = query.replace("{", "").replace("}", "");
        String tableQuery = query.replace(TABLE_NAME, table);
        String viewQuery = query.replace(TABLE_NAME, view);
        try (Statement statement = connection.createStatement()) {
            ResultSet result = statement.executeQuery(tableQuery);
            tableColumnNames = getColumnNames(result);
            result = statement.executeQuery(viewQuery);
            viewColumnNames = getColumnNames(result);
            Set<String> entrySet = tableColumnNames.keySet();
            for (String s : entrySet) {
                if (viewColumnNames.containsKey(s))
                    columns.append(s).append(",");
            }
            int x = columns.lastIndexOf(",");
            columns.replace(x, x + 1, "");
            tableQuery = tableQuery.replace("*", columns).replace(";", " order by " + primaryKey + ";");
            result = statement.executeQuery(tableQuery);
            writeInFile(result, table);
            File tableFileRead = new File(Constants.FEEDFILEREPORTS_DATAQUALITY + table + ".csv");
            List<String> primarykeys = csvHelper.getColumn(tableFileRead, primaryKey);
            StringBuilder keys = new StringBuilder();
            for (String s : primarykeys) {
                keys.append(s).append(",");
            }
            viewQuery = viewQuery.replace("*", columns).replace(";", " where " + primaryKey + " IN " + primarykeys).replace("[", "(").replace("]", ");");
            result = statement.executeQuery(viewQuery);
            writeInFile(result, view);
            File viewFileRead = new File(Constants.FEEDFILEREPORTS_DATAQUALITY + view + ".csv");
            // Transform the table data and compare
            if (transformFlag != null) {
                File transformedFile = transformData(table, tableFileRead, ruleJson, rulesJsonPath);
                csvHelper.compareCSVs(transformedFile, viewFileRead);
            } else {
                csvHelper.compareCSVs(tableFileRead, viewFileRead);
            }
        } catch (SQLException | IOException e) {
            commonActionHelper.appendTextInGlobalSummary(HTML.LI + HTML.ERROR + e.getMessage() + HTML.LI_CLOSE);
        }
        commonActionHelper.appendTextInGlobalSummary(HTML.TABLE_CLOSE);
    }

    public void writeInFile(ResultSet result, String tableName) throws IOException, SQLException {
        String path = null;
        File file = new File(Constants.FEEDFILEREPORTS_DATAQUALITY + tableName + ".csv");
        if (file.exists()) {
            path = Constants.FEEDFILEREPORTS_DATAQUALITY + tableName + ".csv";
        } else {
            createFeedFileExecutionResultDirectory(Constants.FEEDFILEREPORTS_DATAQUALITY);
            path = Constants.FEEDFILEREPORTS_DATAQUALITY + tableName + ".csv";
        }
        FileWriter fileWriter = new FileWriter(path);
        bufferedWriter = new BufferedWriter(fileWriter);
        int columnCount = writeHeaderLine(result);
        while (result.next()) {
            String line = "";
            for (int i = 1; i <= columnCount; i++) {
                Object valueObject = result.getObject(i);
                String valueString = "";
                if (valueObject != null) valueString = valueObject.toString();
                line = line.concat(valueString);
                if (i != columnCount) {
                    line = line.concat(",");
                }
            }
            bufferedWriter.newLine();
            bufferedWriter.write(line);
        }
        bufferedWriter.close();
        fileWriter.close();
    }

    public File transformData(String tableName, File file, String ruleJson, Map<String, Object> rulesJsonPath) throws IOException {
        CSVHelper csvHelper = new CSVHelper();
        XMLHelper xmlHelper = new XMLHelper();
        StringBuilder stringBuilder = new StringBuilder();
        List<String> rawHeaders;
        List<String> rawRecord;
        List<String> processedRecord;
        LinkedHashMap<String, String> rawDataRecord = new LinkedHashMap<>();
        long recordCount = csvHelper.getRows(csvHelper.loadFile(file)).size();
        rawHeaders = csvHelper.getHeaders(csvHelper.loadFile(file));
        File transformedfile = new File(Constants.FEEDFILEREPORTS_DATAQUALITY + tableName + "_Transformed_file" + ".csv");
        try (FileWriter writer = new FileWriter(transformedfile)) {
            for (int i = 0; i < recordCount; i++) {
                rawRecord = csvHelper.getRow(csvHelper.loadFile(file), i);
                processedRecord = xmlHelper.applyRuleOnRow(rawHeaders, rawRecord, rulesJsonPath, ruleJson);
                for (int j = 0; j < rawHeaders.size(); j++) {
                    rawDataRecord.put(rawHeaders.get(j), processedRecord.get(j));
                }
                if (stringBuilder.length() < 1) {
                    for (String key : rawDataRecord.keySet()) {
                        stringBuilder.append(key).append(",");
                    }
                    stringBuilder = new StringBuilder(stringBuilder.substring(0, stringBuilder.lastIndexOf(",")).concat("\n"));
                    writer.write(stringBuilder.toString());
                }
                StringBuilder line = new StringBuilder();
                for (Map.Entry<String, String> node : rawDataRecord.entrySet()) {
                    line.append(node.getValue()).append(",");
                }
                line = new StringBuilder(line.substring(0, line.lastIndexOf(",")).concat("\n"));
                writer.write(line.toString());
                writer.flush();
            }

        }
        return transformedfile;
    }

}
