package com.qe.framework.enums;

public enum SwipeDirection {
    UP,
    DOWN,
    LEFT,
    RIGHT;
}
