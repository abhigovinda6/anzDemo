package com.qe.framework.enums;

public enum LocatorTypeEnum {
    id, name, css, linkText, partialLinkText, tagName, xpath, className
}
