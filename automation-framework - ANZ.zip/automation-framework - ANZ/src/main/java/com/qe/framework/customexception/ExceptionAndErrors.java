package com.qe.framework.customexception;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ExceptionAndErrors {
    private ExceptionAndErrors() {
        throw new IllegalStateException("Utility class");
    }

    private static final String FAILEDSTEP = "This test-step has failed"; // Compliant
    private static final Logger logger = LoggerFactory.getLogger(ExceptionAndErrors.class);

    public static String getFailedstep(WebElement ele) {
        throw new AssertionError("WebElement Not Found: " + " - " + ele);
    }

    public static String getFailedstep() {
        throw new AssertionError(ExceptionAndErrors.FAILEDSTEP);

    }

    public static String getFailedstep(Exception e) {
        throw new AssertionError(ExceptionAndErrors.FAILEDSTEP + " - " + e);

    }

    public static String getFailedstep(AssertionError e) {
        throw new AssertionError(ExceptionAndErrors.FAILEDSTEP + " - " + e);

    }

    public static String getFailedstep(String e) {
        throw new AssertionError(ExceptionAndErrors.FAILEDSTEP + "- " + e);

    }

    public static void getPassedstep(String e) {
        ExceptionAndErrors.logger.info("Step is passed -> {}", e);
    }

    public static String getFailedstep(Exception e, WebElement el) {
        throw new AssertionError(ExceptionAndErrors.FAILEDSTEP + " - " + e + " - " + el);

    }

    public static String getFailedstep(String e, WebElement el) {

        throw new AssertionError(ExceptionAndErrors.FAILEDSTEP + " - " + e + " - " + el);

    }

    public static String getFailedstep(By el) {
        throw new AssertionError(ExceptionAndErrors.FAILEDSTEP + "-" + el);

    }

    public static String getAPIFailedstep(String e) {
        ExceptionAndErrors.logger.error("Exception in API call failed: {}", e);
        throw new AssertionError("exception in API call Failed " + "- " + e);
    }

    public static void getAPIPassedstep(String e) {
        ExceptionAndErrors.logger.info("Step is passed in API-> {}", e);
    }
}
