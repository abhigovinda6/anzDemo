# Purpose #

This repository is developed and maintained for Automation Script Development and Execution for Application release. The
project is developed using MAVEN and supports POM for specifying the dependencies. The framework is capable to execute 
tests on Local Browsers, Local Appium Server, Remote Browsers on Azure Devops, Remote Devices and Desktop WEB on Perfecto. 
The tests can as well be executed on Perfecto via PS-Azure.

# Framework Capabilities

## Functional Testing

#### Desktop Web Browser

* Chrome, FireFox, Edge, Safari

#### Responsive Web Browser

* Chrome, FireFox, Edge, Safari

#### Mobile Web Browser

* Chrome on Android
* Safar on iOS

#### Mobile App

* Android (APK app)
* iOS (IPA app)

# API
* Handling API Methods - GET, PUT, POST, DELETE
* Polling an API call
* oAuth

# Integration with Perfecto Cloud
* WEB Desktop & Responsive
  * Window (Chrome, Firefox, Edge)
  * MAC (Safari, Chrome, Firefox)
    * Note: We only have two licences for Safari. Any additional request will be redirected ti Win-Chrome
* Devices - Android and iOS

# Accessibility Testing
* It is implemented via AXE plugin
* It can test different wcag categories - wcag2a, wcag2aa, or both
* and different impact levels - critical, serious, moderate, minor, or all

# Security Testing
* OWASP Zap tool is being used to Scan-n-Test the application
* Test Capabilities - Spider Scan, Active Scan, Passive Scan, Authentication Scanning 

# Feed File Ingestion, Structural Integrity, Data Quality Validation
* For details refer the confluence page - https://tools.publicis.sapient.com/confluence/display/ASDA/Feed+File+Testing

## Framework Key Components

* Runners - Provides a plan on high level. Enabling tests given in Feature files. You can narrow down to specific tests
  via @TAGS
* Configurators - Local Machine, Cloud, Mobile Viewport, specific to Environment
* Feature Files - Test Steps written in plain English by making use of Gherkin (plugin - cucumber for JAVA), thus
  allowing interaction with JAVA
* Driver Contexts - Ability to handle variety of contexts - Desktop Web, Mobile Browsers, Mobile Apps
* Selenium Library - Frontend as Step-Definitions (StepDefs), Backend is Common/Helper Modules -> Driver Core
* Common Methods - set of common function that can be used between Web and App context
* Locator Processor - to process the Locators definition into required Action Elements based on Context
* API Library - Frontend as Step-Definitions (StepDefs), Backend is Common Modules -> DriverHelper
* Utils - generic library of static methods that can be used to perform variety of related tasks across the context
* Test Data Handlers - Ability to read files pertaining to an Env - AppType
* Security Testing - It is implemented via ZAP tool
* Visual Test and Analytics - (TBD)
* Cucumber Reporting

## Test Layer

* Cucumber Feature files - Automation script to test User Stories.
* Step Definition - To interpret the Feature Files, performs initial vetting of input via Steps and then pass the
  information to Helper modules
* Runner files - allows execution of Feature files
* Configuration - These files have details of the environments, test-data and other runtime config
* Page Objects - These contain the Locator reference to each Web/Device element under test

## Configuration Setting - Functional Testing

|                    | AppType    | browserType | deviceName | deviceVersion | mobileAppFileName    |
|--------------------|------------|-------------|------------|---------------|----------------------|
| Desktop Browser    | web        | chrome      | discarded  | discarded     | discarded            |
| Desktop Browser    | web        | firefox     | discarded  | discarded     | discarded            |
| Desktop Browser    | web        | edge        | discarded  | discarded     | discarded            |
| Desktop Responsive | responsive | chrome      | Nexus 5    | discarded     | discarded            |
| Desktop Responsive | responsive | firefox     | Nexus 5    | discarded     | discarded            |
| Desktop Responsive | responsive | edge        | Nexus 5    | discarded     | discarded            |
| Mobile Browser     | android    | chrome      | Pixel5     | 10            | discarded            |
| Mobile Browser     | iOS        | safari      | iPhoneSE   | 10            | discarded            |
| Mobile App         | android    | discarded   | Pixel5     | 10            | APK file location    |
| Mobile App         | iOS        | discarded   | iPhoneSE   | 10            | IPA file location    |

### Clone the repository ###

```    git clone https://github.com/Asda-eCom/automation-framework.git  ```

## Execution Modes

* Sequential
* Parallel

### Ways to Execute

* IDE (Intelli-J)
* CLI (Command line)
* Azure Devops Pipeline
  * Local - Runs on Browsers provided by DevOps agent
  * Remote - Runs on Browsers on Perfecto Cloud

### How to use Tags in Runner File

OR - i.e. @ios or @android  
tags = {"@ios, @android"}

AND - i.e. @mobile and @android  
tags = {"@mobile", "@android"}

Combination of AND & OR  
tags = {"@mobile",("@ios, @android")}

Scenarios marked as @norun will be skipped when you prefix tag with tilde symbol ~
tags = {"@web", "~@norun"}

### Use Local Config file for testing on your local machine

NOTE: Never make changes to Config.properties

1. make a copy of src\test\resources\config\Config.properties and paste it in the same location
2. Rename the copy as Config_Local.properties
3. You can change anything here for testing on local machine.

### Single/Sequential execution

```mvn clean verify -P Single -Dtestsuitnamefromci="**/*WebTestRunner.java" -Dcucumber.options="-t @web" ```

#### Parallel execution

```mvn clean verify -P Parallel "-DparallelScheme=FEATURE" "-Dtags=@web" "-DforkCount=3" -"Dsd=com/qe/test/stepdefinition/" -"Dffile=src/test/resources/features/web" -DrunBrowserHeadLess=no```

### Executing multiple tags

```mvn clean verify -P Parallel "-DparallelScheme=FEATURE" "-Dtags=@web" "-DcreateChecksum=true" "-DforkCount=2" "-Dsd=com/qe/test/stepdefinition/" "-Dffile=src/test/resources/features/web/test/"```

### Specific Browser

NOTE: We do not require Browser Drivers to be separately downloaded as we are using Bonigarcia dependency to download the drivers at runtime. 
However, a driver is required only for Appium Chromedriver on MAC machine

```mvn clean verify -P Parallel "-DparallelScheme=FEATURE" "-Dtags=@web" "-DcreateChecksum=true" "-DforkCount=2" "-DdriverType=local" "-DAppType=web" -"Dsd=com/qe/test/stepdefinition/" -"Dffile=src/test/resources/features/web"```

```mvn clean verify -P Parallel "-DparallelScheme=FEATURE" "-Dtags=@web" "-DcreateChecksum=true" "-DforkCount=2" "-DdriverType=local" "-DAppType=web" -Dtargeted.web.browserType=chrome -"Dsd=com/qe/test/stepdefinition/" -"Dffile=src/test/resources/features/web"```

#### Execution on Android

```mvn clean verify -P Parallel "-DparallelScheme=FEATURE" "-Dtags=@perfecto" "-DcreateChecksum=true" "-DforkCount=1" "-DdriverType=local" "-DAppType=mobile" "-Dsd=com/qe/test/stepdefinition/" "-Dffile=src/test/resources/features/OnBoarding/appium/" -Dtargeted.mobile.deviceName=Android```

#### Execution on iOS

```mvn clean verify -P Parallel "-DparallelScheme=FEATURE" "-Dtags=@perfecto" "-DcreateChecksum=true" "-DforkCount=1" "-DdriverType=local" "-DAppType=mobile" "-Dsd=com/qe/test/stepdefinition/" "-Dffile=src/test/resources/features/OnBoarding/appium/" -Dtargeted.mobile.deviceName=iOS```

For detailed device setup and execution steps, please visit the confluence page at:
https://tools.publicis.sapient.com/confluence/pages/viewpage.action?pageId=1443761527


### Primary POC for Automation ###

| Tanuj Wadhwa   |
|----------------|


### Repo Owner ###

| Tanuj Wadhwa   |
|----------------|
| Vineet Manotra |

